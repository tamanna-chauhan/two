package com.tamanna.basearchitecture.ui.screen.login

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import androidx.navigation.fragment.findNavController
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.data.models.base.APIConstant
import com.tamanna.basearchitecture.data.models.base.RHandler
import com.tamanna.basearchitecture.databinding.FragmentLoginBinding
import com.tamanna.basearchitecture.ui.base.BaseFragment
import com.tamanna.basearchitecture.util.IConstants
import com.tamanna.basearchitecture.util.viewutils.YumUtil
import com.tamanna.basearchitecture.util.viewutils.YumUtil.showSoftKeyboard
import org.koin.androidx.viewmodel.ext.android.viewModel


class LoginFragment : BaseFragment<FragmentLoginBinding, LoginViewModel>(), ILoginView {

    override val fvm: LoginViewModel by viewModel()


    override fun getLayoutId() = R.layout.fragment_login


    private val navController by lazy {
        findNavController()
    }

    override fun onFragmentReady(view: View) {
        bd.loginViewmodel = fvm
        applyDebounceClickListener(bd.btnLogin)
        bd.mobileInput.showSoftKeyboard()
        bd.mobileInput.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(cs: CharSequence, arg1: Int, arg2: Int, arg3: Int) {
                bd.editTextOutline.error = null
            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int, arg3: Int) {
            }

            override fun afterTextChanged(arg0: Editable) {
            }
        })
    }

    override fun navToOtp() {

        fvm.loginSendOtp(bd.mobileInput.text.toString()).observe(this, { result ->
            RHandler<Any>(
                this,
                result
            ) {


            }

        })

    }

    override fun onResponse(code: Int?, response: Any?, title: String?, message: String) {
        when (code) {
            APIConstant.Code.OTP_SENT_SUCCESS -> {
                val args = Bundle()
                args.putString(IConstants.FragmentArgs.MOBILE, bd.mobileInput.text.toString())
                args.putString(IConstants.FragmentArgs.FLAG, IConstants.FragmentArgs.LOGIN)
                navController.navigate(R.id.action_fragment_login_to_fragment_otp_verify, args)

            }

            APIConstant.Code.NEW_USER -> {
                showAlerter(title ?: "", message)
                val args = Bundle()
                args.putString(IConstants.FragmentArgs.MOBILE, bd.mobileInput.text.toString())
                navController.navigate(R.id.action_fragment_login_to_fragment_signup, args)

            }

            else -> super.onResponse(code, response, title ?: "", message)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val no = arguments?.getString(IConstants.FragmentArgs.MOBILE)
        if (no != null) {
            bd.mobileInput.setText(no.toString())
        }
    }

    override fun onDebounceClick(view: View) {
        when (view) {
            bd.btnLogin -> {

                if (bd.mobileInput.text.toString().isNotEmpty()) {


                    if (YumUtil.isValidMobile(bd.mobileInput.text.toString())) {
                        bd.editTextOutline.error = null
                        navToOtp()
                    } else {
                        bd.editTextOutline.error = getString(R.string.incorrect_mobile_number)

                    }
                } else {
                    bd.editTextOutline.error = getString(R.string.enter_mobile_number)

                }


            }
        }
        super.onDebounceClick(view)
    }
}