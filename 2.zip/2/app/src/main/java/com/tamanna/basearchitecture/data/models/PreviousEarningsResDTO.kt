package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName

/**
 * Created by Bhupendra Kumar Sahu on 10-Feb-21.
 */
data class PreviousEarningsResDTO(
    @field:SerializedName("nextSkip") val nextSkip: Int,
    @field:SerializedName("previousEarnings") val previousEarnings: List<PreEarningListDTO>

)

data class PreEarningListDTO(
    @field:SerializedName("earnings") val earnings: Double,
    @field:SerializedName("trips") val trips: Long,
    @field:SerializedName("weekDay") val weekDay: Long,
    @field:SerializedName("weekDayLabel") val weekDayLabel: String,
    @field:SerializedName("createdAt") val createdAt: String,
)