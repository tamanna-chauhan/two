package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

/**
 * Created by Shriom Tripathi .
 */

data class TaskInfoDTO (
        @field:SerializedName("expectedDistance") val expectedDistance: Double,
        @field:SerializedName("expectedEarning") val expectedEarning: Double,
        @field:SerializedName("activeTask") val task: Task
): Serializable

data class Task(
        @field:SerializedName("_id") val id: String,
        @field:SerializedName("taskLeg") var taskLeg: String,
        @field:SerializedName("taskLocation") val taskLocation: TaskLocation,
        @field:SerializedName("deliveryType") val deliveryType: String,
        @field:SerializedName("status") var status: String,
        @field:SerializedName("packetInfo") val packetInfo: PacketInfo,
        @field:SerializedName("creationTime") val creationTime: String?,
        @field:SerializedName("completionTime") val completionTime: String? = null,
        @field:SerializedName("scheduledDate") val scheduledDate: String? = null,
        @field:SerializedName("taskId") val taskID: String,
        @field:SerializedName("estDistance") val estDistance: Double,
        @field:SerializedName("estDuration") val estDuration: Double,
        @field:SerializedName("accountTransactionId") val accountTransactionID: String,
        @field:SerializedName("assignmentSeq") val assignmentSeq: Double,
        @field:SerializedName("clientOrderId") val clientOrderId: Long
): Serializable

data class PacketInfo (
    @field:SerializedName("payment") val payment: Payment,
    @field:SerializedName("items") val items: List<Item>,
    @field:SerializedName("packetType") val packetType: List<Any?>
): Serializable

data class Payment(
    @field:SerializedName("amount") val amount: Double,
    @field:SerializedName("transactionId") var transactionID: String,
    @field:SerializedName("payStatus") var payStatus: String,
    @field:SerializedName("payMethod") val payMethod: String
) : Serializable

data class TaskLocation (
        @field:SerializedName("specialInstructions") val specialInstructions: List<String>,
        @field:SerializedName("coordinates") val coordinates: Coordinates,
        @field:SerializedName("contact") val contact: Contact,
        @field:SerializedName("addressLine") val addressLine: String,
        @field:SerializedName("houseNum") val houseNum: String,
        @field:SerializedName("pincode") val pincode: Int,
        @field:SerializedName("city") val city: String,
        @field:SerializedName("locality") val locality: String,
        @field:SerializedName("landmark") val landmark: String,
): Serializable

data class Contact (
        @field:SerializedName("name") val name: String,
        @field:SerializedName("mobile1") val mobile1: String,
        @field:SerializedName("mobile2") val mobile2: String,
        @field:SerializedName("landline") val landline: String,
        @field:SerializedName("extension") val extension: String
): Serializable

data class Coordinates (
        @field:SerializedName("coordinates") val coordinates: List<Double>,
        @field:SerializedName("type") val type: String
): Serializable

data class Item (
        @field:SerializedName("name") val name: String,
        @field:SerializedName("qty") val qty: Int,
        @field:SerializedName("approxvalue") val approxvalue: Double
): Serializable