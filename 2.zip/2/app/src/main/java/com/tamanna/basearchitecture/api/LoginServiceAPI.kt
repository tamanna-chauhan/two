package com.tamanna.basearchitecture.api

import com.tamanna.basearchitecture.data.models.*
import com.tamanna.basearchitecture.data.models.base.APIConstant
import com.tamanna.basearchitecture.data.models.base.LoginResponseDTO
import com.tamanna.basearchitecture.data.models.base.ResponseDTO
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query


interface LoginServiceAPI {

    @POST(APIConstant.URL.LOGIN_SEND_OTP)
    suspend fun loginSendOtp(@Body sendOtpDTO: SendOtpDTO): Response<ResponseDTO<Any>>

    @POST(APIConstant.URL.LOGIN)
    suspend fun verifyLogin(@Body loginOtpDTO: LoginOtpDTO): Response<ResponseDTO<LoginResponseDTO>>

    @POST(APIConstant.URL.SIGN_UP)
    suspend fun verifySignUp(@Body signupOtpDTO: SignUpOtpDTO): Response<ResponseDTO<SignUpResponseDTO>>

    @POST(APIConstant.URL.SIGNUP_SEND_OTP)
    suspend fun signupResendOtp(@Body sendOtpDTO: SendOtpDTO): Response<ResponseDTO<Any>>


    @POST(APIConstant.URL.LOGOUT)
    suspend fun logout(
        @Query("tamannaId") tamannaId: String
    ): Response<ResponseDTO<Any>>

    @POST(APIConstant.URL.UPDATE_LOCATION)
    suspend fun updateLocation(
        @Body body: Map<String, String>
    ): Response<ResponseDTO<Any>>

    @POST(APIConstant.URL.DUTY)
    suspend fun duty(@Body hashMap: HashMap<String, String>): Response<ResponseDTO<DutyResDTO>>
}
