package com.tamanna.basearchitecture.ui.base.sheetdialog

interface IBaseActionSheetTemplete
