package com.tamanna.basearchitecture.worker

interface SmsListener {
    fun messageReceived(messageText: String?)
    fun onTimeOut(messageText: String?)

}