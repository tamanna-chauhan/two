package com.tamanna.basearchitecture.ui.screen.mainActivity.data

import com.tamanna.basearchitecture.api.BaseDataSource
import com.tamanna.basearchitecture.api.LoginServiceAPI
import com.tamanna.basearchitecture.api.ProcessServiceAPI
import com.tamanna.basearchitecture.data.models.ProcessDTO
import com.tamanna.basearchitecture.data.models.ProcessPayloadDTO

class MainRemoteDataSource constructor(
//    private val serviceAPI: LoginServiceAPI

    private val processAPI : ProcessServiceAPI
) :
    BaseDataSource() {

    suspend fun getList(process : ProcessPayloadDTO) = getResult {
        processAPI.getList(process)
    }


    suspend fun getErrorList() = getResult {
        processAPI.getErrorList()
    }


//    suspend fun logout(tamannaId: String) = getResult {
//        serviceAPI.logout(tamannaId)
//    }



}
