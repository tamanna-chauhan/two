package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.databinding.ViewSelectAccountBinding
import com.tamanna.basearchitecture.ui.helper.hideEmptyTextView
import com.tamanna.basearchitecture.util.viewutils.YumUtil

/**
 * Created by Bhupendra Kumar Sahu on 20-Aug-20.
 */
class LSelectAccountView : LinearLayout {

    var iconTextColor: Int = 0
        set(value) {
            field = value
            vbd.saIconCross.setTextColor(field)
        }

    var icon: CharSequence? = ""
        set(value) {
            field = value
            vbd.saIconCross.hideEmptyTextView(field.toString())
        }

    var header: CharSequence? = ""
        set(value) {
            field = value
            vbd.saTvHeader.tv_header.hideEmptyTextView(field.toString())
        }

    var des: CharSequence? = ""
        set(value) {
            field = value
            vbd.saTvDescription.tv_description.hideEmptyTextView(field.toString())
        }
    var holderName: CharSequence? = ""
        set(value) {
            field = value
            vbd.viewAccountDetails.description.tv_description.hideEmptyTextView(field.toString())
        }

    var acNo: CharSequence? = ""
        set(value) {
            field = value
            vbd.viewAccountDetails.header.tv_header.hideEmptyTextView(field.toString())
        }

    fun getCrossIcon(): View {
        return vbd.saIconCross
    }

    fun getTransferBtn(): View {
        return vbd.btnTransfer.actionButton
    }

    fun getAmount(): String {
        return vbd.inputAmount.text.toString()
    }

    fun getInputLayout(): View {
        return vbd.editAmountOutline.findViewById(R.id.edit_amount_outline)
    }

    fun getEditText(): View {
        return vbd.editAmountOutline.findViewById(R.id.input_amount)
    }

    private val vbd by lazy {
        val layoutInflater = LayoutInflater.from(context)
        ViewSelectAccountBinding.inflate(
            layoutInflater,
            this,
            true
        )
    }

    constructor(context: Context) : this(context, null, 0)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {

        if (attrs != null) {
            val a = context.theme.obtainStyledAttributes(
                attrs,
                R.styleable.LSelectAccountView,
                defStyleAttr,
                0
            )
            header = a.getString(R.styleable.LSelectAccountView_cardHeader) ?: header
            des = a.getString(R.styleable.LSelectAccountView_cardDescription) ?: des
            icon = a.getString(R.styleable.LSelectAccountView_fontIcon) ?: icon
            holderName = a.getString(R.styleable.LSelectAccountView_holderName) ?: holderName
            acNo = a.getString(R.styleable.LSelectAccountView_acNo) ?: acNo
            iconTextColor = a.getInt(R.styleable.LSelectAccountView_fontIconColor, 0)

            vbd.inputAmount.filters = arrayOf(YumUtil.CLDecimalDigitsInputFilter(6, 2))
            a.recycle()
        }
    }
}