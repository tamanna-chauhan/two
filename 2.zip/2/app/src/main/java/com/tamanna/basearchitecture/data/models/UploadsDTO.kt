package com.tamanna.basearchitecture.data.models

/**
 * Created by Bhupendra Kumar Sahu on 25-Jan-21.
 */
class UploadsDTO