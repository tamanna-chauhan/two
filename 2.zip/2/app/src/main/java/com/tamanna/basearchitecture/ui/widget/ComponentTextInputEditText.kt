package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.LinearLayout
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.tamanna.basearchitecture.R


/**
 * Created by Bhupendra Kumar Sahu on 19-Aug-20.
 */
class ComponentTextInputEditText @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : LinearLayout(context, attrs, defStyleAttr, defStyleRes) {
     val input_edit_text: TextInputEditText
    private val edit_text_outline: TextInputLayout

    var input: CharSequence = ""
        set(value) {
            if (value == null) {
                input_edit_text.visibility = View.INVISIBLE
                input_edit_text.setText("")
                return
            }
            input_edit_text.setText(value)
            field = value
        }
    var inputHint: CharSequence = ""
        set(value) {

            input_edit_text.hint = value
            edit_text_outline.hint = value
            field = value
        }
//
//    var inputType: Int = 0
//        set(value) {
//
//            input_edit_text.inputType = value
//            field = value
//        }

    var alignmentCenter: Boolean = false
        set(value) {
            if (value) {
                input_edit_text.textAlignment = View.TEXT_ALIGNMENT_CENTER
            } else {
                input_edit_text.textAlignment = View.TEXT_ALIGNMENT_TEXT_START
            }
            field = value
        }

    init {
        clipToPadding = false
        val view = View.inflate(context, R.layout.type_attribute_input_edittext, this)
        input_edit_text = view.findViewById(R.id.input_edit_text)
        edit_text_outline = view.findViewById(R.id.edit_text_outline)

        val a = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.ComponentTextInputEditText,
            defStyleAttr,
            defStyleRes
        )
        input = a.getString(R.styleable.ComponentTextInputEditText_inputText) ?: input
        inputHint = a.getString(R.styleable.ComponentTextInputEditText_inputTextHint) ?: inputHint
     //   inputType = a.getInt(R.styleable.ComponentTextInputEditText_inputType,0) ?: inputType
        alignmentCenter =
            a.getBoolean(R.styleable.ComponentTextInputEditText_alignmentCenter, false)
        a.recycle()
    }
}