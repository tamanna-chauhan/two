package com.tamanna.basearchitecture.ui.screen.login

import com.tamanna.basearchitecture.ui.base.IView

interface ILoginView : IView {
    fun navToOtp()

}
