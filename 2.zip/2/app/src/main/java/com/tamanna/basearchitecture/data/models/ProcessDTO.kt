package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName


data class ProcessDTO (
    @field:SerializedName("key") val key: String,
    @field:SerializedName("tabName") val tabName: String,
    @field:SerializedName("datasource") val datasource: List<Datasource>
)

data class Datasource (
    @field:SerializedName("logID") val logID: String,
    @field:SerializedName("process") val process: String,
    @field:SerializedName("formType") val formType: String,
    @field:SerializedName("location") val location: String,
    @field:SerializedName("logbookID") val logbookID: String,
    @field:SerializedName("adhocTable") val adhocTable: String,
    @field:SerializedName("description") val description: String,
    @field:SerializedName("elogbookName") val elogbookName: String,
    @field:SerializedName("pendingCount") val pendingCount: String,
    @field:SerializedName("completedCount") val completedCount: String,
    @field:SerializedName("recurrencePattern") val recurrencePattern: String
)

data class ProcessPayloadDTO (
    @field:SerializedName("userId") val userId: String,
    @field:SerializedName("roleId") val roleId: String,
    @field:SerializedName("Process") val process: String
        )