package com.tamanna.basearchitecture.ui.base

import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.LayoutRes
import androidx.appcompat.widget.Toolbar
import androidx.core.content.res.ResourcesCompat
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.Fragment
import com.laalsa.laalsalib.utilcode.util.ClickUtils
import com.laalsa.laalsalib.utilcode.util.ToastUtils
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.data.models.base.APIConstant
import com.tamanna.basearchitecture.ui.base.actiondialog.ActionDialog
import com.tamanna.basearchitecture.ui.helper.AlerterHelper
import com.tamanna.basearchitecture.util.IConstants
import com.tamanna.basearchitecture.util.viewutils.YumUtil
import org.koin.android.ext.android.inject


abstract class BaseFragment<B : ViewDataBinding, T : BaseViewModel<IView>> : Fragment(), IView {

    open val toolbarId: Int = R.id.main_toolbar
    open lateinit var bd: B
    abstract val fvm: T
    var toolBar: Toolbar? = null

    private var baseActivity: BaseActivity<*, *>? = null
    private var fragmentView: View? = null
    private val mClickListener = View.OnClickListener { v -> onDebounceClick(v) }

    @LayoutRes
    abstract fun getLayoutId(): Int

    abstract fun onFragmentReady(view: View)

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is BaseActivity<*, *>) {
            baseActivity = context
        }
    }

    override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        bd = DataBindingUtil.inflate(inflater, getLayoutId(), container, false)
        bd.lifecycleOwner = this
        fragmentView = bd.root
        fvm.attachView(this)
        onFragmentReady(bd.root)

        return fragmentView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        toolBar = requireActivity().findViewById<Toolbar>(toolbarId)
        YumUtil.hideKeyboard(requireActivity())
    }

    open fun applyDebounceClickListener(vararg views: View?) {
        ClickUtils.applyGlobalDebouncing(views, mClickListener)
        ClickUtils.applyPressedViewScale(*views)
    }

    override fun showProgressBar() {
        baseActivity?.showProgressBar()
    }

    override fun onDestroy() {
        baseActivity = null
//        bd?.lifecycleOwner = null
        super.onDestroy()

    }

    override fun hideProgressBar() {
        baseActivity?.hideProgressBar()
    }

    open fun showError(title: String?, message: String) {
        baseActivity?.showToast(title, message)
    }

    open fun showSnackBar(message: String, statusColor: Int) {
        baseActivity?.showSnackBar(message, statusColor)

    }


    open fun showAlerter(title: String, message: String?) {
        AlerterHelper.showError(requireContext(), title, message)
    }

    open fun showSuccessAlerter(title: String) {
        AlerterHelper.showToast(requireContext(), title, "")
    }

//    protected fun hideToolBar() {
//        toolBar?.let { it.isGone = true }
//    }
//
//    protected fun showToolBar() {
//        toolBar?.let { it.isGone = true }
//    }

    open fun onDebounceClick(view: View) {

    }

    override fun onResponse(code: Int?, response: Any?, title: String?, message: String) {
        if (code == APIConstant.Status.NO_NETWORK) {
            baseActivity?.networkUnavailable()
        } else
            if (response is DisplayTypeDTO) {
                when (response.displayType) {
                    IConstants.DisplayType.TOAST -> {
                        if (response.title.isNullOrEmpty())
                            displayToast(response.message)
                        else {
                            displayToast(response.title + "\n" + response.message)
                        }
                    }
                    IConstants.DisplayType.DIALOG -> {
                        ActionDialog(response.code, response.title, "\ue001", response.message, null, null).show(requireActivity().supportFragmentManager, "Dialog")
                    }
                    IConstants.DisplayType.SNACKBAR -> {
                        showSnackBar(response.message, ResourcesCompat.getColor(resources, R.color.colorGreenAccent, requireActivity().theme))
                    }
                    else -> {
                        AlerterHelper.showToast(requireContext(), response.title
                                ?: "", response.message)
                    }
                }

            } else {
                AlerterHelper.showError(requireContext(), title
                    ?: "", message)
            }

    }

    open fun displayToast(message: CharSequence) {
        ToastUtils.showLong(message)
    }

    override fun showCodeError(code: Int?, title: String?, message: String) {
        when (code) {
            APIConstant.Status.SUCCESS -> {
                AlerterHelper.showSuccess(context, title, message)
            }
            APIConstant.Status.ERROR -> {
                AlerterHelper.showError(context, title, message)
            }
            APIConstant.Status.NO_NETWORK -> {
                showSnackBar(IConstants.ResponseError.NO_INTERNET, Color.BLACK)
            }
            APIConstant.Status.SESSION_EXPIRED -> {

            }
            else -> {
                showError(null, message)
            }
        }
    }


}