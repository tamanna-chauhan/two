package com.tamanna.basearchitecture.ui.screen.mainActivity

import android.view.View
import androidx.navigation.fragment.findNavController
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.databinding.FragmentMyThreeBinding
import com.tamanna.basearchitecture.ui.base.BaseFragment
import com.tamanna.basearchitecture.ui.common.otpview.PinEditView
import com.tamanna.basearchitecture.ui.screen.mainActivity.viewModel.SprayingViewModel
import com.tamanna.basearchitecture.ui.screen.otp.IOtp
import org.koin.androidx.viewmodel.ext.android.viewModel

class KlinPFragment:  BaseFragment<FragmentMyThreeBinding, SprayingViewModel>(), IOtp,
    PinEditView.PinViewEventListener {

    override val fvm: SprayingViewModel by viewModel()


    override fun getLayoutId() = R.layout.fragment_my_three

    private val navController by lazy {
        findNavController()
    }

    override fun onFragmentReady(view: View) {
//        fvm.getErrorList().observe(this) {
//            RHandler<List<Datasource>>(this, it) {
//                showSnackBar("get response", 2)
//            }
//        }
    }


    override fun onDataEntered(pinEditView: PinEditView?, isFill: Boolean) {
    }

    override fun onResponse(code: Int?, response: Any?, title: String?, message: String) {
        super.onResponse(code, response, title, message)
    }


}