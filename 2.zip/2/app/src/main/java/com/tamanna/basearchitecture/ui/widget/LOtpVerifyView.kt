package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.LinearLayout
import com.tamanna.basearchitecture.R

import com.tamanna.basearchitecture.util.viewutils.fontutils.FontIconView

/**
 * Created by Bhupendra Kumar Sahu on 20-Aug-20.
 */
class LOtpVerifyView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : LinearLayout(context, attrs, defStyleAttr, defStyleRes) {
    val tvColor: ComponentColorTextView
    val tvHeader: ComponentHeaderTextView
    val tvDescription: ComponentDescriptionTextView
    val crossIcon: FontIconView
    val actionButton: ComponentButton
    val edtInput: ComponentTextInputEditText


    private var iconTextColor: Int? = 0
        set(value) {
            if (value == null) {
                // fontIcon.visibility = View.GONE
            } else {

                crossIcon.setTextColor(value)
            }
            field = value
        }
   private var textColor: Int? = 0
        set(value) {
            if (value == null) {
                // fontIcon.visibility = View.GONE
            } else {

                tvColor. setTextColor=value
            }
            field = value
        }


    private var colorText: String? = null
        set(value) {
            if (value == null) {
                // fontIcon.visibility = View.GONE
            } else {

                tvColor.tv_colored.text = value
                tvColor.visibility = View.VISIBLE
            }
            field = value
        }

    private var iconText: String? = null
        set(value) {
            if (value == null) {
                // fontIcon.visibility = View.GONE
            } else {

                crossIcon.text = value
                crossIcon.visibility = View.VISIBLE
            }
            field = value
        }
    private var header: String? = null
        set(value) {
            if (value == null) {
                // fontIcon.visibility = View.GONE
            } else {

                tvHeader.header = value
                tvHeader.visibility = View.VISIBLE
            }
            field = value
        }
    private var description: String? = null
        set(value) {
            if (value == null) {
                // fontIcon.visibility = View.GONE
            } else {

                tvDescription.description = value
                tvDescription.visibility = View.VISIBLE
            }
            field = value
        }
//    var inputType: Int = 0
//        set(value) {
//
//            edtInput.inputType = value
//            field = value
//        }
    var inputHint: CharSequence = ""
        set(value) {
            edtInput.inputHint = value
            field = value
        }

    init {
        clipToPadding = false
        val view = View.inflate(context, R.layout.view_otp_verify, this)
        tvHeader = view.findViewById(R.id.otp_tv_header)
        tvDescription = view.findViewById(R.id.tv_otp_description)
        tvColor = view.findViewById(R.id.tv_resend)
        crossIcon = view.findViewById(R.id.otp_icon_cross)
        actionButton = view.findViewById(R.id.otp_action_btn)
        edtInput = view.findViewById(R.id.otp_edt_input)
        val a = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.LOtpVerifyView,
            defStyleAttr,
            defStyleRes
        )
        colorText = a.getString(R.styleable.LOtpVerifyView_setText) ?: colorText
        description = a.getString(R.styleable.LOtpVerifyView_cardDescription) ?: description
        header = a.getString(R.styleable.LOtpVerifyView_cardHeader) ?: header
        inputHint = a.getString(R.styleable.LOtpVerifyView_inputTextHint) ?: inputHint
        iconText = a.getString(R.styleable.LOtpVerifyView_fontIcon) ?: iconText
        iconTextColor = a.getInt(R.styleable.LOtpVerifyView_fontIconColor, 0)
        textColor = a.getInt(R.styleable.LOtpVerifyView_colorText, 0)
      //  inputType = a.getInt(R.styleable.LOtpVerifyView_inputType,0) ?: inputType

        a.recycle()
    }
}