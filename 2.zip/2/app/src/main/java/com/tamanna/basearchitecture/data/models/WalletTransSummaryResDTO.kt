/*
 *   Created by Sourav Kumar Pandit  22 - 4 - 2020
 */

package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName


data class WalletTransSummaryResDTO(
    @field:SerializedName("transactions") val transactions: List<TransactionDTO>,
    @field:SerializedName("nextSkip") val nextSkip: Long
)

data class TransactionDTO(
    @field:SerializedName("name") val name: String,
    @field:SerializedName("amount") val amount: Double,
    @field:SerializedName("date") val date: String,
    @field:SerializedName("type") val type: String,
)
