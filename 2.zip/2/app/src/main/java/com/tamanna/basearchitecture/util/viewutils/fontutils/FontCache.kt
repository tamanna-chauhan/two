package com.tamanna.basearchitecture.util.viewutils.fontutils

import android.content.Context
import android.graphics.Typeface
import java.util.*

object FontCache {
    const val FA_FONT_REGULAR = "fonts/_Icon.ttf"
    const val FA_FONT_SOLID = "fonts/_Icon.ttf"
    const val FA_FONT_BRANDS = "fonts/_Icon.ttf"
    private val fontCache =
        Hashtable<String, Typeface?>()

    @JvmStatic
    operator fun get(context: Context, name: String): Typeface? {
        var typeface = fontCache[name]
        if (typeface == null) {
            typeface = try {
                Typeface.createFromAsset(context.assets, name)
            } catch (e: Exception) {
                return null
            }
            fontCache[name] = typeface
        }
        return typeface
    }
}