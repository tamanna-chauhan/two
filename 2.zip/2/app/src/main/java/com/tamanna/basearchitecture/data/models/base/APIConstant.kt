/*
 *   Created by Sourav Kumar Pandit  24 - 4 - 2020
 */

package com.tamanna.basearchitecture.data.models.base

interface APIConstant {
    interface Status {
        companion object {
            const val SUCCESS = 200
            const val ERROR = 500
            const val UNKNOWN = 503
            const val SESSION_EXPIRED = 1009
            const val LOADING = -1
            const val IGNORE = -2000
            const val NO_NETWORK = -404
            const val OFFLINE = -405
            const val FROM_ROOM = -406
        }
    }

    interface URL {
        companion object {
            //const val SIGN_UP_INIT = "account/signup/init"
            const val GET_LIST = "logbook/getlist"
            const val GET_ERROR_LIST = "logbook/getError"


            const val LOGIN = "account/login"
            const val LOGIN_SEND_OTP = "account/login/sendotp"
            const val SIGNUP_SEND_OTP = "account/signup/sendotp"
            const val SIGN_UP = "account/signup/complete"
            const val GET_PROFILE = "account/profile"
            const val HOME_DATA = "account/homepage"
            const val DUTY = "account/duty"
            const val EARNINGS = "account/earnings"
            const val PREVIOUS_EARNINGS = "account/previousEarnings"
            const val WEEKLY_EARNINGS = "account/weeklyEarning"
            const val PRE_WEEKLY_EARNINGS = "account/previousWeekEarnings"
            const val LOGOUT = "account/logout"
            const val SSE_ENDPOINT = "subscriptions/v1/subscribe"
            const val UPDATE_LOCATION = "account/onNewLocation"
            const val RAISED_TICKET = "account/raise/ticket"


        }

    }

    interface Code {
        companion object {
            // Account suspended
            // Session expire
            // Force logout - for multiple login attempt

            //
            val TASK_EXECUTED: Int = 4000
            const val QUERY_DATABASE = 2200
            const val USER_EXIST = 1050
            const val NEW_USER = 1060
            const val OTP_SENT_SUCCESS =
                2251 // Code required when otp sent successfully - redirect otp screen
            const val ACCOUNT_INACTIVE = 2050
            const val WALLET_NOT_FOUND = 3050
            const val EXCEEDS_WALLET_BALANCE = 3060
            const val LOGOUT_USER = 1070
            const val PROFILE_INCOMPLETE = 2051


        }
    }

}
