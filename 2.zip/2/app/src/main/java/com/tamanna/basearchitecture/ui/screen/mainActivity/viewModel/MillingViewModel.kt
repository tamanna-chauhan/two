package com.tamanna.basearchitecture.ui.screen.mainActivity.viewModel

import com.tamanna.basearchitecture.data.models.Datasource
import com.tamanna.basearchitecture.ui.base.BaseViewModel
import com.tamanna.basearchitecture.ui.screen.mainActivity.Fragment2Interface
import com.tamanna.basearchitecture.ui.screen.mainActivity.data.MainRepository

class MillingViewModel constructor(private val repository: MainRepository) :
    BaseViewModel<Fragment2Interface>(){

    val elogMap: MutableMap<String, List<Datasource>> = mutableMapOf()

    fun getList(userId: String, roleId: String, process: String) =
        repository.getList(userId, roleId, process)

    fun getErrorList() =
        repository.getErrorList()

}