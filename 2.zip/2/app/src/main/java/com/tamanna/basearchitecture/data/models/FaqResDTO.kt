package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName

/**
 * Created by Bhupendra Kumar Sahu on 10-Feb-21.
 */
data class FaqResDTO(
    @field:SerializedName("faq") val faq: List<FAQListDTO>
)

data class FAQListDTO
    (

    @field:SerializedName("headingId") val headingId: Long,
    @field:SerializedName("title") val title: String,
    @field:SerializedName("subItems") val subItems: List<FAQSubItemDTO>

)

data class FAQSubItemDTO
    (

    @field:SerializedName("subItemId") val subItemId: Long,
    @field:SerializedName("question") val question: String,
    @field:SerializedName("answer") val answer: String

)
