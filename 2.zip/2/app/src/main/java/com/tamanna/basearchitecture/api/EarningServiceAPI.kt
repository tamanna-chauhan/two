/*
 *   Created by Sourav Kumar Pandit  28 - 4 - 2020
 */

package com.tamanna.basearchitecture.api

import com.tamanna.basearchitecture.data.models.EarningsResDTO
import com.tamanna.basearchitecture.data.models.PreviousEarningsResDTO
import com.tamanna.basearchitecture.data.models.PreviousWeekEarningsResDTO
import com.tamanna.basearchitecture.data.models.WeeklyEarningsResDTO
import com.tamanna.basearchitecture.data.models.base.APIConstant
import com.tamanna.basearchitecture.data.models.base.ResponseDTO
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query


interface EarningServiceAPI {
    @GET(APIConstant.URL.EARNINGS)
    suspend fun dailyEarningsDetails(
        @Query("tamannaId") tamannaId: String,
        @Query("currentDate") currentDate: String
    ): Response<ResponseDTO<EarningsResDTO>>

    @GET(APIConstant.URL.WEEKLY_EARNINGS)
    suspend fun weeklyEarningsDetails(
        @Query("tamannaId") tamannaId: String,
        @Query("currentDate") currentDate: String
    ): Response<ResponseDTO<WeeklyEarningsResDTO>>

    @GET(APIConstant.URL.PRE_WEEKLY_EARNINGS)
    suspend fun previousWeekEarnings(
        @Query("tamannaId") tamannaId: String,
        @Query("week") week: Int
    ): Response<ResponseDTO<PreviousWeekEarningsResDTO>>

    @GET(APIConstant.URL.PREVIOUS_EARNINGS)
    suspend fun previousEarnings(
        @Query("tamannaId") tamannaId: String,
        @Query("currentDate") currentDate: String,
        @Query("skip") skip: Int,
        @Query("limit") limit: Int,
    ): Response<ResponseDTO<PreviousEarningsResDTO>>


}
