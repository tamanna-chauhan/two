package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.LinearLayout
import android.widget.TextView
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.databinding.ViewTripCardBinding
import com.tamanna.basearchitecture.ui.helper.bindIsGone
import com.tamanna.basearchitecture.ui.helper.hideEmptyTextView

/**
 * Created by Bhupendra Kumar Sahu on 20-Aug-20.
 */
class LTripCard : LinearLayout {

    val vbd by lazy {
        val layoutInflater = LayoutInflater.from(context)
        ViewTripCardBinding.inflate(
            layoutInflater,
            this,
            true
        )
    }
    var date: CharSequence? = null
        set(value) {
            field = value
            vbd.tvTripTime.tv_description.hideEmptyTextView(field)

        }
    var name: CharSequence? = null
        set(value) {
            field = value
            vbd.tvRestName.tv_header.hideEmptyTextView(field)

        }

    var status: CharSequence? = null
        set(value) {
            field = value
            vbd.tvTripStatus.tv_colored.hideEmptyTextView(field)

        }

    //    var totAmount: CharSequence? = null
//        set(value) {
//            field = value
//            vbd.tvTripAmount.tv_header.hideEmptyTextView(field)
//
//        }
    var textColor: Int = 0
        set(value) {
            field = value
            vbd.tvTripStatus.tv_colored.setTextColor(field)

        }
    var showLeftIcon: Boolean = false
        set(value) {
            field = value
            vbd.llLeft.bindIsGone(!field)
        }

    var icon: String? = null
        set(value) {
            field = value
            vbd.iconTrip.hideEmptyTextView(field)
        }

    var iconColor: Int = 0
        set(value) {
            field = value
            vbd.iconTrip.setTextColor(field)
        }

    var iconBackColor: Int = 0
        set(value) {
            field = value
            vbd.iconBackColor.setTextColor(field)

        }

    fun getTextStatusId(): TextView {
        return vbd.tvTripStatus.tv_colored
    }

    constructor(context: Context) : this(context, null, 0)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {

        if (attrs != null) {
            val a =
                context.obtainStyledAttributes(
                    attrs,
                    R.styleable.LTripCard,
                    defStyleAttr,
                    0
                )
            date = a.getString(R.styleable.LTripCard_cardDescription) ?: date
            name = a.getString(R.styleable.LTripCard_cardTitle) ?: name
            status = a.getString(R.styleable.LTripCard_cardHeader) ?: status
            // totAmount = a.getString(R.styleable.LTripCard_tripAmount) ?: totAmount
            icon = a.getString(R.styleable.LTripCard_fontIcon) ?: icon
            textColor = a.getInt(R.styleable.LTripCard_colorText, 0)
            iconColor = a.getInt(R.styleable.LTripCard_fontIconColor, 0)
            iconBackColor = a.getInt(R.styleable.LTripCard_backColor, 0)
            showLeftIcon = a.getBoolean(R.styleable.LTripCard_showIcon, false)
            a.recycle()
        }
    }

    fun setPrice(price: Double) {
        vbd.tvTripAmount.setPriceValue(price)
    }
}
