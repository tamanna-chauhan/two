package com.tamanna.basearchitecture.ui.screen.mainActivity

import com.tamanna.basearchitecture.ui.base.IView

interface Fragment2Interface: IView {


}