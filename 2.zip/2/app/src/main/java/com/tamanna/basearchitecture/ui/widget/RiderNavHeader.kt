package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.FrameLayout
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.databinding.ViewRiderHeaderBinding
import com.tamanna.basearchitecture.ui.helper.invisibleEmptyTextView

/**
 * Composite view to show an item containing a text label and a [ColorDotView].
 */
class RiderNavHeader @JvmOverloads constructor(
        context: Context,
        attrs: AttributeSet? = null,
        defStyleAttr: Int = 0,
        defStyleRes: Int = 0
) : FrameLayout(context, attrs, defStyleAttr, defStyleRes) {

    private val vbd by lazy {
        ViewRiderHeaderBinding.inflate(LayoutInflater.from(context), this, true)
    }
    var name: String? = ""
        set(value) {
            field = value
            vbd.tvProfileName.invisibleEmptyTextView(value)
        }

    var profileStatus: Int = -1
        set(value) {
            field = value
            if (profileStatus >= 0)
                vbd.profileProgress.progress = profileStatus
        }
//
//    private var attributeText: String = ""
//        set(value) {
//
//            vbd.colorAttribute.text = value
//            field = value
//        }
//
//    private var dotFillColor: Int = Color.LTGRAY
//        set(value) {
//            vbd.colorDot.fillColor = value
//            field = value
//        }
//
//    private var dotStrokeColor: Int = Color.DKGRAY
//        set(value) {
//            vbd.colorDot.strokeColor = value
//            field = value
//        }

    init {

        val a = context.theme.obtainStyledAttributes(
                attrs,
                R.styleable.ColorAttributeView,
                defStyleAttr,
                defStyleRes
        )

//        attributeText = a.getString(
//            R.styleable.ColorAttributeView_android_text
//        ) ?: attributeText
//        dotFillColor = a.getColor(R.styleable.ColorAttributeView_colorFillColor, dotFillColor)
//        dotStrokeColor = a.getColor(
//            R.styleable.ColorAttributeView_colorStrokeColor,
//            dotStrokeColor
//        )
        a.recycle()
    }
}
