package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.LinearLayout
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.databinding.ViewNotificationCardBinding
import com.tamanna.basearchitecture.ui.helper.hideEmptyTextView

/**
 * Created by Bhupendra Kumar Sahu on 20-Aug-20.
 */
class LNotificationCard : LinearLayout {

    val vbd by lazy {
        val layoutInflater = LayoutInflater.from(context)
        ViewNotificationCardBinding.inflate(
            layoutInflater,
            this,
            true
        )
    }

    var header: CharSequence? = null
        set(value) {
            field = value
            vbd.tvMessage.tv_header.hideEmptyTextView(field)

        }
    var description: CharSequence? = null
        set(value) {
            field = value
            vbd.tvDateTime.tv_description.hideEmptyTextView(field)

        }


    constructor(context: Context) : this(context, null, 0)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {

        if (attrs != null) {
            val a =
                context.obtainStyledAttributes(
                    attrs,
                    R.styleable.LNotificationCard,
                    defStyleAttr,
                    0
                )
            header = a.getString(R.styleable.LNotificationCard_cardHeader) ?: header
            description = a.getString(R.styleable.LNotificationCard_cardDescription) ?: description

            a.recycle()
        }
    }
}
