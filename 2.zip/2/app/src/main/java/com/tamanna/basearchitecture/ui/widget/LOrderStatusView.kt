package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.LinearLayout
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.databinding.ViewOrderStatusCardBinding
import com.tamanna.basearchitecture.ui.helper.hideEmptyTextView

/**
 * Created by Bhupendra Kumar Sahu on 20-Aug-20.
 */
class LOrderStatusView : LinearLayout {


    var description: CharSequence? = null
        set(value) {
            field = value
            vbd.tvTime.tv_description.hideEmptyTextView(field)

        }

    var title: CharSequence? = null
        set(value) {
            field = value
            vbd.tvTitle.tv_colored.hideEmptyTextView(field)

        }

    var iconColor: Int = 0
        set(value) {
            field = value
            vbd.iconColor.setTextColor(field)
            vbd.tvTitle.tv_colored.setTextColor(field)
        }

    var iconBackColor: Int = 0
        set(value) {
            field = value
            vbd.iconBackColor.setTextColor(field)

        }
    private val vbd by lazy {
        val layoutInflater = LayoutInflater.from(context)
        ViewOrderStatusCardBinding.inflate(
            layoutInflater,
            this,
            true
        )
    }

    constructor(context: Context) : this(context, null, 0)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {

        if (attrs != null) {
            val a =
                context.obtainStyledAttributes(
                    attrs,
                    R.styleable.LOrderStatusView,
                    defStyleAttr,
                    0
                )
            description = a.getString(R.styleable.LOrderStatusView_cardDescription) ?: description
            title = a.getString(R.styleable.LOrderStatusView_cardHeader) ?: title
            iconColor = a.getInt(R.styleable.LOrderStatusView_fontIconColor, 0)
            iconBackColor = a.getInt(R.styleable.LOrderStatusView_backColor, 0)
            a.recycle()
        }
    }
}
