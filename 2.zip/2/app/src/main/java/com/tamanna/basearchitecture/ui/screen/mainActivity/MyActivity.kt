package com.tamanna.basearchitecture.ui.screen.mainActivity

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.CompoundButton
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.core.view.GravityCompat
import androidx.navigation.Navigation
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.NavigationUI
import androidx.navigation.ui.navigateUp
import com.google.android.material.navigation.NavigationView
import com.laalsa.laalsalib.utilcode.util.ToastUtils
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.databinding.ActivityMyBinding
import com.tamanna.basearchitecture.pref.AppPref
import com.tamanna.basearchitecture.ui.base.BaseActivity
import com.tamanna.basearchitecture.ui.screen.mainActivity.viewModel.MainViewModel
import com.tamanna.basearchitecture.ui.screen.setting.ChangeLanguageSheet
import com.tamanna.basearchitecture.util.IConstants
import org.koin.androidx.viewmodel.ext.android.viewModel


@SuppressLint("LogNotTimber")
class MyActivity : BaseActivity<ActivityMyBinding, MainViewModel>(), IMainView,
    NavigationView.OnNavigationItemSelectedListener {

    private lateinit var appBarConfiguration: AppBarConfiguration

    private val navController by lazy { findNavController(R.id.nav_host_fragment) }

    override val vm: MainViewModel by viewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        this.bindView(R.layout.activity_my)
        setSupportActionBar(bd.mainContainer.mainToolbar)

        setupNavigationController()

        bd.navView.setNavigationItemSelectedListener(this)

        val actionBarDrawerToggle: ActionBarDrawerToggle = object : ActionBarDrawerToggle(
            this,
            bd.drawerLayout,
            null,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        ) {
            override fun onDrawerOpened(drawerView: View) {
                super.onDrawerOpened(drawerView)
                //TODO do something.
            }
        }

        //Setting the actionbarToggle to drawer layout
        bd.drawerLayout.addDrawerListener(actionBarDrawerToggle)


        //calling sync state is necessary or else your hamburger icon wont show up
        actionBarDrawerToggle.syncState()

    }

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }

    private fun setupNavigationController() {
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
//        mToolbar = findViewById<View>(R.id.toolbar) as Toolbar
        setSupportActionBar(bd.mainContainer.mainToolbar)
        supportActionBar!!.setDisplayShowHomeEnabled(true)
        appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.nav_milling_fragment,
                R.id.nav_spraying_fragment,
                R.id.nav_powder_fragment,
                R.id.nav_my_glazeline_fragment,
                R.id.nav_glazeprep_fragment,
                R.id.nav_klin_fragment,
                R.id.nav_polishing_fragment,
                R.id.nav_sorting_fragment,
                R.id.bottom_home,
                R.id.bottom_cashflow,
                R.id.bottom_history,
                R.id.bottom_wallet,
                R.id.nav_earning,
                R.id.nav_demand_area,
                R.id.nav_help_support,
                R.id.nav_refer_earn,
                R.id.nav_faqs,
                R.id.nav_test_fragment,
                R.id.nav_config_frament,
            ), bd.drawerLayout
        )
        val navController = Navigation.findNavController(this, R.id.nav_host_fragment)

        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration)

        NavigationUI.setupWithNavController(bd.navView, navController)

        supportActionBar!!.setDisplayHomeAsUpEnabled(true)

        navController.addOnDestinationChangedListener { controller, destination, arguments ->
            when (destination.id) {
                /*Bottom navigation and toolbar visible*/
                R.id.bottom_home,
                R.id.bottom_cashflow,
                R.id.bottom_history,
                R.id.bottom_wallet,
                R.id.nav_milling_fragment,
                R.id.nav_spraying_fragment,
                R.id.nav_powder_fragment,
                R.id.nav_my_glazeline_fragment,
                R.id.nav_glazeprep_fragment,
                R.id.nav_klin_fragment,
                R.id.nav_polishing_fragment,
                R.id.nav_sorting_fragment,
                -> {
                    bd.mainContainer.mainToolbar.visibility = View.VISIBLE

                }
                /*Bottom navigation and toolbar gone*/
                R.id.nav_refer_earn -> {
                    bd.mainContainer.mainToolbar.visibility = View.GONE
                }

                /*Bottom navigation gone  and toolbar visible*/
                else -> {

                }
            }
        }
    }


    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        val closeDrawer = true

        when (item.itemId) {
            R.id.nav_duty_status -> return false
            R.id.nav_dark -> return false
            R.id.nav_sign_out -> {
                ToastUtils.showShort("SignOut Click")
            }
            R.id.nav_language -> {
                val clFragmentManager = supportFragmentManager
                val changeLang = ChangeLanguageSheet()
//                changeLang.actionHandler = this
                changeLang.moduleId = IConstants.ActionModule.CHANGE_LANGUAGE
                changeLang.show(clFragmentManager, "Change Language")
            }
//            R.id.nav_test_fragment -> navController.navigate(R.id.nav_test_fragment)
            R.id.nav_config_frament -> {
                AppPref.baseUrl = ""
                val baseUrl = AppPref.baseUrl
//                navController.navigate(R.id.nav_config_frament)
                IConstants.BASE_URL = baseUrl
            }

            R.id.nav_milling_fragment -> {
                navController.navigate(R.id.nav_milling_fragment)
            }
            R.id.nav_spraying_fragment -> {
                navController.navigate(R.id.nav_spraying_fragment)
            }
            R.id.nav_powder_fragment -> {
                navController.navigate(R.id.nav_powder_fragment)
            }
            R.id.nav_my_glazeline_fragment -> {
                navController.navigate(R.id.nav_my_glazeline_fragment)
            }
            R.id.nav_glazeprep_fragment -> {
                navController.navigate(R.id.nav_glazeprep_fragment)
            }
            R.id.nav_klin_fragment -> {
                navController.navigate(R.id.nav_klin_fragment)
            }
            R.id.nav_polishing_fragment -> {
                navController.navigate(R.id.nav_polishing_fragment)
            }
            R.id.nav_sorting_fragment -> {
                navController.navigate(R.id.nav_sorting_fragment)
            }

        }
        if (closeDrawer) {
            bd.drawerLayout.closeDrawer(GravityCompat.START)
        }
        return NavigationUI.onNavDestinationSelected(item, navController) ||
                super.onOptionsItemSelected(item)


    }


    override fun onCheckedChanged(buttonView: CompoundButton?, isChecked: Boolean) {

    }

    override fun onSuccess(actionId: Int, data: Any?) {

    }
}
