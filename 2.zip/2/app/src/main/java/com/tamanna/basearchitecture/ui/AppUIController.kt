package com.tamanna.basearchitecture.ui

import androidx.appcompat.app.AppCompatActivity
import com.laalsa.laalsalib.utilcode.util.ActivityUtils

object AppUIController {
    private val topActivity: AppCompatActivity
        get() = ActivityUtils.getTopActivity() as AppCompatActivity

}