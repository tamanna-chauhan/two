package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.LinearLayout
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.databinding.ViewDeliveryStatusCardBinding

/**
 * Created by Bhupendra Kumar Sahu on 20-Aug-20.
 */
class LDeliveryStatusCardView : LinearLayout {

    var orderNo: CharSequence? = ""
        set(value) {
            field = value
            vbd.tvOrderNo.description = field.toString()
        }

    var restaurantName: CharSequence? = ""
        set(value) {
            field = value
            vbd.tvRestaurantName.title = field.toString()
        }
    var status: CharSequence? = null
        set(value) {
            field = value
            vbd.tvDeliveryStatus.setText = field.toString()
        }

    var icon: CharSequence? = null
        set(value) {
            field = value
            vbd.icon.text = field.toString()
        }

    var iconColor: Int = 0
        set(value) {

            field = value
            vbd.icon.setTextColor(value)
            vbd.tvDeliveryStatus.setTextColor = value
        }


    private val vbd by lazy {
        val layoutInflater = LayoutInflater.from(context)
        ViewDeliveryStatusCardBinding.inflate(
            layoutInflater,
            this,
            true
        )
    }

    constructor(context: Context) : this(context, null, 0)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {

        if (attrs != null) {
            val a = context.theme.obtainStyledAttributes(
                attrs,
                R.styleable.LDeliveryStatusCardView,
                defStyleAttr,
                0
            )
            orderNo = a.getString(R.styleable.LDeliveryStatusCardView_cardDescription) ?: orderNo
            restaurantName =
                a.getString(R.styleable.LDeliveryStatusCardView_cardHeader) ?: restaurantName
            status = a.getString(R.styleable.LDeliveryStatusCardView_setText) ?: status
            icon = a.getString(R.styleable.LDeliveryStatusCardView_fontIcon) ?: icon
            iconColor = a.getInt(R.styleable.LDeliveryStatusCardView_fontIconColor, 0)
            a.recycle()
        }
    }
}
