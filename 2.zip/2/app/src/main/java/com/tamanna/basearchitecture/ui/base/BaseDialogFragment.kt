package com.tamanna.basearchitecture.ui.base

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.view.*
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.res.ResourcesCompat
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentManager
import com.google.android.material.snackbar.Snackbar
import com.laalsa.laalsalib.ui.VUtil
import com.laalsa.laalsalib.ui.px
import com.laalsa.laalsalib.utilcode.util.ClickUtils
import com.laalsa.laalsalib.utilcode.util.ToastUtils
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.data.models.base.APIConstant
import com.tamanna.basearchitecture.ui.CodeColor
import com.tamanna.basearchitecture.ui.base.actiondialog.ActionDialog
import com.tamanna.basearchitecture.ui.helper.AlerterHelper
import com.tamanna.basearchitecture.ui.helper.ThemeConstant
import com.tamanna.basearchitecture.util.IConstants
import com.tamanna.basearchitecture.util.viewutils.YumUtil
import timber.log.Timber

abstract class BaseDialogFragment<B : ViewDataBinding> : DialogFragment(), IModuleHandler {

    var moduleId: Int = 0

    open var actionHandler: IModuleHandler? = null
    open lateinit var bd: B

    private lateinit var dialogView: ViewGroup

    var handler: Handler? = null
    var update: Runnable? = null

    private lateinit var mProgressBar: ProgressBar
    private lateinit var frameLayout: FrameLayout
    private var baseActivity: BaseActivity<*, *>? = null


    private val mClickListener =
        View.OnClickListener { v -> onDebounceClick(v) }

    override fun onCreate(savedInstanceState: Bundle?) {
        setStyle(STYLE_NO_FRAME, R.style.FullScreenDialogStyle)
        super.onCreate(savedInstanceState)
        baseActivity = requireActivity() as BaseActivity<*, *>
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        bd = DataBindingUtil.inflate(inflater, getLayoutId(), container, false)
        dialogView = bd.root as ViewGroup
        dialogView.addView(initFrame())
        return bd.root
    }

    private fun initFrame(): FrameLayout {
        frameLayout = FrameLayout(requireContext())
        val frameParam = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        frameLayout.layoutParams = frameParam
        frameLayout.background = null
        mProgressBar = ProgressBar(requireContext())
        mProgressBar.background = null
        mProgressBar.visibility = View.GONE
        val pbParam: FrameLayout.LayoutParams = FrameLayout.LayoutParams(45.px, 45.px)
        pbParam.gravity = Gravity.CENTER
        mProgressBar.layoutParams = pbParam
        mProgressBar.setPadding(3.px, 3.px,3.px,3.px,)
        frameLayout.addView(mProgressBar)
        return frameLayout

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        onDialogReady(view)
        YumUtil.hideDialogKeyboard(dialog!!)

    }

    fun applyDebouchingClickListener(vararg views: View?) {
        ClickUtils.applySingleDebouncing(views, mClickListener)
        ClickUtils.applyPressedViewScale(*views)
    }

    protected fun hideSoftKeyboard(activity: Activity) {
        activity.window.setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
        )
    }

    private fun showProgressBar(visibility: Boolean) {
        mProgressBar.visibility = if (visibility) View.VISIBLE else View.INVISIBLE
//        if (visibility) frameLayout.setBackgroundColor(0x3CFFFFFF) else frameLayout.background =
//            null
        frameLayout.isClickable = visibility
    }

    override fun hideProgressBar() {
        showProgressBar(false)
    }

    override fun showProgressBar() {
        showProgressBar(true)

    }

    open fun displayToast(message: CharSequence) {
        ToastUtils.showLong(message)
    }

    override fun onResponse(code: Int?, response: Any?, title: String?, message: String) {
        if (code == APIConstant.Status.NO_NETWORK) {
            baseActivity?.networkUnavailable()
        } else
            if (response is DisplayTypeDTO) {
                when (response.displayType) {
                    IConstants.DisplayType.TOAST -> {
                        if (response.title.isNullOrEmpty())
                            displayToast(response.message)
                        else {
                            displayToast(response.title + "\n" + response.message)
                        }
                    }
                    IConstants.DisplayType.DIALOG -> {
                        ActionDialog(response.code, response.title, "\ue001", response.message, null, null).show(requireActivity().supportFragmentManager, "Dialog")
                    }
                    IConstants.DisplayType.SNACKBAR -> {
                        showSnackBar(response.message, ResourcesCompat.getColor(resources, R.color.colorGreenAccent, requireActivity().theme))
                    }
                    else -> {
                        AlerterHelper.showToast(requireContext(), response.title
                                ?: "", response.message)
                    }
                }

            }

    }

    override fun showCodeError(code: Int?, title: String?, message: String) {
        val codeColor = CodeColor.COLOR_CODE.getCodeColor(code)
        if (codeColor == null) {
            showToast(message)
            return
        }
        when (code) {
            APIConstant.Status.NO_NETWORK -> {

            }
            APIConstant.Status.SESSION_EXPIRED -> {

            }
            else -> {
                showSnackBar(message, Color.RED)
            }
        }


    }

    override fun show(manager: FragmentManager, tag: String?) {
        try {
            val ft = manager.beginTransaction()
            ft.add(this, tag)
            ft.commitAllowingStateLoss()
        } catch (e: IllegalStateException) {
            Timber.d("Exception: ${e}")
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()

    }


    open fun showSnackBar(message: String, statusColor: Int = Color.BLACK) {
        val snackBar = Snackbar.make(dialogView, message, Snackbar.LENGTH_SHORT)
        val viewGroup = snackBar.view as ViewGroup
        viewGroup.minimumHeight = VUtil.dpToPx(0)
        viewGroup.getChildAt(0).background = null
        viewGroup.background = ColorDrawable(Color.BLACK)
        val textView = (viewGroup.getChildAt(0) as ViewGroup).getChildAt(0) as TextView
        textView.background = null
        textView.setTextColor(ThemeConstant.white)
        snackBar.setActionTextColor(Color.WHITE)
//        ViewCompat.setOnApplyWindowInsetsListener(snackBar.view, null)
        snackBar.show()
    }

    open fun showError(title: String?, error: String?) {
        AlerterHelper.showError(requireContext(), title ?: "Ops! Something happened", error ?: "")
    }

    open fun onDebounceClick(view: View) {

    }

    override fun onSuccess(actionId: Int, data: Any?) {

    }

    abstract fun getLayoutId(): Int

    abstract fun onDialogReady(view: View)

}