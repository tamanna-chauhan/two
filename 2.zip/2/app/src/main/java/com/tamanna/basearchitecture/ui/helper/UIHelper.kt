package com.tamanna.basearchitecture.ui.helper

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.ViewAnimationUtils
import android.view.ViewGroup
import android.widget.*
import androidx.annotation.DrawableRes
import com.laalsa.laalsalib.ui.VUtil
import com.laalsa.laalsalib.ui.pxf
import com.laalsa.laalsaui.utils.ColorHelper
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.util.ViewConst
import com.tamanna.basearchitecture.util.viewutils.fontutils.FontIconView
import kotlin.math.hypot


object UIHelper {



    private fun changeButtonPropety(filledButton: Button) {
        val param = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        filledButton.minHeight = 0
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            filledButton.stateListAnimator = null
            filledButton.elevation = 0f
        }
        filledButton.minWidth = 0
        filledButton.minimumHeight = 0
        filledButton.minimumWidth = 0
        filledButton.layoutParams = param
    }

    fun roundedShadeDrawable(
        color1: Int = 0xFFFFC04C.toInt(),
    ) = roundedShadeDrawable(
        color1,
        ColorHelper.darkenColor(color1, 0.2f),
    )

    fun roundedShadeDrawable(
        color1: Int = 0xFFFFC04C.toInt(),
        color2: Int = 0xFFFF7C18.toInt(),
    ): GradientDrawable {
        val ovalDrawable =
            GradientDrawable(GradientDrawable.Orientation.BL_TR, intArrayOf(color1, color2))
        ovalDrawable.setGradientCenter(0.0f, 0.0f)
        ovalDrawable.shape = GradientDrawable.OVAL
        ovalDrawable.gradientType = GradientDrawable.LINEAR_GRADIENT
        return ovalDrawable
    }

    fun roundColoredDrawable(): GradientDrawable {
        val buttonBackground1 = GradientDrawable()
        buttonBackground1.cornerRadius = 8.pxf
        buttonBackground1.setStroke(2, ThemeConstant.pinkies)
        buttonBackground1.setColor(ThemeConstant.pinkies)
        return buttonBackground1
    }

    fun roundStrokedDrawable(color: Int = ThemeConstant.pinkies): GradientDrawable {
        val buttonBackground2 = GradientDrawable()
        buttonBackground2.cornerRadius = 8.pxf
        buttonBackground2.setStroke(2, color)
        buttonBackground2.setColor(ThemeConstant.white)
        return buttonBackground2
    }

    fun getStrokeDoted(
        strokeWidth: Int,
        color: Int,
        dashWidth: Float,
        dashGap: Float
    ): GradientDrawable {
        val storkDrawable = GradientDrawable()

        storkDrawable.shape = GradientDrawable.LINE
        storkDrawable.setStroke(strokeWidth, color, dashWidth, dashGap)
        return storkDrawable
    }

    fun roundDotedGreenStrokedDrawable(
        strokeWidth: Int,
        color: Int,
        backColor: Int,
        dashWidth: Float,
        dashGap: Float
    ): GradientDrawable {
        val strokDrawable = GradientDrawable()
        strokDrawable.cornerRadius = 8.pxf
        strokDrawable.setStroke(strokeWidth, color, dashWidth, dashGap)
        strokDrawable.setColor(backColor)
        return strokDrawable
    }


    fun getStrokeDrawable(strokeColor: Int, rounded: Float, strokeWidth: Int): Drawable {
        val drawable = GradientDrawable()
        drawable.cornerRadius = rounded
        drawable.setStroke(strokeWidth, strokeColor)
        return drawable

    }

    fun showNoDataToDisplay(requireContext: Context): LinearLayout {
        val layout = LinearLayout(requireContext)
        layout.layoutParams =
            LinearLayout.LayoutParams(ViewConst.MATCH_PARENT, ViewConst.MATCH_PARENT)
        layout.orientation = LinearLayout.VERTICAL
        layout.gravity = Gravity.CENTER
        val fontIconView = FontIconView(requireContext)
        fontIconView.layoutParams = LinearLayout.LayoutParams(VUtil.dpToPx(100), VUtil.dpToPx(100))
        fontIconView.setText(R.string.icon_cook)
        fontIconView.setTextColor(Color.GRAY)

        val textView = TextView(requireContext)
        textView.gravity = Gravity.CENTER
        textView.layoutParams =
            LinearLayout.LayoutParams(ViewConst.MATCH_PARENT, ViewConst.WRAP_CONTENT)
        textView.text = "Sorry, Nothing Here"
        textView.setTextColor(Color.GRAY)

        layout.addView(fontIconView)
        layout.addView(textView)
        return layout

    }

    fun inviteLayout(requireContext: Context, @DrawableRes drawable: Int): LinearLayout {
        val layout = LinearLayout(requireContext)
        layout.layoutParams =
            LinearLayout.LayoutParams(ViewConst.MATCH_PARENT, ViewConst.MATCH_PARENT)
        layout.orientation = LinearLayout.VERTICAL
        layout.gravity = Gravity.CENTER
        val illsImage = ImageView(requireContext)
        illsImage.layoutParams = LinearLayout.LayoutParams(
            (VUtil.screenWidth * (0.6)).toInt(),
            (VUtil.screenWidth * 0.6).toInt()
        )

        illsImage.setImageResource(drawable)

        layout.addView(illsImage)
        return layout

    }

    fun showMessagedToDisplay(
        context: Context,
        fontIcon: Int,
        color: Int,
        label: String
    ): LinearLayout {
        val layout = LinearLayout(context)
        layout.layoutParams =
            LinearLayout.LayoutParams(ViewConst.MATCH_PARENT, ViewConst.MATCH_PARENT)
        layout.orientation = LinearLayout.VERTICAL
        layout.gravity = Gravity.CENTER
        val fontIconView = FontIconView(context)
        fontIconView.layoutParams = LinearLayout.LayoutParams(VUtil.dpToPx(100), VUtil.dpToPx(100))

        fontIconView.setText(fontIcon)
        fontIconView.setTextColor(color)

        val textView = TextView(context)
        textView.gravity = Gravity.CENTER
        textView.layoutParams =
            LinearLayout.LayoutParams(ViewConst.MATCH_PARENT, ViewConst.WRAP_CONTENT)
        textView.gravity = Gravity.CENTER
        textView.text = label
        textView.setTextColor(Color.GRAY)
        layout.addView(fontIconView)
        layout.addView(textView)
        return layout

    }

    fun showMessageWithImage(
        context: Context,
        fontIcon: Int,
        label: String
    ): LinearLayout {
        val layout = LinearLayout(context)
        layout.layoutParams =
            LinearLayout.LayoutParams(ViewConst.MATCH_PARENT, ViewConst.MATCH_PARENT)
        layout.orientation = LinearLayout.VERTICAL
        layout.gravity = Gravity.CENTER
        val fontIconView = ImageView(context)
        fontIconView.layoutParams = LinearLayout.LayoutParams(VUtil.dpToPx(100), VUtil.dpToPx(100))
        fontIconView.setImageResource(fontIcon)

        val textView = TextView(context)
        textView.gravity = Gravity.CENTER
        textView.layoutParams =
            LinearLayout.LayoutParams(ViewConst.MATCH_PARENT, ViewConst.WRAP_CONTENT)
        textView.gravity = Gravity.CENTER
        textView.text = label
        textView.setTextColor(Color.GRAY)
        layout.addView(fontIconView)
        layout.addView(textView)
        return layout

    }


    fun copyToClipboard(context: Context, data: String?) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("clipboard", data)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "Text copied to clipboard", Toast.LENGTH_SHORT).show()
    }


    fun revealInvisibleView(
        view: View,
        cx: Int = view.width / 2,
        cy: Int = view.height / 2,
        startRadius: Float = 0f,
        duration: Long = 500
    ) {
        // previously invisible view
        // Check if the runtime version is at least Lollipop
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            // get the center for the clipping circle
            // get the final radius for the clipping circle
            val finalRadius = hypot(cx.toDouble(), cy.toDouble()).toFloat()

            // create the animator for this view (the start radius is zero)
            val anim =
                ViewAnimationUtils.createCircularReveal(view, cx, cy, startRadius, finalRadius)
            // make the view visible and start the animation
            view.visibility = View.VISIBLE
            anim.setDuration(duration).start()
        } else {
            // set the view to invisible without a circular reveal animation below Lollipop
            view.visibility = View.INVISIBLE
        }
    }

    fun hideVisibleView(view: View, cx: Int = view.width / 2, cy: Int = view.height / 2) {

// Check if the runtime version is at least Lollipop
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.LOLLIPOP) {
            // get the center for the clipping circle
//            val cx = view.width / 2
//            val cy = view.height / 2
            // get the initial radius for the clipping circle
            val initialRadius = Math.hypot(cx.toDouble(), cy.toDouble()).toFloat()

            // create the animation (the final radius is zero)
            val anim = ViewAnimationUtils.createCircularReveal(view, cx, cy, initialRadius, 0f)

            // make the view invisible when the animation is done
            anim.addListener(object : AnimatorListenerAdapter() {

                override fun onAnimationEnd(animation: Animator) {
                    super.onAnimationEnd(animation)
                    view.visibility = View.INVISIBLE
                }
            })

            // start the animation
            anim.start()
        } else {
            // set the view to visible without a circular reveal animation below Lollipop
            view.visibility = View.VISIBLE
        }
    }


}