package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.LinearLayout
import androidx.appcompat.widget.AppCompatImageView
import com.laalsa.laalsalib.ui.VUtil
import com.tamanna.basearchitecture.R
import kotlin.math.roundToInt

/**
 * Created by Bhupendra Kumar Sahu on 19-Aug-20.
 */
class ComponentImageResView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : LinearLayout(context, attrs, defStyleAttr, defStyleRes) {
    val imageview: AppCompatImageView

    var imageRes: Int? = null
        set(value) {
            field = value
            if (field != null && field != -1) {

                imageview.setImageResource(field!!)
                imageview.visibility = View.VISIBLE

            } else {
                imageview.visibility = View.GONE
            }
        }
    var imageResSize: Float = VUtil.dpToPx(45).toFloat()
        set(value) {
            field = value
            imageview.maxHeight = value.roundToInt()
            imageview.maxWidth = value.roundToInt()

        }

    init {
        val view = View.inflate(context, R.layout.type_attribute_imageview_res, this)
        imageview = view.findViewById(R.id.imageview_res)

        val a = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.ComponentImageResView,
            defStyleAttr,
            defStyleRes
        )
        imageRes = a.getResourceId(
            R.styleable.ComponentImageResView_imageRes,
            -1
        )
        imageResSize = a.getDimension(R.styleable.ComponentImageResView_imageResSize, imageResSize)

    }
}