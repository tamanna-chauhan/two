package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.View
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.util.viewutils.fontutils.FontIconView

/**
 * Created by Bhupendra Kumar Sahu on 20-Aug-20.
 */
class LVerticalTextViewsWithIcon @JvmOverloads constructor(
        context: Context,
        attrs: AttributeSet? = null,
        defStyleAttr: Int = 0,
        defStyleRes: Int = 0
) : com.google.android.material.card.MaterialCardView(context, attrs, defStyleAttr) {
    val tv_order_id: ComponentTitleTextView
    val tv_customer_name: ComponentHeaderTextView
    val tv_pickup_no: ComponentDescriptionTextView
    val tv_order_status: ComponentColorTextView
    val icon_order_status: FontIconView


    var bottomLable: CharSequence = ""
        set(value) {
            if (value == null) {
                tv_order_id.visibility = View.INVISIBLE
                tv_order_id.title = ""
                return
            }
            tv_order_id.title = value
            field = value
        }
    var title: CharSequence? = ""
        set(value) {
            if (value == null) {
                tv_customer_name.visibility = View.INVISIBLE
                tv_customer_name.header = ""
                return
            }
            tv_customer_name.header = value
            field = value


        }
    var topLabel: CharSequence = ""
        set(value) {
            if (value == null) {
                tv_pickup_no.visibility = View.INVISIBLE
                tv_pickup_no.description = ""
                return
            }
            tv_pickup_no.description = value
            field = value


        }
    var status: CharSequence = ""
        set(value) {
            if (value == null) {
                tv_order_status.visibility = View.GONE
                tv_order_status.tv_colored.text = ""
                return
            }
            tv_order_status.tv_colored.text = value
            field = value


        }

    var icon: String = ""
        set(value) {
            if (value == null) {
                icon_order_status.visibility = View.GONE
                icon_order_status.text = ""
                return
            }
            icon_order_status.text = value
            field = value


        }
    var iconColor: Int = 0
        set(value) {
            icon_order_status.setTextColor(value)
            tv_order_status.setTextColor = value
            field = value


        }

    init {
        clipToPadding = false
        val view = View.inflate(context, R.layout.view_vertical_textviews, this)
        tv_order_id = view.findViewById(R.id.tv_order_id)
        tv_customer_name = view.findViewById(R.id.tv_customer_name)
        tv_pickup_no = view.findViewById(R.id.tv_pickup_no)
        tv_order_status = view.findViewById(R.id.tv_order_status)
        icon_order_status = view.findViewById(R.id.icon_order_status)


        val a = context.theme.obtainStyledAttributes(
                attrs,
                R.styleable.LVerticalTextViewsWithIcon,
                defStyleAttr,
                defStyleRes
        )
        bottomLable = a.getString(R.styleable.LVerticalTextViewsWithIcon_cardTitle) ?: bottomLable
        title = a.getString(R.styleable.LVerticalTextViewsWithIcon_cardSubTitle)
                ?: title
        topLabel = a.getString(R.styleable.LVerticalTextViewsWithIcon_cardHeader) ?: topLabel
        status = a.getString(R.styleable.LVerticalTextViewsWithIcon_pickupStatus) ?: status
        icon = a.getString(R.styleable.LVerticalTextViewsWithIcon_fontIcon) ?: icon
        iconColor = a.getInt(R.styleable.LVerticalTextViewsWithIcon_fontIconColor, 0)
        a.recycle()
    }
}
