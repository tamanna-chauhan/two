package com.tamanna.basearchitecture.pref

import com.chibatching.kotpref.KotprefModel

/**
 * Created by Bhupendra Kumar Sahu on 10-Feb-21.
 */
object RiderInfo : KotprefModel() {
    var accessToken by nullableStringPref("Bearar djdjjfhjvjd243drvfvf")
    var name by stringPref(default = "")
    var tamannaId by stringPref(default = "")
    var operationalStatus by booleanPref(default = false)
    var mobile by stringPref("")
    var accountStatus by stringPref("")
    var photo by stringPref("")
    var email by stringPref("")
    var aadhar by stringPref("")
    var dlNo by stringPref("")
    var workingMode by stringPref("")
    var bank by stringPref("")
    var holderName by stringPref("")
    var panNo by stringPref("")
    var ifsc by stringPref("")
    var acNo by stringPref("")
    var percent by intPref(0)
    var bankDetailsComplete by booleanPref(default = false)
    var hasRaisedTicket by booleanPref(default = false)
    var raisedTicketTitle by stringPref("")
    var raisedTicketMsg by stringPref("")
}