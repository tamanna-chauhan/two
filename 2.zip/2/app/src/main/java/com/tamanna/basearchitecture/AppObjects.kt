package com.tamanna.basearchitecture

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import com.chibatching.kotpref.Kotpref
import com.google.gson.Gson
import com.laalsa.laalsalib.utilcode.util.Utils

//import com.laalsa.laalsalib.utilcode.util.Utils
//com.laalsa.laalsalib.utilcode

lateinit var appGson: Gson

@SuppressLint("MissingPermission")
class AppObjects(context: Context) {

    init {
        val application = context as Application
        appGson = Gson()
        Utils.init(application)
        Kotpref.init(application)
    }


}