package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.LinearLayout
import androidx.appcompat.widget.AppCompatTextView
import androidx.constraintlayout.widget.ConstraintLayout

import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.ui.helper.ThemeConstant

/**
 * Created by Bhupendra Kumar Sahu on 24-Aug-20.
 */
class LReferralDetailsCardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : LinearLayout(context, attrs, defStyleAttr, defStyleRes) {
    val txt_refer_prsn_name: AppCompatTextView
    val referral_status: AppCompatTextView
    val txt_city: AppCompatTextView
    val txt_prsn_no: AppCompatTextView
    val refer_date: AppCompatTextView
    val txt_total_earnd: AppCompatTextView
    val footer_layout: ConstraintLayout


    var personName: CharSequence? = ""
        set(value) {
            if (value == null) {
                txt_refer_prsn_name.visibility = View.INVISIBLE
                txt_refer_prsn_name.text = ""
                return
            }
            txt_refer_prsn_name.text = value
            field = value
        }
    var setColor: Int? = 0
        set(value) {
            if (value == 0) {
                referral_status.setTextColor(ThemeConstant.alphaBlackColor)
                return
            }
            value?.let { referral_status.setTextColor(it) }
            field = value
        }
    var referralStatus: CharSequence? = ""
        set(value) {
            if (value == null) {
                referral_status.visibility = View.INVISIBLE
                referral_status.text = ""
                return
            }
            referral_status.text = value
            field = value
        }

    var city: CharSequence? = ""
        set(value) {
            if (value == null) {
                txt_city.visibility = View.INVISIBLE
                txt_city.text = ""
                return
            }
            txt_city.text = value
            field = value
        }
    var personNo: CharSequence? = ""
        set(value) {
            if (value == null) {
                txt_prsn_no.visibility = View.INVISIBLE
                txt_prsn_no.text = ""
                return
            }
            txt_prsn_no.text = value
            field = value
        }
    var referDate: CharSequence? = ""
        set(value) {
            if (value == null) {
                refer_date.visibility = View.INVISIBLE
                refer_date.text = ""
                return
            }
            refer_date.text = value
            field = value
        }
    var totalEarnd: CharSequence? = ""
        set(value) {
            if (value == null) {
                txt_total_earnd.visibility = View.INVISIBLE
                txt_total_earnd.text = ""
                return
            }
            txt_total_earnd.text = value
            field = value
        }

    var showFooterView: Boolean = false
        set(value) {
            if (value) {
                footer_layout.visibility = View.VISIBLE
            }
            else
            {
                footer_layout.visibility = View.GONE

        }
            field = value
        }


    init {
        clipToPadding = false
        orientation = VERTICAL
        val view = View.inflate(context, R.layout.view_referral_details_card, this)
        txt_refer_prsn_name = view.findViewById(R.id.txt_refer_prsn_name)
        referral_status = view.findViewById(R.id.referral_status)
        txt_city = view.findViewById(R.id.txt_city)
        txt_prsn_no = view.findViewById(R.id.txt_prsn_no)
        refer_date = view.findViewById(R.id.refer_date)
        txt_total_earnd = view.findViewById(R.id.txt_total_earnd)
        footer_layout = view.findViewById(R.id.footer_layout)


        val a = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.LReferralDetailsCardView,
            defStyleAttr,
            defStyleRes
        )
        referralStatus =
            a.getString(R.styleable.LReferralDetailsCardView_referralStatus) ?: referralStatus
        personName = a.getString(R.styleable.LReferralDetailsCardView_personName) ?: personName
        city = a.getString(R.styleable.LReferralDetailsCardView_city) ?: city
        personNo = a.getString(R.styleable.LReferralDetailsCardView_personNo) ?: personNo
        referDate = a.getString(R.styleable.LReferralDetailsCardView_referDate) ?: referDate
        totalEarnd = a.getString(R.styleable.LReferralDetailsCardView_referAmount) ?: totalEarnd
        setColor = a.getInt(R.styleable.LReferralDetailsCardView_colorText, 0)
        showFooterView = a.getBoolean(R.styleable.LReferralDetailsCardView_showFooter, false)
        a.recycle()
    }
}