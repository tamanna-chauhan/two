package com.tamanna.basearchitecture.ui.screen.started

import android.view.View
import androidx.navigation.fragment.findNavController
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.databinding.FragmentStartedBinding
import com.tamanna.basearchitecture.pref.RiderInfo
import com.tamanna.basearchitecture.ui.base.BaseFragment
import org.koin.androidx.viewmodel.ext.android.viewModel


class StartedFragment : BaseFragment<FragmentStartedBinding, StartedViewModel>(), IStarted {
    override val fvm: StartedViewModel by viewModel()

    override fun getLayoutId() = R.layout.fragment_started

    private val navController by lazy {
        findNavController()
    }

    override fun onFragmentReady(view: View) {
        applyDebounceClickListener(bd.btnLogin, bd.btnSignup)

        if (RiderInfo.accessToken != null) {
            if (navController.currentDestination?.id == R.id.fragment_started)
                navController.navigate(R.id.action_fragment_started_to_home)
        }

    }

    override fun onDebounceClick(view: View) {
        when (view) {
            bd.btnLogin -> {
                if (navController.currentDestination?.id == R.id.fragment_started)
                    navController.navigate(R.id.fragment_login)
            }
            bd.btnSignup -> {
                if (navController.currentDestination?.id == R.id.fragment_started)
                    navController.navigate(R.id.fragment_signup)
            }
        }
        super.onDebounceClick(view)
    }
}