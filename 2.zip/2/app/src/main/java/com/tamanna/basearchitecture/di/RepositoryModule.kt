package com.tamanna.basearchitecture.di

import com.tamanna.basearchitecture.ui.screen.mainActivity.data.MainRepository
import com.tamanna.basearchitecture.ui.screen.otp.data.OtpRepository
import com.tamanna.basearchitecture.ui.screen.signup.data.*
import org.koin.dsl.module

fun repositoryModule() = module {

    factory { LoginRepository(get()) }
    factory { SignUpRepository(get()) }
    factory { OtpRepository(get()) }

    factory { MainRepository(get()) }


}