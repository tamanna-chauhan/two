package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName

data class LoginHistoryListResDTO(
    @field:SerializedName("histories") val histories: List<HistoryListDTO>,
    @field:SerializedName("nextSkip") val nextSkip: Int,

    )

data class HistoryListDTO(
    @field:SerializedName("week") val week: Int,
    @field:SerializedName("endDate") val endDate: String,
    @field:SerializedName("startDate") val startDate: String,
    @field:SerializedName("hour") val hour: Int,
    @field:SerializedName("minutes") val minutes: Int

)
