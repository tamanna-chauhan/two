/*
 *   Created by Sourav Kumar Pandit  22 - 4 - 2020
 */

package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName


data class SendOtpDTO(
    @field:SerializedName("mobile") val mobile: String,
    @field:SerializedName("countryCode") val countryCode: String,
    @field:SerializedName("method") val method: String
)
