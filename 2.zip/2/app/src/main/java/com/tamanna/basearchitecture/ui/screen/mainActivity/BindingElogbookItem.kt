package com.tamanna.basearchitecture.ui.screen.mainActivity

import android.view.LayoutInflater
import android.view.ViewGroup
import com.mikepenz.fastadapter.binding.AbstractBindingItem
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.data.models.Datasource
import com.tamanna.basearchitecture.databinding.AdapterElogbookBinding

class BindingElogbookItem() : AbstractBindingItem<AdapterElogbookBinding>() {

    var elogBook: Datasource? = null

    override val type: Int = R.id.item_elogbook

    fun withDatasource(item: Datasource): BindingElogbookItem {
        this.elogBook = item
        return this
    }

    override fun createBinding(
        inflater: LayoutInflater,
        parent: ViewGroup?
    ): AdapterElogbookBinding {
        return AdapterElogbookBinding.inflate(inflater, parent, false)
    }

    override fun bindView(binding: AdapterElogbookBinding, payloads: List<Any>) {
        super.bindView(binding, payloads)
        attachToWindow(binding)

        binding.tvLogbookoName.text = elogBook?.elogbookName
        binding.tvSaved.text = elogBook?.pendingCount
        binding.tvSubmit.text = elogBook?.completedCount
    }

}