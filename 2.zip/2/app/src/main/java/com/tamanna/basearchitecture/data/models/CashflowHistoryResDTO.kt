/*
 *   Created by Sourav Kumar Pandit  22 - 4 - 2020
 */

package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName


data class CashflowHistoryResDTO(
    @field:SerializedName("description") val description: String?,
    @field:SerializedName("transactions") val transactions: List<CashflowHistoryListDTO>
)

data class CashflowHistoryListDTO(
    @field:SerializedName("title") val title: String,
    @field:SerializedName("date") val date: String,
    @field:SerializedName("amount") val amount: Double,
)
