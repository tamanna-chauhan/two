package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import androidx.constraintlayout.widget.ConstraintLayout
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.databinding.ViewDistanceTotalEarningBinding


class LDistanceAndLoginHrsView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : ConstraintLayout(context, attrs, defStyleAttr, defStyleRes) {
    val vbd by lazy {
        val layoutInflater = LayoutInflater.from(context)
        ViewDistanceTotalEarningBinding.inflate(layoutInflater, this, true)
    }


    //    var distanceHeader: CharSequence = ""
//        set(value) {
//            if (value == null) {
//                vbd.tvDistanceHeader.visibility = View.INVISIBLE
//                vbd.tvDistanceHeader.header = ""
//                return
//            }
//            vbd.tvDistanceHeader.header = value
//            field = value
//        }
    var distancedes: CharSequence = ""
        set(value) {
            if (value == null) {
                vbd.tvDistanceDes.visibility = View.INVISIBLE
                vbd.tvDistanceDes.description = ""
                return
            }
            vbd.tvDistanceDes.description = value
            field = value


        }

    //    var earningHeader: CharSequence = ""
//        set(value) {
//            if (value == null) {
//                vbd.tvEarningHeader.visibility = View.INVISIBLE
//                vbd.tvEarningHeader.header = ""
//                return
//            }
//            vbd.tvEarningHeader.header = value
//            field = value
//        }
    var earningdes: CharSequence = ""
        set(value) {
            if (value == null) {
                vbd.tvEarningDes.visibility = View.INVISIBLE
                vbd.tvEarningDes.description = ""
                return
            }
            vbd.tvEarningDes.description = value
            field = value


        }

    //    var totalEarningHeader: CharSequence = ""
//        set(value) {
//            if (value == null) {
//                vbd.tvTotEarningHeader.visibility = View.INVISIBLE
//                vbd.tvTotEarningHeader.header = ""
//                return
//            }
//            vbd.tvTotEarningHeader.header = value
//            field = value
//        }
    var totalEarningdes: CharSequence = ""
        set(value) {
            if (value == null) {
                vbd.tvTotEarningDes.visibility = View.INVISIBLE
                vbd.tvTotEarningDes.description = ""
                return
            }
            vbd.tvTotEarningDes.description = value
            field = value

        }

    var alignmentCenter: Boolean = true
        set(value) {
            if (value) {
                vbd.tvTotEarningDes.alignmentCenter = value
                vbd.tvEarningDes.alignmentCenter = value
                vbd.tvDistanceDes.alignmentCenter = value
                vbd.tvTotEarningHeader.alignmentCenter = value
                vbd.tvEarningHeader.alignmentCenter = value
                vbd.tvDistanceHeader.alignmentCenter = value
            } else {
                vbd.tvTotEarningDes.alignmentCenter = value
                vbd.tvEarningDes.alignmentCenter = value
                vbd.tvDistanceDes.alignmentCenter = value
                vbd.tvTotEarningHeader.alignmentCenter = value
                vbd.tvEarningHeader.alignmentCenter = value
                vbd.tvDistanceHeader.alignmentCenter = value
            }
            field = value
        }

    init {


        val a = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.LDistanceAndLoginHrsView,
            defStyleAttr,
            defStyleRes
        )
//        distanceHeader =
//            a.getString(R.styleable.LDistanceAndLoginHrsView_distanceHeader) ?: distanceHeader
        distancedes =
            a.getString(R.styleable.LDistanceAndLoginHrsView_LoginHrDes)
                ?: distancedes
//        earningHeader =
//            a.getString(R.styleable.LDistanceAndLoginHrsView_earningHeader) ?: earningHeader
        earningdes =
            a.getString(R.styleable.LDistanceAndLoginHrsView_milesDes)
                ?: earningdes
//        totalEarningHeader =
//            a.getString(R.styleable.LDistanceAndLoginHrsView_totEarningHeader)
//                ?: totalEarningHeader
        totalEarningdes =
            a.getString(R.styleable.LDistanceAndLoginHrsView_totMilesDes)
                ?: totalEarningdes
        alignmentCenter =
            a.getBoolean(R.styleable.LDistanceAndLoginHrsView_alignmentCenter, true)


        a.recycle()
    }

    fun setLoginHrMin(hour: Int, minutes: Int) {
        vbd.tvDistanceHeader.setLoginHrMin(hour, minutes)
    }


    fun setKm(km: Double) {
        vbd.tvEarningHeader.setKm(km)

    }

    fun setTotKm(km: Double) {
        vbd.tvTotEarningHeader.setKm(km)

    }
}
