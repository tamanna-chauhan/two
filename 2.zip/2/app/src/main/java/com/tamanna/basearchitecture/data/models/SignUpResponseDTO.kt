/*
 *   Created by Sourav Kumar Pandit  22 - 4 - 2020
 */

package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName


data class SignUpResponseDTO(
    @field:SerializedName("status") val status: String,
    @field:SerializedName("tamannaId") val tamannaId: String,
    @field:SerializedName("countryCode") val countryCode: String,
    @field:SerializedName("mobile") val mobile: String,
    @field:SerializedName("createdAt") val createdAt: String,
    @field:SerializedName("photo") val photo: String?,
    @field:SerializedName("name") val name: String?,
    @field:SerializedName("mobile1") val mobile1: String?,
    @field:SerializedName("authToken") val authToken: String?,
    @field:SerializedName("operationalStatus") val operationalStatus: String?,
    @field:SerializedName("completionPercent") val completionPercent: Int,
    @field:SerializedName("bankDetailsComplete") val bankDetailsComplete: Boolean
)
