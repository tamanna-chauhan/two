package com.tamanna.basearchitecture.ui.screen.otp.data

import com.tamanna.basearchitecture.api.BaseDataSource
import com.tamanna.basearchitecture.api.LoginServiceAPI
import com.tamanna.basearchitecture.data.models.LoginOtpDTO
import com.tamanna.basearchitecture.data.models.SendOtpDTO
import com.tamanna.basearchitecture.data.models.SignUpOtpDTO

class OtpRemoteDataSource constructor(
    private val serviceAPI: LoginServiceAPI
) :
    BaseDataSource() {
    suspend fun verifyLogin(loginOtpDTO: LoginOtpDTO) = getResult {
        serviceAPI.verifyLogin(loginOtpDTO)
    }

    suspend fun verifySignUp(sendOtpDTO: SignUpOtpDTO) = getResult {
        serviceAPI.verifySignUp(sendOtpDTO)
    }

    suspend fun signupResendOtp(sendOtpDTO: SendOtpDTO) = getResult {
        serviceAPI.signupResendOtp(sendOtpDTO)
    }

    suspend fun loginSendOtp(sendOtpDTO: SendOtpDTO) = getResult {
        serviceAPI.loginSendOtp(sendOtpDTO)
    }

}
