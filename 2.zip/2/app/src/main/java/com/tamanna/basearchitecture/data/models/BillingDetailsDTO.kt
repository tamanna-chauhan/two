package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName


data class Billing(
    @field:SerializedName("totalAmount") val totalAmount: Double,
    @field:SerializedName("tip") val tip: ExtraIncomeDTO,
    @field:SerializedName("charges") val charges: List<EarningDTO>,
)



