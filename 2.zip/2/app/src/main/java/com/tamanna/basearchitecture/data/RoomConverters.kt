package com.tamanna.basearchitecture.data


/**
 * Type converters to allow Room to reference complex data types.
 */
class RoomConverters {
//    val gson: Gson = Gson()

}
