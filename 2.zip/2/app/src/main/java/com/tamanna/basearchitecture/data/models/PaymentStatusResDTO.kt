package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class PaymentStatusResDTO(

    @field:SerializedName("status") val status: String,
    @field:SerializedName("amount") val amount: String,
    @field:SerializedName("method") val method: String,
    @field:SerializedName("transactionId") val transactionId: String?,
) : Serializable
