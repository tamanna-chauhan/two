/*
 *   Created by Sourav Kumar Pandit  24 - 4 - 2020
 */
package com.tamanna.basearchitecture.data.models.base

import com.tamanna.basearchitecture.ui.base.DisplayTypeDTO
import com.tamanna.basearchitecture.ui.base.IView
import com.tamanna.basearchitecture.util.IConstants

@Suppress("UNCHECKED_CAST")
class RHandler<T>(view: IView, result: ResponseDTO<Any?>, callerFun: ((T) -> Unit)? = null) {
    init {

        val code = result.code
        val displayType = result.displayType
        when (result.type) {
            APIConstant.Status.LOADING -> {
                view.showProgressBar()
            }
            APIConstant.Status.ERROR -> {
                view.hideProgressBar()

                when (code) {
//                    handle for different code type
                    is Int -> {
                        view.onResponse(code, result.data, result.title, result.message ?: "")
                    }
                    else -> {
                        when (displayType) {
                            is String -> {
                                when (displayType) {
                                    IConstants.DisplayType.TOAST -> {
                                        view.onResponse(code, DisplayTypeDTO(displayType, code
                                                ?: -1, result.title ?: "", result.message
                                                ?: "", code ?: -1), result.title, result.message
                                                ?: "")
                                    }
                                    IConstants.DisplayType.DIALOG -> {
                                        view.onResponse(code, DisplayTypeDTO(displayType, code
                                                ?: -1, result.title ?: "", result.message
                                                ?: "", code ?: -1), result.title, result.message
                                                ?: "")
                                    }
                                    IConstants.DisplayType.SNACKBAR -> {
                                        view.onResponse(code, DisplayTypeDTO(displayType, code
                                                ?: -1, result.title ?: "", result.message
                                                ?: "", code ?: -1), result.title, result.message
                                                ?: "")
                                    }
                                    else -> {
                                        view.onResponse(code, DisplayTypeDTO(displayType, code
                                                ?: -1, result.title ?: "", result.message
                                                ?: "", code ?: -1), result.title, result.message
                                                ?: "")
                                    }
                                }
                            }
                            else -> {
                                view.showCodeError(
                                        APIConstant.Status.ERROR,
                                        result.title,
                                        result.message ?: ""
                                )
                            }

                        }

                    }

                }
            }

            APIConstant.Status.SUCCESS -> {
                when (code) {
//                    handle data in ui
                    null -> {
                        if (result.data != null)
                            callerFun?.invoke(result.data as T)
                        else
                            view.showCodeError(
                                    APIConstant.Status.SUCCESS,
                                    result.title,
                                    result.message ?: ""
                            )
                    }

                    else -> {
                        view.onResponse(code, result.data, result.title, result.message ?: "")
                    }
                }
                view.hideProgressBar()
            }
        }
    }
}
/*
 displayType
  -- toast
  -- dialog
  -- snackbar
  -- alerter


 */