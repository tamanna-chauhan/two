package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.databinding.ViewNotLinkedBankBinding
import com.tamanna.basearchitecture.ui.helper.hideEmptyTextView

/**
 * Created by Bhupendra Kumar Sahu on 20-Aug-20.
 */
class LNotLinkedBankView : LinearLayout {

    var iconTextColor: Int = 0
        set(value) {
            field = value
            vbd.saIconCross.setTextColor(field)
        }

    var icon: CharSequence? = ""
        set(value) {
            field = value
            vbd.saIconCross.hideEmptyTextView(field.toString())
        }

    var header: CharSequence? = ""
        set(value) {
            field = value
            vbd.saTvHeader.tv_title.hideEmptyTextView(field.toString())
            vbd.saTvHeader.alignmentCenter = true
        }

    var des: CharSequence? = ""
        set(value) {
            field = value
            vbd.saTvDescription.tv_description.hideEmptyTextView(field.toString())
        }

    private val vbd by lazy {
        val layoutInflater = LayoutInflater.from(context)
        ViewNotLinkedBankBinding.inflate(
            layoutInflater,
            this,
            true
        )
    }

    fun getCrossIcon(): View {
        return vbd.saIconCross
    }

    fun getAddAcView(): View {
        return vbd.llAddNewAccount
    }

    constructor(context: Context) : this(context, null, 0)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {

        if (attrs != null) {
            val a = context.theme.obtainStyledAttributes(
                attrs,
                R.styleable.LNotLinkedBankView,
                defStyleAttr,
                0
            )
            header = a.getString(R.styleable.LNotLinkedBankView_cardHeader) ?: header
            des = a.getString(R.styleable.LNotLinkedBankView_cardDescription) ?: des
            icon = a.getString(R.styleable.LNotLinkedBankView_fontIcon) ?: icon
            iconTextColor = a.getInt(R.styleable.LNotLinkedBankView_fontIconColor, 0)


            a.recycle()
        }
    }
}