package com.tamanna.basearchitecture.ui.contracthandler

object ContractAction {
    const val ACTIVITY_FOR_RESULT = "com.laalsa..ACTIVITY_FOR_RESULT"
    const val PICK_CONTENT = "com.laalsa..PICK_CONTENT"
    const val SELECT_IMAGE = "com.laalsa..SELECT_IMAGE"

}