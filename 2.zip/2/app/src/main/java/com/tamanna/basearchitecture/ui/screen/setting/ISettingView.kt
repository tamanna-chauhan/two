package com.tamanna.basearchitecture.ui.screen.setting

import com.tamanna.basearchitecture.ui.base.IView

interface ISettingView : IView
