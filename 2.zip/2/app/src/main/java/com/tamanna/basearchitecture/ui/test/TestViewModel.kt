package com.tamanna.basearchitecture.ui.test

import com.tamanna.basearchitecture.ui.base.BaseViewModel
import com.tamanna.basearchitecture.ui.screen.mainActivity.IMainView
import com.tamanna.basearchitecture.ui.screen.mainActivity.data.MainRepository

class TestViewModel constructor(private val repository: MainRepository) :
    BaseViewModel<IMainView>() {



}