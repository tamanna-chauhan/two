package com.tamanna.basearchitecture.ui.common

import android.view.LayoutInflater
import android.view.ViewGroup
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.databinding.EmptyItemBinding
import com.mikepenz.fastadapter.binding.AbstractBindingItem

class EmptyItem(title: String = "No Record To Display", img: Int = R.drawable.ic_empty_list) :
    AbstractBindingItem<EmptyItemBinding>() {
    val mtitle = title
    val mImg = img

    override val type: Int
        get() = R.id.empty_item_id

    override fun bindView(binding: EmptyItemBinding, payloads: List<Any>) {
        binding.ivEmptyLogo.setImageResource(mImg)
    }

    override fun createBinding(inflater: LayoutInflater, parent: ViewGroup?): EmptyItemBinding {
        return EmptyItemBinding.inflate(inflater, parent, false)
    }
}
