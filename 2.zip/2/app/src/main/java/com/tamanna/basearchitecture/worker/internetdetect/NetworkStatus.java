package com.tamanna.basearchitecture.worker.internetdetect;

public interface NetworkStatus {

    boolean isOnline();
}