package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class TaskSummaryDTO(
        @field:SerializedName("distance") val distance: Double,
        @field:SerializedName("earning") val earning: Double,
        @field:SerializedName("todaysEarning") val todaysEarning: Double,
        @field:SerializedName("time") val time: Double,
        @field:SerializedName("status") val status: String
) : Serializable
