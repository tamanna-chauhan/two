package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName

/**
 * Created by Bhupendra Kumar Sahu on 10-Feb-21.
 */
data class TripsDetailsResDTO(
    @field:SerializedName("earnings") val earning: List<EarningDTO>,
    @field:SerializedName("cashOnHand") val cashOnHand: CashOnHandDTO,
    @field:SerializedName("extraIncome") val extraIncome: ExtraIncomeDTO,
    @field:SerializedName("pickupDistance") val pickupDistance: Double,
    @field:SerializedName("dropoffDistance") val dropoffDistance: Double,
    @field:SerializedName("status") val status: String,
    @field:SerializedName("restaurant") val restaurant: String,
    @field:SerializedName("totalTime") val totalTime: TotalTimeDTO,
    @field:SerializedName("states") val states: List<RiderStateDTO>,
    @field:SerializedName("orderNum") val orderNum: String

)

data class CashOnHandDTO(
    @field:SerializedName("amount") val amount: Double
)

data class EarningDTO(
    @field:SerializedName("name") val name: String,
    @field:SerializedName("displayName") val displayName: String,
    @field:SerializedName("value") val value: Double,

    )

data class ExtraIncomeDTO(
    @field:SerializedName("amount") val amount: Double? = 0.0,
    @field:SerializedName("reason") val reason: String? = "",
)


data class RiderStateDTO(
    @field:SerializedName("state") val state: String,
    @field:SerializedName("timestamp") val timestamp: String,
    @field:SerializedName("title") val title: String?
)


data class CoordinatesDTO(
    @field:SerializedName("coordinates") val coordinates: List<Double>,
    @field:SerializedName("type") val type: String
)

data class TotalTimeDTO(
    @field:SerializedName("hour") val hour: Int,
    @field:SerializedName("minutes") val minutes: Int
)