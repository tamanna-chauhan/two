package com.tamanna.basearchitecture.worker.internetdetect;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class AppNetworkStatus implements NetworkStatus {

    private final Context context;

    public AppNetworkStatus(Context context) {
        this.context = context;
    }

    @Override
    public boolean isOnline() {
        ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = manager.getActiveNetworkInfo();
        // Device is online
        // Device is not online
        return networkInfo != null && networkInfo.isConnected();
    }
}