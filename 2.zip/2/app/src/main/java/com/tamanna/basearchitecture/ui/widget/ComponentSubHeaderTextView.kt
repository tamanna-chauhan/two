package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.ui.helper.*


/**
 * Created by Bhupendra Kumar Sahu on 19-Aug-20.
 */
class ComponentSubHeaderTextView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : LinearLayout(context, attrs, defStyleAttr, defStyleRes) {
    val tv_header: TextView

    var header: CharSequence = ""
        set(value) {
            tv_header.text = value
            field = value
        }

    var alignmentCenter: Boolean = false
        set(value) {
            if (value) {
                tv_header.textAlignment = View.TEXT_ALIGNMENT_CENTER
            } else {
                tv_header.textAlignment = View.TEXT_ALIGNMENT_TEXT_START
            }
            field = value
        }

    init {
        clipToPadding = false
        val view = View.inflate(context, R.layout.type_attribute_sub_header_text, this)
        tv_header = view.findViewById(R.id.tv_header)

        val a = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.ComponentSubHeaderTextView,
            defStyleAttr,
            defStyleRes
        )

        header = a.getString(R.styleable.ComponentSubHeaderTextView_cardHeader) ?: header
        alignmentCenter =
            a.getBoolean(R.styleable.ComponentSubHeaderTextView_alignmentCenter, false)
        a.recycle()
    }

    fun setPriceValue(price: Double) {
        tv_header.appendPriceValue(price)
    }

    fun setDebitPrice(earnings: Double) {
        tv_header.appendDebitPriceValue(earnings)
    }

    fun setCreditPrice(earnings: Double) {
        tv_header.appendCreditPriceValue(earnings)
    }

    fun setLoginHrMin(hour: Int, minutes: Int) {
        tv_header.loginHours(hour, minutes)

    }

    fun setWeek(week: Int) {
        tv_header.setWeek(week)

    }

}

//ConstraintLayout {
//    var header: CharSequence? = ""
//    set(value) {
//        field = value
//        vbd.tvHeader.hideEmptyTextView(field.toString())
//    }
//
//    var alignmentCenter: Boolean = false
//    set(value) {
//        if (value) {
//            vbd.tvHeader.textAlignment = View.TEXT_ALIGNMENT_CENTER
//        } else {
//            vbd.tvHeader.textAlignment = View.TEXT_ALIGNMENT_TEXT_START
//        }
//        field = value
//    }
//
//
//    private val vbd by lazy {
//        val layoutInflater = LayoutInflater.from(context)
//        TypeAttributeSubHeaderTextBinding.inflate(
//            layoutInflater,
//            this,
//            true
//        )
//    }
//
//    constructor(context: Context) : this(context, null, 0)
//    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
//    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
//    context,
//    attrs,
//    defStyleAttr
//    ) {
//
//        if (attrs != null) {
//            val a = context.theme.obtainStyledAttributes(
//                attrs,
//                R.styleable.ComponentSubHeaderTextView,
//                defStyleAttr,
//                0
//            )
//
//            header = a.getString(R.styleable.ComponentSubHeaderTextView_cardHeader) ?: header
//            alignmentCenter =
//                a.getBoolean(R.styleable.ComponentSubHeaderTextView_alignmentCenter, false)
//            a.recycle()
//        }
//    }
//
//
//    fun setPriceValue(earnings: Double?) {
//        vbd.tvHeader.appendPriceValue(earnings)
//    }
//}