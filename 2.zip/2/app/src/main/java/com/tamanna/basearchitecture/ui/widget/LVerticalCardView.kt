package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.databinding.ViewVerticalCardBinding


/**
 * Created by Bhupendra Kumar Sahu on 19-Aug-20.
 */
class LVerticalCardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : LinearLayout(context, attrs, defStyleAttr, defStyleRes) {
    private val vbd by lazy {
        val layoutInflater = LayoutInflater.from(context)
        ViewVerticalCardBinding.inflate(layoutInflater, this, true)
    }


    var header: CharSequence? = ""
        set(value) {
            if (value == null) {
                vbd.cardHeader.visibility = View.INVISIBLE
                vbd.cardHeader.header = ""
                return
            }
            vbd.cardHeader.header = value
            field = value
        }

    var description: CharSequence? = ""
        set(value) {
            if (value == null) {
                vbd.cardDescription.visibility = View.INVISIBLE
                vbd.cardDescription.description = ""
                return
            }
            vbd.cardDescription.description = value
            field = value
        }
    var alignmentCenter: Boolean = true
        set(value) {
            if (value) {
                vbd.cardDescription.alignmentCenter = value
                vbd.cardHeader.alignmentCenter = value
            } else {
                vbd.cardDescription.alignmentCenter = value
                vbd.cardHeader.alignmentCenter = value
            }
            field = value
        }
    var showGrayBtn: Boolean = true
        set(value) {
            if (value) {
                vbd.btnCancel.visibility = View.VISIBLE
            } else {
                vbd.btnCancel.visibility = View.INVISIBLE
            }
            field = value
        }

    var btnDone: CharSequence? = ""
        set(value) {
            if (value == null) {
                vbd.btnDone.visibility = View.GONE
                vbd.btnDone.actionDone = ""
                return
            }
            vbd.btnDone.actionDone = value
            field = value
        }
    var btnCancel: CharSequence? = ""
        set(value) {
            if (value == null) {
                vbd.btnCancel.visibility = View.GONE
                vbd.btnCancel.actionCancel = ""
                return
            }
            vbd.btnCancel.actionCancel = value
            field = value
        }
    init {
        clipToPadding = false
        orientation = VERTICAL

        val a = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.LVerticalCardView,
            defStyleAttr,
            defStyleRes
        )
        description = a.getString(R.styleable.LVerticalCardView_cardDescription) ?: description
        header = a.getString(R.styleable.LVerticalCardView_cardHeader) ?: header
        showGrayBtn = a.getBoolean(R.styleable.LVerticalCardView_showBtn, true)
        alignmentCenter = a.getBoolean(R.styleable.LVerticalCardView_alignmentCenter, true)
        btnDone = a.getString(R.styleable.LVerticalCardView_doneButton) ?: btnDone
        btnCancel = a.getString(R.styleable.LVerticalCardView_cancelButton) ?: btnCancel
        a.recycle()
    }
}