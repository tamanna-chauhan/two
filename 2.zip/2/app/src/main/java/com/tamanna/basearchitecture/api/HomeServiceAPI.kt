/*
 *   Created by Sourav Kumar Pandit  28 - 4 - 2020
 */

package com.tamanna.basearchitecture.api

import com.tamanna.basearchitecture.data.models.DutyResDTO
import com.tamanna.basearchitecture.data.models.HomeResDTO
import com.tamanna.basearchitecture.data.models.ProfileResDTO
import com.tamanna.basearchitecture.data.models.base.APIConstant
import com.tamanna.basearchitecture.data.models.base.ResponseDTO
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query


interface HomeServiceAPI {
    @GET(APIConstant.URL.HOME_DATA)
    suspend fun homeData(
        @Query("tamannaId") tamannaId: String,
        @Query("currentDate") currentDate: String
    ): Response<ResponseDTO<HomeResDTO>>

    @POST(APIConstant.URL.DUTY)
    suspend fun duty(@Body hashMap: HashMap<String, String>): Response<ResponseDTO<DutyResDTO>>

    @GET(APIConstant.URL.GET_PROFILE)
    suspend fun fetchProfile(@Query("tamannaId") tamannaId: String): Response<ResponseDTO<ProfileResDTO>>

    @POST(APIConstant.URL.RAISED_TICKET)
    suspend fun raiseTicket(@Query("tamannaId") tamannaId: String): Response<ResponseDTO<Any>>
}
