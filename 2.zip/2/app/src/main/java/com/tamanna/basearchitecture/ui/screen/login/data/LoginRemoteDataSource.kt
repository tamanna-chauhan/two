package com.tamanna.basearchitecture.ui.screen.login.data

import com.tamanna.basearchitecture.api.BaseDataSource
import com.tamanna.basearchitecture.api.LoginServiceAPI
import com.tamanna.basearchitecture.data.models.SendOtpDTO

class LoginRemoteDataSource constructor(
    private val serviceAPI: LoginServiceAPI
) :
    BaseDataSource() {
    suspend fun loginSendOtp(sendOtpDTO: SendOtpDTO) = getResult {
        serviceAPI.loginSendOtp(sendOtpDTO)
    }


}
