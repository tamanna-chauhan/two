package com.tamanna.basearchitecture.ui.screen.signup

import com.tamanna.basearchitecture.ui.base.BaseViewModel
import com.tamanna.basearchitecture.ui.screen.signup.data.SignUpRepository
import com.tamanna.basearchitecture.util.IConstants


class SignUpViewModel constructor(private val repository: SignUpRepository) :
    BaseViewModel<ISignUp>() {
    fun signUpSendOtp(number: String) =
        repository.signUpSendOtp(number, IConstants.Country.Code, "sendOtp")

}
//    val configObserve: ConfigDataObserve = ConfigDataObserve()
//    fun navigateToOtp() {
//        getView()?.navToOtp()
//
//    }
//
//    inner class ConfigDataObserve : BaseObservable() {
//        private var validNumber: Boolean = false
//        var number: String = ""
//
//        private var validName: Boolean = false
//        var name: String = ""
//
//
//        @get:Bindable
//        val btnText: String
//            get() =
//                if (validNumber && validName) {
//                    "Continue"
//                } else {
//                    if (!validName) {
//                        "Please Enter Valid Name"
//                    } else {
//                        "Please Enter Valid Number"
//                    }
//                }
//
////        @get:Bindable
////        val btnTextColor: Int
////            get() =
////                if (validNumber && validName) {
////                    R.color.white
////                } else {
////                    if (!validName) {
////                        R.color.black
////                    } else {
////                        R.color.black
////                    }
////                }
//
//
//        @Bindable
//        fun isValidMobile(): Boolean {
//            return validNumber
//        }
//
//
//        fun isValidNumber(number: String) {
//            this.validNumber = YumUtil.isValidMobile(number)
////        notifyPropertyChanged(BR.validUrl)
//            notifyPropertyChanged(BR._all)
//        }
//
//        @Bindable
//        fun getMobileTextWatcher(): TextWatcher {
//            return object : TextWatcher {
//                override fun beforeTextChanged(
//                    s: CharSequence,
//                    start: Int,
//                    count: Int,
//                    after: Int
//                ) {
//                    // Do nothing.
//                }
//
//                override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
//                    number = s.toString()
//                    isValidNumber(number)
//                }
//
//                override fun afterTextChanged(s: Editable) {
//                    // Do nothing.
//                }
//            }
//        }
//
//
//        @Bindable
//        fun isValidName(): Boolean {
//            return validName
//        }
//
//
//        fun isValidUserName(name: String) {
//            this.validName = YumUtil.isValidNameIgnoreSpace(name)
////        notifyPropertyChanged(BR.validUrl)
//            notifyPropertyChanged(BR._all)
//        }
//
//        @Bindable
//        fun getNameTextWatcher(): TextWatcher {
//            return object : TextWatcher {
//                override fun beforeTextChanged(
//                    s: CharSequence,
//                    start: Int,
//                    count: Int,
//                    after: Int
//                ) {
//                    // Do nothing.
//                }
//
//                override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
//                    name = s.toString()
//                    isValidUserName(name)
//                }
//
//                override fun afterTextChanged(s: Editable) {
//                    // Do nothing.
//                }
//            }
//        }
//
//
//    }
//}

