package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import androidx.constraintlayout.widget.ConstraintLayout
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.databinding.ViewCashFlowCardBinding
import com.tamanna.basearchitecture.ui.helper.bindIsGone
import com.tamanna.basearchitecture.ui.helper.hideEmptyTextView

class LCashFlowCardView : ConstraintLayout {

    var header: CharSequence? = ""
        set(value) {
            field = value
            vbd.cfCardHeader.tv_header.hideEmptyTextView(field.toString())
        }

    var description: CharSequence? = ""
        set(value) {
            field = value
            vbd.cfCardDescription.tv_description.hideEmptyTextView(field.toString())
        }
    var amount: CharSequence? = ""
        set(value) {
            field = value
            vbd.tvCardAmount.tv_sub_title.hideEmptyTextView(field.toString())
        }
    var status: CharSequence? = ""
        set(value) {
            field = value
            vbd.tvStatus.tv_colored.hideEmptyTextView(field.toString())
        }
    var statusDec: CharSequence? = ""
        set(value) {
            field = value
            vbd.tvStatusDec.tv_description.hideEmptyTextView(field.toString())
        }
    var iconView: CharSequence? = ""
        set(value) {
            field = value
            vbd.iconFont.hideEmptyTextView(field.toString())
        }
    var iconViewColor: Int = 0
        set(value) {
            field = value
            vbd.iconFont.setTextColor(field)
        }

    var backgroungColor: Int = 0
        set(value) {
            field = value
            vbd.fivBackgroundCircle.setTextColor(field)
        }


    var showFontIcon: Boolean = true
        set(value) {
            field = value
            vbd.iconFont.bindIsGone(!field)
            vbd.fivBackgroundCircle.bindIsGone(!field)
            vbd.framelayout.bindIsGone(!field)

        }

    var setTextColor : Int = 0
        set(value) {
            field = value
            vbd.tvStatus.tv_colored.setTextColor(field)

        }

    var alignmentCenter: Boolean = true
        set(value) {
            if (value) {
                vbd.tvStatus.alignmentCenter = value
                vbd.tvCardAmount.alignmentCenter = value
                vbd.tvStatusDec.alignmentCenter = value
            } else {
                vbd.tvStatus.alignmentCenter = value
                vbd.tvCardAmount.alignmentCenter = value
                vbd.tvStatusDec.alignmentCenter = value
            }
            field = value
        }


    private val vbd by lazy {
        val layoutInflater = LayoutInflater.from(context)
        ViewCashFlowCardBinding.inflate(
            layoutInflater,
            this,
            true
        )
    }

    constructor(context: Context) : this(context, null, 0)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {

        if (attrs != null) {
            val a = context.theme.obtainStyledAttributes(
                attrs,
                R.styleable.LCashFlowCardView,
                defStyleAttr,
                0
            )
            header = a.getString(R.styleable.LCashFlowCardView_cardHeader) ?: header
            description = a.getString(R.styleable.LCashFlowCardView_cardDescription) ?: description
            status = a.getString(R.styleable.LCashFlowCardView_textStatus) ?: status
            statusDec = a.getString(R.styleable.LCashFlowCardView_statusDescription) ?: statusDec
            amount = a.getString(R.styleable.LCashFlowCardView_totAmount) ?: amount
            iconView = a.getString(R.styleable.LCashFlowCardView_fontIcon) ?: iconView
            iconViewColor = a.getInt(R.styleable.LCashFlowCardView_fontIconColor, 0)
            backgroungColor = a.getInt(R.styleable.LCashFlowCardView_backColor, 0)
            showFontIcon = a.getBoolean(R.styleable.LCashFlowCardView_showIcon, true)
            setTextColor = a.getInt(R.styleable.LCashFlowCardView_colorText, 0)
            alignmentCenter = a.getBoolean(R.styleable.LCashFlowCardView_alignmentCenter, true)
            // showColorText = a.getBoolean(R.styleable.LCashFlowCardView_showText, true)


            a.recycle()
        }
    }
}
