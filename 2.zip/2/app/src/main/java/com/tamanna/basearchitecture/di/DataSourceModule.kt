package com.tamanna.basearchitecture.di

import com.tamanna.basearchitecture.ui.screen.login.data.LoginRemoteDataSource
import com.tamanna.basearchitecture.ui.screen.mainActivity.data.MainRemoteDataSource
import com.tamanna.basearchitecture.ui.screen.otp.data.OtpRemoteDataSource
import com.tamanna.basearchitecture.ui.screen.signup.data.*
import org.koin.dsl.module

fun dataSourceModule() = module {

    factory { LoginRemoteDataSource(get()) }
    factory { SignUpRemoteDataSource(get()) }
    factory { OtpRemoteDataSource(get()) }
    factory { MainRemoteDataSource(get()) }


}