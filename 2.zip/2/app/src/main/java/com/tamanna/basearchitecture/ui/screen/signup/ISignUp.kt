package com.tamanna.basearchitecture.ui.screen.signup

import com.tamanna.basearchitecture.ui.base.IView

interface ISignUp : IView {
    fun navToOtp()
}
