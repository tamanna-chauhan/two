package com.tamanna.basearchitecture.ui.screen.setting

import android.os.Bundle
import android.view.View
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.databinding.DialogLanguageBinding
import com.tamanna.basearchitecture.ui.base.BaseSheetFragment
import org.koin.androidx.viewmodel.ext.android.viewModel

class ChangeLanguageSheet : BaseSheetFragment<DialogLanguageBinding, SettingViewModel>() {
    override val svm by viewModel<SettingViewModel>()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        bd.toolbar.setNavigationOnClickListener { dismiss() }
    }

    override fun onDebounceClick(view: View) {

    }

    override fun getLayoutId(): Int {
        return R.layout.dialog_language
    }

}

