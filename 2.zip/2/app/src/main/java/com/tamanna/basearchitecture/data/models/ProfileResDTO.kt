package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName

/**
 * Created by Bhupendra Kumar Sahu on 02-Feb-21.
 */
data class ProfileResDTO(

    @field:SerializedName("name") val name: String?,
    @field:SerializedName("mobile") val mobile: String?,
    @field:SerializedName("email") val email: String?,
    @field:SerializedName("workingMode") val workingMode: String?,
    @field:SerializedName("completionPercent") val completionPercent: Int? = 0,
    @field:SerializedName("bankDetailsComplete") val bankDetailsComplete: Boolean? = false,
    @field:SerializedName("bankDetails") val bankDetails: BankDetailsDTO?,
    @field:SerializedName("aadhaar") val aadhaar: AadhaarDTO?,
    @field:SerializedName("dl") val dl: DrivingLicDTO?

)

data class BankDetailsDTO(

    @field:SerializedName("accName") val holderName: String? = "",
    @field:SerializedName("accNum") val accNum: String?,
    @field:SerializedName("bankName") val bankName: String?,
    @field:SerializedName("ifsc") val ifsc: String?,
    @field:SerializedName("pan") val pan: String?


)

data class AadhaarDTO(

    @field:SerializedName("docLink") val docLink: String?,
    @field:SerializedName("docNumber") val docNumber: String?,
    @field:SerializedName("status") val status: String?

)

data class DrivingLicDTO(

    @field:SerializedName("docLink") val docLink: String? = "",
    @field:SerializedName("docNumber") val docNumber: String? = "",
    @field:SerializedName("status") val status: String?

)