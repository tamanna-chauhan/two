package com.tamanna.basearchitecture.ui.screen.otp

import com.tamanna.basearchitecture.data.models.UploadsDTO
import com.tamanna.basearchitecture.ui.base.BaseViewModel
import com.tamanna.basearchitecture.ui.screen.otp.data.OtpRepository
import com.tamanna.basearchitecture.util.IConstants


class OtpViewModel constructor(private val repository: OtpRepository) : BaseViewModel<IOtp>() {
    fun verifyLogin(number: String, otp: String, deviceId: String) =
        repository.verifyLogin(number, otp, deviceId)

    fun verifySignUp(
        uploads: UploadsDTO,
        otp: String,
        number: String,
        deviceId: String,
        name: String
    ) =
        repository.verifySignUp(uploads, otp, number, deviceId, name)

    fun signupResendOtp(number: String) =
        repository.signupResendOtp(number, IConstants.Country.Code, "resendOtp")

    fun loginSendOtp(number: String) =
        repository.loginSendOtp(number, IConstants.Country.Code, "resendOtp")

}
