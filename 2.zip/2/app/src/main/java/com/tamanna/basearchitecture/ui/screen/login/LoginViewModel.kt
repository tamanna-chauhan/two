package com.tamanna.basearchitecture.ui.screen.login

import com.tamanna.basearchitecture.ui.base.BaseViewModel
import com.tamanna.basearchitecture.ui.screen.signup.data.LoginRepository
import com.tamanna.basearchitecture.util.IConstants


class LoginViewModel constructor(private val repository: LoginRepository) :
    BaseViewModel<ILoginView>() {
    // val configObserve: ConfigViewModel.ConfigDataObserve = ConfigViewModel.ConfigDataObserve()
    fun loginSendOtp(number: String) =
        repository.loginSendOtp(number, IConstants.Country.Code, "sendOtp")
//
//    fun navigateToOtp() {
//        getView()?.navToOtp()
//
//    }

//    inner class ConfigDataObserve : BaseObservable() {
//        private var validNumber: Boolean = false
//        var number: String = ""
//
////    private var message: String? = null
//
//        @get:Bindable
//        val btnText: String
//            get() = if (validNumber) {
//                "Continue"
//            } else {
//                "Please Enter Valid Number"
//            }
//
//        @Bindable
//        fun isValidMobile(): Boolean {
//            return validNumber
//        }
//
//
//        fun isValidNumber(number: String) {
//            this.validNumber = YumUtil.isValidMobile(number)
////        notifyPropertyChanged(BR.validUrl)
//            notifyPropertyChanged(BR._all)
//        }
//
//        @Bindable
//        fun getMobileTextWatcher(): TextWatcher {
//            return object : TextWatcher {
//                override fun beforeTextChanged(
//                    s: CharSequence,
//                    start: Int,
//                    count: Int,
//                    after: Int
//                ) {
//                    // Do nothing.
//                }
//
//                override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
//                    number = s.toString()
//                    isValidNumber(number)
//                }
//
//                override fun afterTextChanged(s: Editable) {
//                    // Do nothing.
//                }
//            }
//        }
//    }
}

