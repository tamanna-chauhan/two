package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName

data class EarningsResDTO(
    @field:SerializedName("timings") val timings: TimingsDTO,
    @field:SerializedName("earnings") val earnings: Double,
    @field:SerializedName("trips") val trips: Long,
    @field:SerializedName("orderEarnings") val orderEarnings: Double,
    @field:SerializedName("extraIncomes") val extraIncomes: List<Any?>
)