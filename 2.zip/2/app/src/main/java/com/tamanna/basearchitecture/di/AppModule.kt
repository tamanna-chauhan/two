package com.tamanna.basearchitecture.di

fun appModule() = listOf(
    dataSourceModule(),
    localModule(),
    remoteModule(),
    repositoryModule(),
    viewModelModule()
)