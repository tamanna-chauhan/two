package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import com.laalsa.laalsalib.ui.VUtil
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.data.models.Billing
import com.tamanna.basearchitecture.ui.helper.ThemeConstant
import com.tamanna.basearchitecture.ui.helper.setMontserratBold
import com.tamanna.basearchitecture.ui.helper.setMontserratRegular
import com.tamanna.basearchitecture.ui.helper.withPrecision
import com.tamanna.basearchitecture.util.viewutils.YumUtil

class LBillDetailsView : LinearLayout {

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {
        initAttrs(attrs, context, defStyleAttr)
        intiViews()
    }


    var title: String = ""
        set(value) {
            field = value
            this.findViewById<ComponentSubTitleTextView>(R.id.tv_billing_title)?.tv_sub_title?.text =
                field

        }

    var isBold: Boolean = true
        set(value) {
            field = value
            this.findViewById<ComponentSubTitleTextView>(R.id.tv_billing_title)?.tv_sub_title?.setMontserratBold()
            this.findViewById<ComponentSubTitleTextView>(R.id.tv_billing_subtitle)?.tv_sub_title?.setMontserratBold()
        }
    var subTitle: String = ""
        set(value) {
            field = value
            this.findViewById<ComponentSubTitleTextView>(R.id.tv_billing_subtitle)?.tv_sub_title?.text =
                field
        }

    var billing: Billing? = null
        set(value) {
            if (value != null) {
                setBillingInfoList(value)
            }
            field = value
        }

    private fun initAttrs(
        attrs: AttributeSet?,
        context: Context?,
        defStyleAttr: Int
    ) {
        if (attrs != null) {
            val a =
                context!!.obtainStyledAttributes(
                    attrs,
                    R.styleable.LBillingDetailsView,
                    defStyleAttr,
                    0
                )

            title = a.getString(R.styleable.LBillingDetailsView_billing_title) ?: ""
            subTitle = a.getString(R.styleable.LBillingDetailsView_billing_subtitle) ?: ""

            a.recycle()

        }
    }


    private fun intiViews() {
        this.orientation = VERTICAL
        this.setPadding(VUtil.dpToPx(8), VUtil.dpToPx(8), VUtil.dpToPx(8), VUtil.dpToPx(8))
    }


    private fun setBillingInfoList(billing: Billing) {
        billing.charges.forEachIndexed { index, charge ->

            if (index != 0 && !charge.displayName.contains("Total earning", true))

                this.addView(
                    getRow(
                        charge.displayName,
                        "₹" + charge.value.withPrecision(2),
                        false,
                        0
                    )
                )

        }

        if (!billing.tip.reason.isNullOrEmpty()) {
            this.addView(
                billing.tip.reason.capitalize().let {
                    getRow(
                        it,
                        "₹" + billing.tip.amount?.withPrecision(2),
                        true,
                        2
                    )
                })

        }
        val dividerView = YumUtil.dividerView(context, ThemeConstant.textGrayColor, 1)

        this.addView(dividerView)
        this.addView(
            getRow(
                "Total earning",
                "₹" + billing.totalAmount.withPrecision(2),
                true,
                1
            )
        )
    }

    private fun getRow(
        title: String,
        amount: CharSequence?,
        toBold: Boolean,
        toChangeColor: Int
    ): View {

        val linearLayout = LinearLayout(context)
        linearLayout.orientation = HORIZONTAL
        linearLayout.setPadding(VUtil.dpToPx(2), VUtil.dpToPx(2), VUtil.dpToPx(2), VUtil.dpToPx(2))

        val lp = LayoutParams(0, LayoutParams.MATCH_PARENT, 1f)

        val titleView = ComponentSubTitleTextView(context)
        if (toBold) {
            titleView.tv_sub_title.setMontserratBold()
            titleView.setPadding(0, VUtil.dpToPx(5), 0, VUtil.dpToPx(5))
        } else {
            titleView.tv_sub_title.setMontserratRegular()

        }
        if (toChangeColor == 1) {
            titleView.tv_sub_title.setMontserratBold()
            titleView.tv_sub_title.setTextColor(ThemeConstant.greenConfirmColor)
        } else if (toChangeColor == 2) {
            titleView.tv_sub_title.setMontserratBold()
            titleView.tv_sub_title.setTextColor(ThemeConstant.yellow)
        }

        titleView.tv_sub_title.text = title
        titleView.id = R.id.tv_billing_title
        titleView.gravity = Gravity.START
        titleView.layoutParams = lp

        val priceView = ComponentSubTitleTextView(context)
        if (toBold) {
            priceView.tv_sub_title.setMontserratBold()
            priceView.setPadding(0, VUtil.dpToPx(5), 0, VUtil.dpToPx(5))

        } else {
            priceView.tv_sub_title.setMontserratRegular()
        }
        if (toChangeColor == 1) {
            priceView.tv_sub_title.setMontserratBold()
            priceView.tv_sub_title.setTextColor(ThemeConstant.greenConfirmColor)
        } else if (toChangeColor == 2) {
            priceView.tv_sub_title.setMontserratBold()
            priceView.tv_sub_title.setTextColor(ThemeConstant.yellow)
        }

        priceView.tv_sub_title.text = amount
        priceView.id = R.id.tv_billing_subtitle
        priceView.tv_sub_title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        priceView.gravity = Gravity.END

        linearLayout.addView(titleView)
        linearLayout.addView(priceView)
        return linearLayout

    }


}