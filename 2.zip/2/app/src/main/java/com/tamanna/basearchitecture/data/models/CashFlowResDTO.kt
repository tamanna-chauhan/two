/*
 *   Created by Sourav Kumar Pandit  22 - 4 - 2020
 */

package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName


data class CashFlowResDTO(
    @field:SerializedName("cashFlows") val cashFlows: List<CashFlowsDTO>,
    @field:SerializedName("total") val total: Double
)

data class CashFlowsDTO(
    @field:SerializedName("title") val title: String,

    @field:SerializedName("_id") val _id: String,
    @field:SerializedName("type") val type: String,
    @field:SerializedName("desc") val desc: String,
    @field:SerializedName("amount") val amount: Double,
    @field:SerializedName("percent") val percent: Double

)


