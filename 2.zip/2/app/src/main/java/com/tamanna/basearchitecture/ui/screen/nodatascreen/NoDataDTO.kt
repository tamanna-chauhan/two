package com.tamanna.basearchitecture.ui.screen.nodatascreen

import androidx.annotation.DrawableRes

data class NoDataDTO(val action: Int, @DrawableRes val imgDrawable: Int, val title: String, val message: String)
