package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName

data class NewOrderDTO (
        @field:SerializedName("expectedEarning") val earning: Double = 20.60,
        @field:SerializedName("expectedDistance") val distance: Double = 12.8,
        @field:SerializedName("outletName") val outletName: String = "Restaurant Name",
        @field:SerializedName("outletAddress") val outletAddress: String = "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
        @field:SerializedName("outletCoordinate") val outletCoordinate: List<Double> = listOf(17.443982, 78.398881),
        @field:SerializedName("orderCount") val orderCount: Int = 2,
        @field:SerializedName("orderId") val orderId: String = "#232432543",
        @field:SerializedName("orderBy") val orderBy: String = "Raman raghav",
        @field:SerializedName("amount") val amount: Double = 34.2,
        @field:SerializedName("paymentRequired") val isPaymentRequired: Boolean = false,
        @field:SerializedName("items") val item: List<OrderItemDTO> = listOf(OrderItemDTO(itemQuantity = 2), OrderItemDTO(itemName = "Dohsa")),
        )

data class OrderItemDTO(
    @field:SerializedName("name") val itemName: String? = null,
    @field:SerializedName("qty") val itemQuantity: Long? = null,
    @field:SerializedName("approxValue") val approxValue: Long? = null,
    @field:SerializedName("weight") val weight: Long? = null
)