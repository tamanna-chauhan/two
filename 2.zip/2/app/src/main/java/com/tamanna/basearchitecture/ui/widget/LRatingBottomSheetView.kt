package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import androidx.constraintlayout.widget.ConstraintLayout
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.databinding.ViewRatingBottomSheetBinding


/**
 * Created by Bhupendra Kumar Sahu on 20-Aug-20.
 */
class LRatingBottomSheetView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : ConstraintLayout(context, attrs, defStyleAttr, defStyleRes) {
    private val vbd by lazy {
        val layoutInflater = LayoutInflater.from(context)
        ViewRatingBottomSheetBinding.inflate(layoutInflater, this, true)
    }

    var header: CharSequence = ""
        set(value) {
            if (value == null) {
                vbd.rtvHeader.visibility = View.INVISIBLE
                vbd.rtvHeader.header = ""
                return
            }
            vbd.rtvHeader.header = value
            field = value
        }

    var colorText: CharSequence = ""
        set(value) {
            if (value == null) {
                vbd.rtvSubHeader.visibility = View.INVISIBLE
                vbd.rtvSubHeader.tv_colored.text = ""
                return
            }
            vbd.rtvSubHeader.tv_colored.text = value
            field = value
        }
    var rating: Float = 0.0f
        set(value) {
            if (value == null) {
                return
            }
            vbd.ratingbar.rating = value
            field = value
        }
    var title: CharSequence = ""
        set(value) {
            if (value == null) {
                vbd.rtvTitle.visibility = View.INVISIBLE
                vbd.rtvTitle.title = ""
                return
            }
            vbd.rtvTitle.title = value
            field = value

        }

    var subTitle: CharSequence = ""
        set(value) {
            if (value == null) {
                vbd.rtvSubtitle.visibility = View.INVISIBLE
                vbd.rtvSubtitle.subTitle = ""
                return
            }
            vbd.rtvSubtitle.subTitle = value
            field = value

        }

    var showActionBtn: Boolean = true
        set(value) {
            if (value) {
                vbd.btnSubmit.visibility = View.VISIBLE
            } else {
                vbd.btnSubmit.visibility = View.GONE
            }
            field = value
        }
    var setTextColor : Int = 0
        set(value) {
            vbd.rtvSubHeader.setTextColor = value
            field = value


        }

    init {


        val a = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.LRatingBottomSheetView,
            defStyleAttr,
            defStyleRes
        )
        header = a.getString(R.styleable.LRatingBottomSheetView_cardHeader) ?: header
        colorText = a.getString(R.styleable.LRatingBottomSheetView_setText) ?: colorText
        rating = a.getFloat(R.styleable.LRatingBottomSheetView_rating, 0.0f)
        setTextColor = a.getInt(R.styleable.LRatingBottomSheetView_colorText, 0)
        title = a.getString(R.styleable.LRatingBottomSheetView_cardTitle) ?: title
        subTitle = a.getString(R.styleable.LRatingBottomSheetView_cardSubTitle) ?: subTitle
        showActionBtn = a.getBoolean(R.styleable.LRatingBottomSheetView_showBtn, true)
        a.recycle()
    }
}
