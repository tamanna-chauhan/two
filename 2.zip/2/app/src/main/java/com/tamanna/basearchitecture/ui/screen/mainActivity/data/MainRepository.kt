package com.tamanna.basearchitecture.ui.screen.mainActivity.data

import androidx.lifecycle.distinctUntilChanged
import com.tamanna.basearchitecture.data.models.ProcessPayloadDTO
import com.tamanna.basearchitecture.data.models.SendOtpDTO
import com.tamanna.basearchitecture.data.models.base.ResponseDTO
import com.tamanna.basearchitecture.worker.networkLiveData

class MainRepository constructor(
    private val mainRemoteSource: MainRemoteDataSource,
    ) {
//    fun logout(tamannaId: String) = networkLiveData(
//        networkCall = {
//            mainRemoteSource.logout(tamannaId)
//        }
//    ).distinctUntilChanged()
//
    fun getList(userId: String, roleId: String, process: String) =networkLiveData(
        networkCall = {
            val send = ProcessPayloadDTO(userId= userId, roleId= roleId, process=process )
            mainRemoteSource.getList(send)
        }
    ).distinctUntilChanged()


    fun getErrorList() =networkLiveData(
        networkCall = {
            mainRemoteSource.getErrorList()
        }
    ).distinctUntilChanged()


}
