package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName

data class WeekResDTO(
        @field:SerializedName("weekDetail") val weekDetail: WeekDetailDTO,
        @field:SerializedName("weekDays") val weekDays: List<WeekDaysDTO>? = null,

        )

data class WeekDetailDTO(
        @field:SerializedName("totalLoginHour") val totalLoginHour: Int,
        @field:SerializedName("totalLoginMins") val totalLoginMins: Int,
        @field:SerializedName("earnings") val earnings: Double,
        @field:SerializedName("trips") val trips: Long,

        )


data class WeekDaysDTO(
        @field:SerializedName("trips") val trips: Long? = 0,
        @field:SerializedName("totalLoginHrs") val totalLoginHrs: Long? = 0,
        @field:SerializedName("totalLoginMins") val totalLoginMins: Long? = 0,
        @field:SerializedName("weekDayLabel") val weekDayLabel: String? = "",
        @field:SerializedName("createdAt") val createdAt: String? = "",
        @field:SerializedName("dayTrips") val dayTrips: List<DayTripDTO>? = null
)

data class DayTripDTO(
        @field:SerializedName("restaurant") val restaurant: String? = "",
        @field:SerializedName("createdAt") val createdAt: String? = "",
        @field:SerializedName("completedAt") val completedAt: String? = "",
        @field:SerializedName("timeDiff") val timeDiff: TimeDiffDTO,


        )

data class TimeDiffDTO(
        @field:SerializedName("hour") val hour: Int? = 0,
        @field:SerializedName("minutes") val minutes: Int? = 0
)