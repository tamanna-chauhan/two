package com.tamanna.basearchitecture.util.dateformater

import org.joda.time.DateTime
import org.joda.time.DateTimeZone
import org.joda.time.LocalDate
import org.joda.time.format.DateTimeFormat
import java.text.SimpleDateFormat
import java.util.*


class UTCtoNormalDate {
    companion object {
        fun getDate(date: String): String? {
            val DATE_FORMAT = DateTimeFormat.forPattern("dd MMMM, yyyy")
            return DATE_FORMAT.print(DateTime.parse(date.substring(0, 10)))
        }

        fun isYesterday(date: String): Boolean? {
            return DateTime.parse(date.substring(0, 10))
                .isEqual(DateTime.parse(LocalDate.now().minusDays(1).toString()))
        }

        fun isToday(date: String): Boolean? {
            return DateTime.parse(date.substring(0, 10))
                .isEqual(DateTime.parse(LocalDate.now().toString()))
        }

        fun getDateTime(date: String): String? {
            val DATE_FORMAT = DateTimeFormat.forPattern("dd MMMM, yyyy HH:mm a").withZone(
                DateTimeZone.getDefault()
            )
            return DATE_FORMAT.print(DateTime.parse(date))

        }


        fun getime(date: String): String? {
            val DATE_FORMAT = DateTimeFormat.forPattern("HH:mm a").withZone(
                DateTimeZone.getDefault()
            )
            return DATE_FORMAT.print(DateTime.parse(date))

        }

        fun getDateMillis(date: String): Long {
            return DateTime.parse(date.substring(0, 10)).millis
        }

        fun getCurrentDate(): String {
            val c = Calendar.getInstance().time
            val df = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.getDefault())
            df.timeZone = TimeZone.getTimeZone("IST")
            val formatteISOdDate: String = df.format(c)
            return formatteISOdDate
        }

        fun getCurrentNormalDate(): String {
            val c = Calendar.getInstance().time
            val df = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val formatteISOdDate: String = df.format(c)
            return formatteISOdDate
        }

        fun convertToCustomFormat(dateStr: String?): String {
            val utc = TimeZone.getTimeZone("UTC")
            val sourceFormat = SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy")
            val destFormat = SimpleDateFormat("YYYY-MM-dd")
            sourceFormat.timeZone = utc
            val convertedDate = sourceFormat.parse(dateStr)
            return destFormat.format(convertedDate)
        }

        fun getMonthDate(dateStr: String?): String {
            val utc = TimeZone.getTimeZone("UTC")
            val sourceFormat = SimpleDateFormat("EEE MMM dd yyyy HH:mm:ss zzz")
            sourceFormat.timeZone = utc
            val destFormat = SimpleDateFormat("MMM dd")
            val convertedDate = sourceFormat.parse(dateStr)
            return destFormat.format(convertedDate)
        }

        fun getISOFormDate(dateStr: String?): String {
            val sourceFormat = SimpleDateFormat("EEE MMM dd yyyy HH:mm:ss zzz")
            sourceFormat.timeZone = TimeZone.getTimeZone("UTC")

            val destFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'")
            destFormat.timeZone = TimeZone.getTimeZone("IST")

            val convertedDate = sourceFormat.parse(dateStr)

            return destFormat.format(convertedDate)
        }

        fun getDateUTC_TO_IST(dateStr: String?): String {
            if (dateStr.isNullOrEmpty()) {
                return "null"
            } else {
                val DATE_FORMAT = DateTimeFormat.forPattern("dd MMMM, yyyy hh:mm a").withZone(
                    DateTimeZone.getDefault()
                )
                return DATE_FORMAT.print(DateTime.parse(dateStr))
            }
//            val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
//                Locale.getDefault())
//            dateFormat.timeZone =
//                TimeZone.getTimeZone("GMT")  // IMP !!!
//            Log.d("--date---",dateFormat.parse(dateStr).toString())


        }

        fun changeDateFormat(date: String): String? {
            val DATE_FORMAT = DateTimeFormat.forPattern("dd-MM-yyyy")
            return DATE_FORMAT.print(DateTime.parse(date))
        }

    }
}

