package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName

data class LoginHistoryResDTO(
        @field:SerializedName("currentDay") val currentDay: CurrentDayDTO,
        @field:SerializedName("currentWeek") val currentWeek: CurrentWeekDTO? = null,

        )

data class CurrentDayDTO(
        @field:SerializedName("timings") val timings: TimingsDTO,
        @field:SerializedName("earnings") val earnings: Double,
        @field:SerializedName("trips") val trips: Long,

        )

data class TimingsDTO(
    @field:SerializedName("hour") val hour: Int,
    @field:SerializedName("minutes") val minutes: Int
)

data class CurrentWeekDTO(
    @field:SerializedName("hour") val hour: Int? = 0,
    @field:SerializedName("minutes") val minutes: Int? = 0,
    @field:SerializedName("endDate") val endDate: String? = "",
    @field:SerializedName("startDate") val startDate: String? = ""

)