package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.LinearLayout
import com.tamanna.basearchitecture.R

import com.tamanna.basearchitecture.util.viewutils.fontutils.FontIconView

/**
 * Created by Bhupendra Kumar Sahu on 19-Aug-20.
 */
class LIonWithVerticalTextViews @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : LinearLayout(context, attrs, defStyleAttr, defStyleRes) {
     val header_txt: ComponentHeaderTextView
     val sub_header_txt: ComponentSubTitleTextView
     val title_txt: ComponentTitleTextView
     val dec_txt: ComponentDescriptionTextView
     val loc_icon: FontIconView
     val header_layout: LinearLayout



    var iconSubject: String? = null
        set(value) {
            if (value == null) {
                // arrowIcon.visibility = View.GONE
            } else {

                loc_icon.text = value
                loc_icon.visibility = View.VISIBLE
            }
            field = value
        }

    var showIcon: Boolean= false
        set(value) {
            if (value) {
                 loc_icon.visibility = View.VISIBLE
            } else {
                loc_icon.visibility = View.GONE
            }
            field = value
        }

    var hideTitle: Boolean= false
        set(value) {
            if (value) {
                 title_txt.visibility = View.GONE
            } else {
                title_txt.visibility = View.VISIBLE
            }
            field = value
        }
    var hideHeaderLayout: Boolean= false
        set(value) {
            if (value) {
                 header_layout.visibility = View.GONE
            } else {
                header_layout.visibility = View.VISIBLE
            }
            field = value
        }
    private var iconTextColor: Int = 0
        set(value) {

            loc_icon.setTextColor(value)
            field = value
        }



//    var ivSize: Int = 0
//        set(value) {
//            if (value == null) {
//                // arrowIcon.visibility = View.GONE
//            } else {
//                val iconParam =
//                    LinearLayout.LayoutParams(VUtil.dpToPx(ivSize), VUtil.dpToPx(ivSize))
//                arrowIcon.layoutParams = iconParam
//            }
//            field = value
//        }


     var header: CharSequence = ""
        set(value) {
            header_txt.header=value
            field = value
        }


     var colorText: CharSequence = ""
        set(value) {
            sub_header_txt.subTitle=value
            field = value
        }


     var title: CharSequence = ""
        set(value) {
            title_txt.title=value
            field = value
        }

     var dec: CharSequence = ""
        set(value) {
            dec_txt.description=value
            field = value
        }


    init {
        clipToPadding = false
        val view = View.inflate(context, R.layout.view_icon_with_vertical_texts, this)
        header_txt = view.findViewById(R.id.header_txt)
        header_layout = view.findViewById(R.id.header_layout)
        sub_header_txt = view.findViewById(R.id.sub_header_txt)
        title_txt = view.findViewById(R.id.title_txt)
        dec_txt = view.findViewById(R.id.dec_txt)
        loc_icon = view.findViewById(R.id.loc_icon)
        val a = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.LIonWithVerticalTextViews,
            defStyleAttr,
            defStyleRes
        )
        iconSubject = a.getString(R.styleable.LIonWithVerticalTextViews_fontIcon)?: iconSubject
        iconTextColor = a.getInt(R.styleable.LIonWithVerticalTextViews_fontIconColor, 0)
        header = a.getString(R.styleable.LIonWithVerticalTextViews_cardHeader) ?: header
        colorText = a.getString(R.styleable.LIonWithVerticalTextViews_setText) ?: colorText
        title = a.getString(R.styleable.LIonWithVerticalTextViews_cardTitle) ?: title
        dec = a.getString(R.styleable.LIonWithVerticalTextViews_cardDescription) ?: dec
        showIcon = a.getBoolean(R.styleable.LIonWithVerticalTextViews_showIcon,false)
        hideTitle = a.getBoolean(R.styleable.LIonWithVerticalTextViews_hideTitle,false)
        hideHeaderLayout = a.getBoolean(R.styleable.LIonWithVerticalTextViews_hideHeaderLayout,false)
        a.recycle()
    }
}