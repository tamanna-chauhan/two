package com.tamanna.basearchitecture.ui.base

import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.ConnectivityManager
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.res.ResourcesCompat
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import com.google.android.material.snackbar.Snackbar
import com.laalsa.laalsalib.ui.VUtil
import com.laalsa.laalsalib.ui.px
import com.laalsa.laalsalib.utilcode.util.ClickUtils
import com.laalsa.laalsalib.utilcode.util.ToastUtils
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.data.models.base.APIConstant
import com.tamanna.basearchitecture.ui.base.actiondialog.ActionDialog
import com.tamanna.basearchitecture.ui.helper.AlerterHelper
import com.tamanna.basearchitecture.ui.helper.ThemeConstant
import com.tamanna.basearchitecture.util.IConstants
import com.tamanna.basearchitecture.worker.internetdetect.NetworkStateReceiver
import org.koin.android.ext.android.inject


abstract class BaseActivity<B : ViewDataBinding, T : BaseViewModel<*>> :
        AppCompatActivity(), IView, NetworkStateReceiver.NetworkStateReceiverListener {
    open val navigationPadding = true
    open lateinit var bd: B
    abstract val vm: T
    private var mProgressBar: ProgressBar? = null
    private var frameLayout: FrameLayout? = null
    lateinit var rootView: ConstraintLayout
    private var networkStateReceiver: NetworkStateReceiver? = null


//    private val noInternetBinding by lazy {
//        LayoutBaseNoInternetBinding.inflate(layoutInflater, rootView, true)
//    }

//    open val sharedPrefsHelper: SharedPrefsHelper by inject()

//    abstract fun initViewModel()


    protected fun bindView(layoutId: Int) {
        bd = DataBindingUtil.setContentView(this, layoutId)
        bd.lifecycleOwner = this


    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vm.attachView(this)
        networkStateReceiver = NetworkStateReceiver()
        networkStateReceiver!!.addListener(this)
//        ConnectivityManager().registerDefaultNetworkCallback()
        this.registerReceiver(
                networkStateReceiver,
                IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION)
        )
    }


    /**warning:
     * The root of the activity container must be of type ConstraintLayout
     *  DO NOT CHANGE THIS CONSISTENCY
     * */
    override fun setContentView(layoutResID: Int) {
        rootView =
                LayoutInflater.from(this).inflate(layoutResID, null) as ConstraintLayout
        rootView.addView(initFrame())
        super.setContentView(rootView)
    }


    override fun setContentView(view: View?) {
        rootView = getConstraintLayout()
        rootView.addView(view, 0)
        rootView.addView(frameLayout, 1)
        super.setContentView(rootView)

    }


    override fun setContentView(view: View?, params: ViewGroup.LayoutParams?) {
        rootView = getConstraintLayout()
        rootView.addView(view, 0)
        rootView.addView(frameLayout, 1)
        super.setContentView(rootView, params)
    }



    private fun showProgressBar(visibility: Boolean) {
        mProgressBar?.visibility = if (visibility) View.VISIBLE else View.INVISIBLE
//        if (visibility) frameLayout.setBackgroundColor(0x3CFFFFFF)
//        else frameLayout.background = null
        frameLayout?.isClickable = visibility
    }

    open fun applyDebouncingClickListener(vararg views: View?) {
        ClickUtils.applyGlobalDebouncing(views, mClickListener)
        ClickUtils.applyPressedViewScale(*views)
    }

    override fun hideProgressBar() {
        frameLayout?.setOnClickListener(null)
        showProgressBar(false)
    }

    override fun showProgressBar() {
        frameLayout?.setOnClickListener { }
        showProgressBar(true)

    }

    override fun onResponse(code: Int?, response: Any?, title: String?, message: String) {
        if (response is DisplayTypeDTO) {
            when (response.displayType) {
                IConstants.DisplayType.TOAST -> {
                    if (response.title.isNullOrEmpty())
                        displayToast(response.message)
                    else {
                        displayToast(response.title + "\n" + response.message)
                    }
                }
                IConstants.DisplayType.DIALOG -> {
                    ActionDialog(response.code, response.title, "\ue001", response.message, null, null).show(supportFragmentManager, "Dialog")
                }
                IConstants.DisplayType.SNACKBAR -> {
                    showSnackBar(response.message, ResourcesCompat.getColor(resources, R.color.colorGreenAccent, theme))
                }
                else -> {
                    AlerterHelper.showToast(this, response.title ?: "", response.message)
                }
            }

        }
    }


    private fun displayToast(message: CharSequence) {
        ToastUtils.showLong(message)
    }

    private fun getConstraintLayout(): ConstraintLayout {
        val constraintLayout = ConstraintLayout(this)
        constraintLayout.layoutParams =
                LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                )
        initFrame()
        return constraintLayout
    }

    private fun initFrame(): FrameLayout {
        frameLayout = FrameLayout(this)
        val frameParam = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        frameLayout?.background = null
        frameParam.gravity = Gravity.CENTER
        frameLayout?.layoutParams = frameParam
        mProgressBar = ProgressBar(this)
        mProgressBar?.background = null
        mProgressBar?.visibility = View.GONE
//        mProgressBar?.elevation = 6f
        val pbParam: FrameLayout.LayoutParams = FrameLayout.LayoutParams(45.px, 45.px)
        pbParam.gravity = Gravity.CENTER
        mProgressBar?.layoutParams = pbParam
        frameLayout?.addView(mProgressBar)
        return frameLayout!!

    }


    open fun showSnackBar(message: String, statusColor: Int) {
        val snackBar = Snackbar.make(rootView, message, Snackbar.LENGTH_SHORT)
        val viewGroup = snackBar.view as ViewGroup
        viewGroup.minimumHeight = VUtil.dpToPx(0)
        viewGroup.getChildAt(0).background = null
        /*  user Color code from ui developer*/
        viewGroup.background = ColorDrawable(Color.BLACK)
        val textView = (viewGroup.getChildAt(0) as ViewGroup).getChildAt(0) as TextView
        textView.background = null
        textView.setTextColor(ThemeConstant.white)
        snackBar.setActionTextColor(Color.WHITE)
        snackBar.show()
    }

    open fun showError(message: String) {
        val snackBar = Snackbar.make(rootView, message, Snackbar.LENGTH_SHORT)
        val viewGroup = snackBar.view as ViewGroup
        viewGroup.minimumHeight = 0
        viewGroup.background = ColorDrawable(Color.BLACK)
        val textView = (viewGroup.getChildAt(0) as ViewGroup).getChildAt(0) as TextView
        textView.setTextColor(Color.WHITE)
        textView.maxLines = 3
        textView.textSize = 12f
        textView.gravity = Gravity.CENTER
        snackBar.show()
    }


    open fun showToast(title: String?, message: String) {
        AlerterHelper.showToast(this, title ?: "", message)
//        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    fun applyDebounceClickListener(vararg views: View) {
        ClickUtils.applyGlobalDebouncing(views, mClickListener)
        ClickUtils.applyPressedViewScale(*views)
    }

    override fun showCodeError(code: Int?, title: String?, message: String) {
        when (code) {

            APIConstant.Status.ERROR -> {
                AlerterHelper.showError(this, title, message)
            }
        }
    }


    private var internetDisconnected = false
    override fun networkAvailable() {
        if (internetDisconnected) {
            AlerterHelper.showSuccess(this, "Internet available", "we are back online")
            internetDisconnected = false
        }

    }

    override fun networkUnavailable() {
        AlerterHelper.showError(this, "No Internet", "could not connect to internet")
        internetDisconnected = true
    }

    override fun onDestroy() {
        vm.detachView()
        networkStateReceiver?.removeListener(this)
        this.unregisterReceiver(networkStateReceiver)
//        bd?.lifecycleOwner = null
        super.onDestroy()

//
    }

    private val mClickListener = View.OnClickListener { onDebounceClick(it) }
    open fun onDebounceClick(view: View) {
    }

//    open fun bindTitleView(): CommonActivityTitleView? = null
//    open val bindTitle: CharSequence = "Application"
//    open val isSupportScroll = true

}