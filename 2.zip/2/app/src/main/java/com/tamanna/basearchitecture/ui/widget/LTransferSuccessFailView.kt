package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.LinearLayout
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.util.YUtils

import com.tamanna.basearchitecture.util.viewutils.fontutils.FontIconView

/**
 * Created by Bhupendra Kumar Sahu on 20-Aug-20.
 */
class LTransferSuccessFailView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : LinearLayout(context, attrs, defStyleAttr, defStyleRes) {
    val tvTitle: ComponentTitleTextView
    val tvSubTitle: ComponentSubTitleTextView
    val tvHeader: ComponentHeaderTextView
    val tvDescription: ComponentDescriptionTextView
    val crossIcon: FontIconView
    val actionButton: ComponentButton
    val infoImageview: ComponentImageView

    var ivInfo: String? = ""
        set(value) {
            value?.let { YUtils.setImageInView(infoImageview.imageview, it) }

            field = value
        }


    private var iconTextColor: Int? = 0
        set(value) {
            if (value == null) {
                // fontIcon.visibility = View.GONE
            } else {

                crossIcon.setTextColor(value)
            }
            field = value
        }
  private var iconText: String? = ""
        set(value) {
            if (value == null) {
                // fontIcon.visibility = View.GONE
            } else {

                crossIcon.text = value
            }
            field = value
        }

    private var title: String? = null
        set(value) {
            if (value == null) {
                // fontIcon.visibility = View.GONE
            } else {

                tvTitle.title = value
                tvTitle.visibility = View.VISIBLE
            }
            field = value
        }


    private var subTitle: String? = null
        set(value) {
            if (value == null) {
                // fontIcon.visibility = View.GONE
            } else {

                tvSubTitle.subTitle = value
                tvSubTitle.visibility = View.VISIBLE
            }
            field = value
        }
    private var header: String? = null
        set(value) {
            if (value == null) {
                // fontIcon.visibility = View.GONE
            } else {

                tvHeader.header = value
                tvHeader.visibility = View.VISIBLE
            }
            field = value
        }
    private var description: String? = null
        set(value) {
            if (value == null) {
                // fontIcon.visibility = View.GONE
            } else {

                tvDescription.description = value
                tvDescription.visibility = View.VISIBLE
            }
            field = value
        }

    private var showBtn: Boolean=true
        set(value) {
            if (value) {
                actionButton.visibility = View.VISIBLE
            } else {

                actionButton.visibility = View.GONE
            }
            field = value
        }
    var alignmentCenter: Boolean = true
        set(value) {
            if (value) {
                tvTitle.alignmentCenter=value
                tvSubTitle.alignmentCenter=value
            } else {
                tvTitle.alignmentCenter=value
                tvSubTitle.alignmentCenter=value
            }
            field = value
        }

    init {
        clipToPadding = false
        val view = View.inflate(context, R.layout.view_transfer_success_fail, this)
        tvHeader = view.findViewById(R.id.tsf_tv_header)
        tvDescription = view.findViewById(R.id.tsf_tv_description)
        infoImageview = view.findViewById(R.id.tfs_imageview)
        tvTitle = view.findViewById(R.id.tsf_tv_title)
        tvSubTitle = view.findViewById(R.id.tsf_tv_subtitle)
        crossIcon = view.findViewById(R.id.tsf_icon_cross)
        actionButton = view.findViewById(R.id.action_btn)
        val a = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.LTransferSuccessFailView,
            defStyleAttr,
            defStyleRes
        )
        title = a.getString(R.styleable.LTransferSuccessFailView_cardTitle) ?: title
        ivInfo = a.getString(R.styleable.LTransferSuccessFailView_imageUrl) ?: ivInfo
        subTitle = a.getString(R.styleable.LTransferSuccessFailView_cardSubTitle) ?: subTitle
        header = a.getString(R.styleable.LTransferSuccessFailView_cardHeader) ?: header
        description = a.getString(R.styleable.LTransferSuccessFailView_cardDescription) ?: description
        iconText = a.getString(R.styleable.LTransferSuccessFailView_fontIcon) ?: iconText
        iconTextColor = a.getInt(R.styleable.LTransferSuccessFailView_fontIconColor, 0)
        showBtn = a.getBoolean(R.styleable.LTransferSuccessFailView_showBtn, true)
        alignmentCenter = a.getBoolean(R.styleable.LTransferSuccessFailView_alignmentCenter, true)


        a.recycle()
    }
}