package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName

/**
 * Created by Bhupendra Kumar Sahu on 10-Feb-21.
 */
data class WeeklyEarningsResDTO(
    @field:SerializedName("endDate") val endDate: String? = "",
    @field:SerializedName("startDate") val startDate: String? = "",
    @field:SerializedName("earnings") val earnings: Double,
    @field:SerializedName("hour") val hour: Int,
    @field:SerializedName("minutes") val minutes: Int,
    @field:SerializedName("trips") val trips: Long,
    @field:SerializedName("week") val week: Int,

    )