package com.tamanna.basearchitecture.api

import com.tamanna.basearchitecture.data.models.ProcessDTO
import com.tamanna.basearchitecture.data.models.ProcessPayloadDTO
import com.tamanna.basearchitecture.data.models.SendOtpDTO
import com.tamanna.basearchitecture.data.models.base.APIConstant
import com.tamanna.basearchitecture.data.models.base.ResponseDTO
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface ProcessServiceAPI {

    @POST(APIConstant.URL.GET_LIST)
    suspend fun getList(@Body payload: ProcessPayloadDTO): Response<List<ProcessDTO>>

    @GET(APIConstant.URL.GET_ERROR_LIST)
    suspend fun getErrorList(): Response<List<ProcessDTO>>

}