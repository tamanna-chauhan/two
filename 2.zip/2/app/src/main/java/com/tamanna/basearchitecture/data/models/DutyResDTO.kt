package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName

data class DutyResDTO(
    @field:SerializedName("operationalStatus") val operationalStatus: Boolean
)