/*
 *   Created by Sourav Kumar Pandit  22 - 4 - 2020
 */

package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName


data class TransferToBankResDTO(
    val transactionDetails: TransactionDetailsDTO

)

data class TransactionDetailsDTO(
    @field:SerializedName("type") val type: String,
    @field:SerializedName("tamannaId") val tamannaId: String,
    @field:SerializedName("amount") val amount: String,
    @field:SerializedName("transactionId") val transactionId: String,
    @field:SerializedName("status") val status: String


)
