/*
 *   Created by Sourav Kumar Pandit  22 - 4 - 2020
 */

package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName


data class WalletSummaryResDTO(
    @field:SerializedName("yourBalance") val yourBalance: Double,
    @field:SerializedName("transferableAmount") val transferableAmount: Double,
    @field:SerializedName("cashOnHand") val cashOnHand: Double,
    @field:SerializedName("nextSkip") val nextSkip: Long,
)

