/*
 * Copyright 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.os.Build
import android.util.AttributeSet
import android.view.View
import android.widget.LinearLayout
import androidx.appcompat.content.res.AppCompatResources
import androidx.appcompat.widget.AppCompatTextView
import androidx.core.widget.TextViewCompat
import com.tamanna.basearchitecture.R


class TypeAttributeView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : LinearLayout(context, attrs, defStyleAttr, defStyleRes) {

    private val typeAttributeTextView: AppCompatTextView
    private val typeAttributePreviewTextView: AppCompatTextView

    var typeAttrText: String = "?textAppearanceHeadline1"
        set(value) {
            typeAttributeTextView.text = value
            field = value
        }

    var typeAttrPreviewText: String = context.getString(R.string.text_appearance_h1_label)
        set(value) {
            typeAttributePreviewTextView.text = value
            field = value
        }

    var typeAttrPreviewTextAppearance: Int = R.attr.textAppearanceHeadline1
        set(value) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                typeAttributePreviewTextView.setTextAppearance(value)
            } else {
                TextViewCompat.setTextAppearance(typeAttributePreviewTextView, value)
            }
            field = value
        }

    var typeAttrPreviewTextColor = AppCompatResources.getColorStateList(
        context,
        R.color.material_on_background_emphasis_high_type
    )
        set(value) {
            typeAttributePreviewTextView.setTextColor(value)
            field = value
        }

    init {
        orientation = LinearLayout.HORIZONTAL
        val view = View.inflate(context, R.layout.type_attribute_view_layout, this)
        typeAttributeTextView = view.findViewById(R.id.type_attribute)
        typeAttributePreviewTextView = view.findViewById(R.id.type_attribute_preview)

        val a = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.TypeAttributeView,
            defStyleAttr,
            defStyleRes
        )
        typeAttrText = a.getString(R.styleable.TypeAttributeView_android_text) ?: typeAttrText
        typeAttrPreviewText = a.getString(
            R.styleable.TypeAttributeView_previewText
        ) ?: typeAttrPreviewText
        typeAttrPreviewTextAppearance = a.getResourceId(
            R.styleable.TypeAttributeView_previewTextAppearance,
            typeAttrPreviewTextAppearance
        )
        typeAttrPreviewTextColor = a.getColorStateList(
            R.styleable.TypeAttributeView_previewTextColor
        ) ?: typeAttrPreviewTextColor
        a.recycle()
    }
}
