package com.tamanna.basearchitecture.ui.screen.test

import android.view.View
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.databinding.TestFragmentBinding
import com.tamanna.basearchitecture.ui.base.BaseFragment
import org.koin.androidx.viewmodel.ext.android.viewModel

class TestFragment : BaseFragment<TestFragmentBinding, TestViewModel>() {
    private val IMAGE_URL = "https://upload.wikimedia.org/wikipedia/commons/d/d7/Android_robot.svg"

    override val fvm: TestViewModel by viewModel()

    override fun getLayoutId(): Int = R.layout.test_fragment

    override fun onFragmentReady(view: View) {
//        BarUtils.setStatusBarColor(requireActivity().window, Color.WHITE)
//        BarUtils.setStatusBarLightMode(requireActivity(),false)
//        BarUtils.setStatusBarColor(requireActivity(), ColorUtils.getColor(R.color.colorPrimary))
//        BarUtils.addMarginTopEqualStatusBarHeight(view)
    }

}