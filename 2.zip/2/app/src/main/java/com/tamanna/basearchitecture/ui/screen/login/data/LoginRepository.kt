package com.tamanna.basearchitecture.ui.screen.signup.data

import androidx.lifecycle.distinctUntilChanged
import com.tamanna.basearchitecture.data.models.SendOtpDTO
import com.tamanna.basearchitecture.ui.screen.login.data.LoginRemoteDataSource
import com.tamanna.basearchitecture.worker.networkLiveData

class LoginRepository constructor(
    private val remoteSource: LoginRemoteDataSource
) {
    fun loginSendOtp(number: String, countryCode: String, method: String) = networkLiveData(
        networkCall = {
            val send =
                SendOtpDTO(mobile = number, countryCode = countryCode, method = method)
            remoteSource.loginSendOtp(send)
        }
    ).distinctUntilChanged()
}
