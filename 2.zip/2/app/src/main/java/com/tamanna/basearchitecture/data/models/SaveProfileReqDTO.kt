package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName


data class SaveProfileReqDTO(
    @field:SerializedName("tamannaId") val tamannaId: String,
    @field:SerializedName("dl") val dl: String,
    @field:SerializedName("aadhaar") val aadhaar: String,
    @field:SerializedName("name") val name: String,
    @field:SerializedName("email") val email: String,
    @field:SerializedName("mobile") val mobile: String,
    @field:SerializedName("workingMode") val workingMode: String,
    @field:SerializedName("bankDetails") val bankDetails: BankDetailsDTO,
)