package com.tamanna.basearchitecture.api

import com.tamanna.basearchitecture.pref.RiderInfo
import okhttp3.Interceptor
import okhttp3.Response
class AuthInterceptor : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val requestBuilder = chain.request().newBuilder()
        // If token has been saved, add it to the request
        RiderInfo.accessToken.let {
            it?.let { it1 -> requestBuilder.addHeader("x-access-token", it1) }
        }

        return chain.proceed(requestBuilder.build())
    }
}