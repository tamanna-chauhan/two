package com.tamanna.basearchitecture.ui.screen.test

import com.tamanna.basearchitecture.ui.base.IView

interface ITestView : IView
