package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.LinearLayout
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.databinding.ViewVerticalLabelBinding
import com.tamanna.basearchitecture.ui.helper.hideEmptyTextView


/**
 * Created by Bhupendra Kumar Sahu on 21-Aug-20.
 */
class LVerticalLabelView : LinearLayout {

//    var title: CharSequence = ""
//        set(value) {
//            field = value
//            binding.lableHeader.tv_header.hideEmptyTextView(field)
//        }

    var subTitle: CharSequence = ""
        set(value) {
            field = value
            binding.labelDescription.tv_description.hideEmptyTextView(field)

        }
    var alignmentCenter: Boolean = true
        set(value) {
            if (value) {
                binding.labelDescription.alignmentCenter = value
                binding.lableHeader.alignmentCenter = value
            } else {
                binding.labelDescription.alignmentCenter = value
                binding.lableHeader.alignmentCenter = value

            }
            field = value
        }
    private val binding by lazy {
        val layoutInflater = LayoutInflater.from(context)
        ViewVerticalLabelBinding.inflate(
            layoutInflater,
            this,
            true
        )
    }

    constructor(context: Context) : this(context, null, 0)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {

        if (attrs != null) {

            val a = context.theme.obtainStyledAttributes(
                attrs,
                R.styleable.LVerticalLabelView,
                defStyleAttr,
                0
            )
//            title = a.getString(R.styleable.LVerticalLabelView_cardTitle) ?: title
            subTitle = a.getString(R.styleable.LVerticalLabelView_cardSubTitle) ?: subTitle
            alignmentCenter = a.getBoolean(R.styleable.LVerticalLabelView_alignmentCenter, true)

            a.recycle()
        }
    }

    fun setPrice(price: Double) {
        binding.lableHeader.setPrice(price)

    }

    fun setTrip(trip: Long) {
        binding.lableHeader.setTrip(trip)

    }

    fun setLoginHrMin(hour: Int, minutes: Int) {
        binding.lableHeader.setLoginHrMin(hour, minutes)

    }
}