package com.tamanna.basearchitecture.ui.worker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.tamanna.basearchitecture.ui.screen.mainActivity.MainActivity

class SseBroadCast : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        val i = Intent(context, MainActivity::class.java)
        i.action = ACTION_NEW_TASK
        if (intent != null) {
            i.putExtras(intent)
        } else {
            return
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        i.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        context?.startActivity(i)
    }
    companion object {
        const val ACTION_NEW_TASK = "com.tamanna.basearchitecture.NEW_TASK_BROADCAST"
        const val ACTION_CANCEL_TASK = "com.tamanna.basearchitecture.CANCEL_TASK_BROADCAST"
        const val ACTION_ORDER_TASK = "com.tamanna.basearchitecture.CANCEL_ORDER_BROADCAST"
    }

}