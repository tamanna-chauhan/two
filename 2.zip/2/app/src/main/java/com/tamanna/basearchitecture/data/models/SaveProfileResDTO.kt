/*
 *   Created by Sourav Kumar Pandit  22 - 4 - 2020
 */

package com.tamanna.basearchitecture.data

import com.google.gson.annotations.SerializedName
import com.tamanna.basearchitecture.data.models.BankDetailsDTO


data class SaveProfileResDTO(
    @field:SerializedName("completionPercent") val completionPercent: Int? = 0,
    @field:SerializedName("body") val body: Body

)

data class Body(
    @field:SerializedName("tamannaId") val tamannaId: String?,
    @field:SerializedName("name") val name: String?,
    @field:SerializedName("mobile") val mobile: String?,
    @field:SerializedName("email") val email: String?,
    @field:SerializedName("workingMode") val workingMode: String?,
    @field:SerializedName("bankDetails") val bankDetails: BankDetailsDTO?,
    @field:SerializedName("aadhaar") val aadhaar: String?,
    @field:SerializedName("dl") val dl: String?
)

