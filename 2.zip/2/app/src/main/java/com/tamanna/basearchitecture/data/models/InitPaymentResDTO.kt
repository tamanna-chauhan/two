package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class InitPaymentResDTO(

    @field:SerializedName("qrCodeId") val qrCodeId: String,
    @field:SerializedName("qrData") val qrData: String,
    @field:SerializedName("image") val image: String
) : Serializable
