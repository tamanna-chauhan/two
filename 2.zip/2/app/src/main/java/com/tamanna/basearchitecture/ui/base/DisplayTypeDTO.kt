package com.tamanna.basearchitecture.ui.base

data class DisplayTypeDTO(val displayType: String, val code: Int, val title: String?, val message: String, val action: Int)
