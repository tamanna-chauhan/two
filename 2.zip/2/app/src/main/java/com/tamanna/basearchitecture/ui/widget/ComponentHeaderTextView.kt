package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.ui.helper.appendPriceValue
import com.tamanna.basearchitecture.ui.helper.loginHours
import com.tamanna.basearchitecture.ui.helper.setTrip
import com.tamanna.basearchitecture.ui.helper.setkm


/**
 * Created by Bhupendra Kumar Sahu on 19-Aug-20.
 */
class ComponentHeaderTextView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : LinearLayout(context, attrs, defStyleAttr, defStyleRes)
{
     val tv_header: TextView

    var header: CharSequence = ""
        set(value) {
            if (value == null) {
                tv_header.visibility = View.INVISIBLE
                tv_header.text = ""
                return
            }
            tv_header.text = value
            field = value
        }

    var alignmentCenter: Boolean = false
        set(value) {
            if (value) {
                tv_header.textAlignment= View.TEXT_ALIGNMENT_CENTER
            } else {
                tv_header.textAlignment= View.TEXT_ALIGNMENT_TEXT_START
            }
            field = value
        }
    init {
        clipToPadding = false
        val view = View.inflate(context, R.layout.type_attribute_header_text, this)
        tv_header = view.findViewById(R.id.tv_header)

        val a = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.ComponentHeaderTextView,
            defStyleAttr,
            defStyleRes
        )

        header = a.getString(R.styleable.ComponentHeaderTextView_cardHeader) ?: header
        alignmentCenter = a.getBoolean(R.styleable.ComponentHeaderTextView_alignmentCenter, false)
        a.recycle()
    }

    fun setLoginHrMin(hour: Int, minutes: Int) {
        tv_header.loginHours(hour, minutes)
    }

    fun setPrice(price: Double) {
        tv_header.appendPriceValue(price)
    }

    fun setKm(km: Double) {
        tv_header.setkm(km)
    }

    fun setTrip(trip: Long) {
        tv_header.setTrip(trip)
    }
}