package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import com.laalsa.laalsalib.ui.VUtil
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.util.YUtils

import kotlin.math.roundToInt

/**
 * Created by Bhupendra Kumar Sahu on 19-Aug-20.
 */
class ComponentImageView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : LinearLayout(context, attrs, defStyleAttr, defStyleRes) {
    val imageview: ImageView

    var imageUrl: String? = ""
        set(value) {
            field = value
            value?.let { YUtils.setImageInView(imageview, it) }

        }
    var ivSize: Float = VUtil.dpToPx(45).toFloat()

        set(value) {
            field = value
            imageview.maxHeight = value.roundToInt()
            imageview.maxWidth = value.roundToInt()

        }

    init {
        clipToPadding = false
        val view = View.inflate(context, R.layout.type_attribute_imageview, this)
        imageview = view.findViewById(R.id.imageview)

        val a = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.ComponentImageView,
            defStyleAttr,
            defStyleRes
        )
        imageUrl = a.getString(R.styleable.ComponentImageView_imageUrl) ?: imageUrl
        ivSize = a.getDimension(R.styleable.ComponentImageView_imageSize,ivSize)

    }
}