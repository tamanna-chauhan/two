package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import com.tamanna.basearchitecture.R


/**
 * Created by Bhupendra Kumar Sahu on 19-Aug-20.
 */
class LButtonToggleComponent @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : LinearLayout(context, attrs, defStyleAttr, defStyleRes) {
    val actionButton: Button

     var actionCancel: CharSequence = ""
        set(value) {

            actionButton.text = value
            field = value
        }

    init {
        clipToPadding = false
        orientation = LinearLayout.HORIZONTAL
        val view = View.inflate(context, R.layout.component_button_outline, this)
        actionButton = view.findViewById(R.id.action_button)
        val a = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.LButtonToggleComponent,
            defStyleAttr,
            defStyleRes
        )
        actionCancel = a.getString(R.styleable.LButtonToggleComponent_buttonText) ?: actionCancel
        a.recycle()
    }
}