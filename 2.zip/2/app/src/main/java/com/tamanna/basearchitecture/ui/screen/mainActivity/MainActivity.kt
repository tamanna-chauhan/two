package com.tamanna.basearchitecture.ui.screen.mainActivity

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.CompoundButton
import androidx.annotation.RequiresApi
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SwitchCompat
import androidx.core.os.bundleOf
import androidx.core.view.GravityCompat
import androidx.core.view.isGone
import androidx.drawerlayout.widget.DrawerLayout
import androidx.navigation.Navigation
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.NavigationUI
import androidx.navigation.ui.navigateUp
import com.google.android.material.navigation.NavigationView
import com.laalsa.laalsalib.utilcode.util.BarUtils
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.data.models.TaskInfoDTO
import com.tamanna.basearchitecture.data.models.base.APIConstant
import com.tamanna.basearchitecture.databinding.ActivityMainBinding
import com.tamanna.basearchitecture.pref.AppPref
import com.tamanna.basearchitecture.pref.RiderInfo
import com.tamanna.basearchitecture.ui.base.BaseActivity
import com.tamanna.basearchitecture.ui.screen.mainActivity.viewModel.MainViewModel
import com.tamanna.basearchitecture.ui.screen.setting.ChangeLanguageSheet
import com.tamanna.basearchitecture.util.IConstants
import com.tamanna.basearchitecture.util.viewutils.YumUtil
import org.koin.androidx.viewmodel.ext.android.viewModel


@SuppressLint("LogNotTimber")
class MainActivity : BaseActivity<ActivityMainBinding, MainViewModel>(), IMainView,
        NavigationView.OnNavigationItemSelectedListener {

    private val navController by lazy { findNavController(R.id.nav_host_fragment) }
    private lateinit var appBarConfiguration: AppBarConfiguration

    override val vm: MainViewModel by viewModel()

    private lateinit var switchDark: SwitchCompat
    private lateinit var switchStatus: SwitchCompat

    // Declare the UpdateManager
//    val mUpdateManager by lazy { UpdateManager.Builder(this).mode(UpdateManagerConstant.IMMEDIATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        this.bindView(R.layout.activity_main)
        setSupportActionBar(bd.mainContainer.mainToolbar)

        if (RiderInfo.accessToken.isNullOrEmpty()) {
            bd.drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED, bd.navView)
        } else {
            bd.drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED, bd.navView)
        }


        BarUtils.addMarginTopEqualStatusBarHeight(bd.navView)
        initNavigationSwitch()
        setupNavigationController()
        restoreTheme()

        bd.navView.setNavigationItemSelectedListener(this)

        val actionBarDrawerToggle: ActionBarDrawerToggle = object : ActionBarDrawerToggle(
            this,
            bd.drawerLayout,
            null,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        ) {
            override fun onDrawerOpened(drawerView: View) {
                super.onDrawerOpened(drawerView)
                //TODO do something.
            }
        }

        //Setting the actionbarToggle to drawer layout
        bd.drawerLayout.addDrawerListener(actionBarDrawerToggle)

        //calling sync state is necessary or else your hamburger icon wont show up
        actionBarDrawerToggle.syncState()

        //Checking for overlay permission and battery optimization permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Log.v("App", "Build Version Greater than or equal to M: " + Build.VERSION_CODES.M)
            YumUtil.executeWithDelay(1200) {
                checkDrawOverlayPermission()
            }
            YumUtil.executeWithDelay(1500) {
                checkBatteryOptimizationPermission()
            }
        } else {
            Log.v("App", "OS Version Less than M")
            //No need for Permission as less then M OS.
        }

//        mUpdateManager.start()
    }

    private fun initNavigationSwitch() {
        switchDark = bd.navView.menu.findItem(R.id.nav_dark).actionView as SwitchCompat
        switchStatus =
                bd.navView.menu.findItem(R.id.nav_duty_status).actionView as SwitchCompat
        switchStatus.setOnCheckedChangeListener(this) // See below!
        switchDark.setOnCheckedChangeListener(this) // See below!
    }

    private fun restoreTheme() {
        switchDark.isChecked = AppPref.darkTheme
        changeTheme(AppPref.darkTheme)
    }


    private fun changeTheme(isChecked: Boolean) {
        BarUtils.setStatusBarLightMode(this, !isChecked)
        val darkThemed: Int = if (isChecked) {
            AppCompatDelegate.MODE_NIGHT_YES
        } else {
            AppCompatDelegate.MODE_NIGHT_NO
        }
        AppCompatDelegate.setDefaultNightMode(darkThemed) // Change the theme at runtime
    }

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }

    private fun hideAppBarLayout() {
        bd.mainContainer.mainToolbar.isGone = true
    }

    private fun showAppbarLayout() {
        bd.mainContainer.mainToolbar.isGone = false
    }



    fun setProfileDetails() {}

    override fun networkUnavailable() {
        super.networkUnavailable()
        val bundle = bundleOf(
            "action" to 404,
            "imgDrawable" to R.drawable.ic_no_internet,
            "title" to getString(R.string.no_internet),
            "message" to getString(R.string.lorem_ipsum),
        )
        navController.navigate(R.id.nav_no_data, bundle)
    }

    override fun networkAvailable() {
        super.networkAvailable()
        if (navController.currentDestination?.id == R.id.nav_no_data) {
            super.onBackPressed()
        }
    }


    override fun onCheckedChanged(buttonView: CompoundButton?, isChecked: Boolean) {
        when (buttonView) {
            switchStatus -> {
                if (isChecked) {
                    switchStatus.text = getString(R.string.online)
                } else {
                    switchStatus.text = getString(R.string.offline)
                }
//                updateSseService(isChecked)
                return
            }
            switchDark -> {
                AppPref.darkTheme = isChecked
                changeTheme(isChecked)
            }
        }
    }


    override fun onSuccess(actionId: Int, data: Any?) {
        when (actionId) {
        }
    }

    fun openDestinationFragment(taskInfoDTO: TaskInfoDTO) {

    }

    private fun singOutRider() {
       /* vm.logout(RiderInfo.tamannaId).observe(this, { result ->
            RHandler<Any>(this, result)

        })*/


    }
    private fun setupNavigationController() {
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
//        mToolbar = findViewById<View>(R.id.toolbar) as Toolbar
        setSupportActionBar(bd.mainContainer.mainToolbar)
        supportActionBar!!.setDisplayShowHomeEnabled(true)
        appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.bottom_home,
                R.id.bottom_cashflow,
                R.id.bottom_history,
                R.id.bottom_wallet,
                R.id.nav_earning,
                R.id.nav_demand_area,
                R.id.nav_help_support,
                R.id.nav_refer_earn,
                R.id.nav_faqs,
                R.id.nav_test_fragment,
                R.id.nav_config_frament,
            ), bd.drawerLayout
        )
        val navController = Navigation.findNavController(this, R.id.nav_host_fragment)
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration)
        NavigationUI.setupWithNavController(bd.navView, navController)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        NavigationUI.setupWithNavController(bd.mainContainer.bottomNavigation, navController)
//        val mDrawerToggle: ActionBarDrawerToggle


        navController.addOnDestinationChangedListener { controller, destination, arguments ->
            when (destination.id) {
                /*Bottom navigation and toolbar visible*/
                R.id.bottom_home,
                R.id.bottom_cashflow,
                R.id.bottom_history,
                R.id.bottom_wallet -> {
                    bd.mainContainer.bottomNavigation.visibility = View.VISIBLE
                    bd.mainContainer.mainToolbar.visibility = View.VISIBLE

                }
                /*Bottom navigation and toolbar gone*/
                R.id.nav_refer_earn -> {
                    bd.mainContainer.bottomNavigation.visibility = View.GONE
                    bd.mainContainer.mainToolbar.visibility = View.GONE
                }

//                TODO handle drawer lock case in login and signup case
                /*Bottom navigation gone  and toolbar visible*/
                else -> {
                    bd.mainContainer.bottomNavigation.visibility = View.GONE
                }
            }
        }
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        val closeDrawer = true
        if (!RiderInfo.accessToken.isNullOrEmpty()) {
            bd.drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED, bd.navView)
        }
        when (item.itemId) {
            R.id.nav_duty_status -> return false
            R.id.nav_dark -> return false
            R.id.nav_sign_out -> {

                singOutRider()
            }
            R.id.nav_language -> {
                val clFragmentManager = supportFragmentManager
                val changeLang = ChangeLanguageSheet()
//                changeLang.actionHandler = this
                changeLang.moduleId = IConstants.ActionModule.CHANGE_LANGUAGE
                changeLang.show(clFragmentManager, "Change Language")
            }
            R.id.nav_test_fragment -> navController.navigate(R.id.nav_test_fragment)
            R.id.nav_config_frament -> {
                AppPref.baseUrl = ""
                val baseUrl = AppPref.baseUrl
                navController.navigate(R.id.nav_config_frament)
                IConstants.BASE_URL = baseUrl
            }
        }
        if (closeDrawer)
            bd.drawerLayout.closeDrawer(GravityCompat.START)
        return NavigationUI.onNavDestinationSelected(item, navController) ||
                super.onOptionsItemSelected(item)


    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    fun checkDrawOverlayPermission() {
        Log.v("App", "Package Name: " + applicationContext.packageName)

        // Check if we already  have permission to draw over other apps
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent().apply {
                action = Settings.ACTION_MANAGE_OVERLAY_PERMISSION
                data = Uri.parse("package:" + applicationContext.packageName)
            }
            startActivity(intent)
        } else {
            Log.v("App", "We already have permission for canDrawOverLays.")
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    fun checkBatteryOptimizationPermission() {
        val intent = Intent().apply {
            action = Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS
            data = Uri.parse("package:${applicationContext.packageName}")
        }

        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            startActivity(intent)
        } else {
            Log.v("App", "We already have permission for BatterOptimization.")
        }
    }

    override fun onResponse(code: Int?, response: Any?, title: String?, message: String) {
        when (code) {
            APIConstant.Code.LOGOUT_USER -> {
                hideAppBarLayout()
                bd.drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED, bd.navView)
                AppPref.clear()
                RiderInfo.clear()
                showToast(getString(R.string.signout_successfully), "")
                navController.popBackStack(R.id.mobile_navigation, true)
                navController.navigate(R.id.fragment_started)
            }

            else -> super.onResponse(code, response, title ?: "", message)
        }
    }

}
