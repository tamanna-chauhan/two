package com.tamanna.basearchitecture.di

import com.tamanna.basearchitecture.ui.screen.login.LoginViewModel
import com.tamanna.basearchitecture.ui.screen.mainActivity.viewModel.MillingViewModel
import com.tamanna.basearchitecture.ui.screen.mainActivity.viewModel.SprayingViewModel
import com.tamanna.basearchitecture.ui.screen.mainActivity.viewModel.MainViewModel
import com.tamanna.basearchitecture.ui.screen.nodatascreen.NoDataViewModel
import com.tamanna.basearchitecture.ui.screen.otp.OtpViewModel
import com.tamanna.basearchitecture.ui.screen.setting.SettingViewModel
import com.tamanna.basearchitecture.ui.screen.signup.SignUpViewModel
import com.tamanna.basearchitecture.ui.screen.started.StartedViewModel
import com.tamanna.basearchitecture.ui.test.TestViewModel
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

fun viewModelModule() = module {


    viewModel { SignUpViewModel(get()) }
    viewModel { StartedViewModel() }
    viewModel { LoginViewModel(get()) }
    viewModel { OtpViewModel(get()) }
    viewModel { MainViewModel(get()) }

    viewModel { SettingViewModel() }
    viewModel { NoDataViewModel() }
    viewModel { TestViewModel(get()) }
    viewModel { SprayingViewModel(get()) }
    viewModel { MillingViewModel(get()) }

}