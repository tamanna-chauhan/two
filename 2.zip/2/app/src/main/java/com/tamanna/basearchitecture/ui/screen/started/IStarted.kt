package com.tamanna.basearchitecture.ui.screen.started

import com.tamanna.basearchitecture.ui.base.IView

/**
 * Created by Bhupendra Kumar Sahu on 18-Jan-21.
 */
interface IStarted : IView