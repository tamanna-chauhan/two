package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import androidx.constraintlayout.widget.ConstraintLayout
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.databinding.ViewLoginHistoryCardBinding
import com.tamanna.basearchitecture.ui.helper.hideEmptyTextView


class LLoginHistoryCard : ConstraintLayout {

//    var header: CharSequence? = ""
//        set(value) {
//            field = value
//            vbd.tvWorkingHr.tv_header.hideEmptyTextView(field.toString())
//        }

    var description: CharSequence? = ""
        set(value) {
            field = value
            vbd.tvDesWorkingHr.tv_description.hideEmptyTextView(field.toString())
        }
    var trip: CharSequence? = ""
        set(value) {
            field = value
            vbd.tvTrip.tv_description.hideEmptyTextView(field.toString())
        }
    var tripNo: CharSequence? = ""
        set(value) {
            field = value
            vbd.tvTotTripNo.tv_header.hideEmptyTextView(field.toString())
        }

    var priceDes: CharSequence? = ""
        set(value) {
            field = value
            vbd.tvPriceDes.tv_description.hideEmptyTextView(field.toString())
        }
    var seeDetails: CharSequence? = ""
        set(value) {
            field = value
            vbd.tvSeeFullDetails.tv_colored.hideEmptyTextView(field.toString())
        }

    var setTextColor: Int = 0
        set(value) {
            field = value
            vbd.tvSeeFullDetails.tv_colored.setTextColor(field)

        }
    var alignmentCenter: Boolean = true
        set(value) {
            if (value) {
                vbd.tvTotTripNo.alignmentCenter = value
                vbd.tvTrip.alignmentCenter = value
            } else {
                vbd.tvTotTripNo.alignmentCenter = value
                vbd.tvTrip.alignmentCenter = value

            }
            field = value
        }


    private val vbd by lazy {
        val layoutInflater = LayoutInflater.from(context)
        ViewLoginHistoryCardBinding.inflate(
            layoutInflater,
            this,
            true
        )
    }

    constructor(context: Context) : this(context, null, 0)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {

        if (attrs != null) {
            val a = context.theme.obtainStyledAttributes(
                attrs,
                R.styleable.LLoginHistoryCard,
                defStyleAttr,
                0
            )
//            header = a.getString(R.styleable.LLoginHistoryCard_cardHeader) ?: header
            description = a.getString(R.styleable.LLoginHistoryCard_cardDescription) ?: description
            tripNo = a.getString(R.styleable.LLoginHistoryCard_tripNo) ?: tripNo
            trip = a.getString(R.styleable.LLoginHistoryCard_trip) ?: trip
            seeDetails = a.getString(R.styleable.LLoginHistoryCard_seeDetails) ?: seeDetails
            priceDes = a.getString(R.styleable.LLoginHistoryCard_tripPriceDes) ?: priceDes
            setTextColor = a.getInt(R.styleable.LLoginHistoryCard_colorText, 0)
            alignmentCenter = a.getBoolean(R.styleable.LLoginHistoryCard_alignmentCenter, true)


            a.recycle()
        }
    }

    fun setPriceValue(earnings: Double) {
        vbd.tvTotPrice.setPriceValue(earnings)
    }

    fun setLoginHrMin(hour: Int, minutes: Int) {
        vbd.tvWorkingHr.setLoginHrMin(hour, minutes)

    }
}