package com.tamanna.basearchitecture.ui.screen.signup.data

import com.tamanna.basearchitecture.api.BaseDataSource
import com.tamanna.basearchitecture.api.SignUpServiceAPI
import com.tamanna.basearchitecture.data.models.SendOtpDTO

class SignUpRemoteDataSource constructor(
    private val serviceAPI: SignUpServiceAPI
) :
    BaseDataSource() {
    suspend fun signUpSendOtp(sendOtpDTO: SendOtpDTO) = getResult {
        serviceAPI.signUpSendOtp(sendOtpDTO)
    }


}
