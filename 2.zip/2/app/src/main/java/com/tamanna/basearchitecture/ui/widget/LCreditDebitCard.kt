package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.LinearLayout
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.databinding.ViewCreditDebitCardBinding
import com.tamanna.basearchitecture.ui.helper.bindIsGone
import com.tamanna.basearchitecture.ui.helper.hideEmptyTextView

/**
 * Created by Bhupendra Kumar Sahu on 20-Aug-20.
 */
class LCreditDebitCard : LinearLayout {

    val vbd by lazy {
        val layoutInflater = LayoutInflater.from(context)
        ViewCreditDebitCardBinding.inflate(
            layoutInflater,
            this,
            true
        )
    }
    var date: CharSequence? = null
        set(value) {
            field = value
            vbd.tvDate.tv_description.hideEmptyTextView(field)

        }

    var cerDebStatus: CharSequence? = null
        set(value) {
            field = value
            vbd.tvCreDebStatus.tv_header.hideEmptyTextView(field)

        }

    //    var totAmount: CharSequence? = null
//        set(value) {
//            field = value
//            vbd.tvTotalAmount.tv_header.hideEmptyTextView(field)
//
//        }
    var textColor: Int = 0
        set(value) {
            field = value
            vbd.tvTotalAmount.tv_header.setTextColor(field)

        }
    var showLeftIcon: Boolean = false
        set(value) {
            field = value
            vbd.llLeft.bindIsGone(!field)
        }

    var icon: String? = null
        set(value) {
            field = value
            vbd.iconCreDeb.hideEmptyTextView(field)
        }

    var iconColor: Int = 0
        set(value) {
            field = value
            vbd.iconCreDeb.setTextColor(field)
        }

    var iconBackColor: Int = 0
        set(value) {
            field = value
            vbd.iconBackColor.setTextColor(field)

        }

    constructor(context: Context) : this(context, null, 0)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {

        if (attrs != null) {
            val a =
                context.obtainStyledAttributes(
                    attrs,
                    R.styleable.LCreditDebitCard,
                    defStyleAttr,
                    0
                )
            date = a.getString(R.styleable.LCreditDebitCard_cardDescription) ?: date
            cerDebStatus = a.getString(R.styleable.LCreditDebitCard_cardHeader) ?: cerDebStatus
            //  totAmount = a.getString(R.styleable.LCreditDebitCard_totalAmount) ?: totAmount
            icon = a.getString(R.styleable.LCreditDebitCard_fontIcon) ?: icon
            textColor = a.getInt(R.styleable.LCreditDebitCard_colorText, 0)
            iconColor = a.getInt(R.styleable.LCreditDebitCard_fontIconColor, 0)
            iconBackColor = a.getInt(R.styleable.LCreditDebitCard_backColor, 0)
            showLeftIcon = a.getBoolean(R.styleable.LCreditDebitCard_showIcon, false)
            a.recycle()
        }
    }

    fun setDebitPrice(price: Double) {
        vbd.tvTotalAmount.setDebitPrice(price)

    }

    fun setCreditPrice(price: Double) {
        vbd.tvTotalAmount.setCreditPrice(price)

    }

    fun setPrice(price: Double) {
        vbd.tvTotalAmount.setPriceValue(price)

    }
//    fun setTrip(trip: Long) {
//        vbd.lableHeader.setTrip(trip)
//
//    }
//    fun setLoginHrMin(hour: Int, minutes: Int) {
//        vbd.lableHeader.setLoginHrMin(hour, minutes)
//
//    }
}
