package com.tamanna.basearchitecture.ui.screen.started

import com.tamanna.basearchitecture.ui.base.BaseViewModel


class StartedViewModel : BaseViewModel<IStarted>()

