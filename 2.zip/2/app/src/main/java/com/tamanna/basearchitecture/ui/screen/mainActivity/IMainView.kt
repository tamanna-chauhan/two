package com.tamanna.basearchitecture.ui.screen.mainActivity

import android.widget.CompoundButton
import com.tamanna.basearchitecture.ui.base.IModuleHandler
import com.tamanna.basearchitecture.ui.base.IView

interface IMainView : IView, CompoundButton.OnCheckedChangeListener,IModuleHandler
