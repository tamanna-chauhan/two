package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.LinearLayout
import com.tamanna.basearchitecture.R

import com.tamanna.basearchitecture.util.viewutils.fontutils.FontIconView

/**
 * Created by Bhupendra Kumar Sahu on 19-Aug-20.
 */
class LDropPointCardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : LinearLayout(context, attrs, defStyleAttr, defStyleRes) {
    val tv_drop_point: ComponentTitleTextView
    val tv_customer_name: ComponentHeaderTextView
    val tv_right_icon_name: ComponentColorTextView
    val tv_icon_msg: ComponentColorTextView
    val tv_order_no: ComponentDescriptionTextView
    val tv_cus_description: ComponentDescriptionTextView
    val loc_drop_point: FontIconView
    val icon_back_right: FontIconView
    val icon_back_msg: FontIconView
    val icon_right: FontIconView
    val icon_mag: FontIconView


    var dropIcon: String? = null
        set(value) {
            if (value == null) {
                // arrowIcon.visibility = View.GONE
            } else {

                loc_drop_point.text = value
                loc_drop_point.visibility = View.VISIBLE
            }
            field = value
        }

    var rightIcon: String? = null
        set(value) {
            if (value == null) {
                // arrowIcon.visibility = View.GONE
            } else {

                icon_right .text = value
                icon_right.visibility = View.VISIBLE
            }
            field = value
        }

    var msgIcon: String? = null
        set(value) {
            if (value == null) {
                // arrowIcon.visibility = View.GONE
            } else {

                icon_mag .text = value
                icon_mag.visibility = View.VISIBLE
            }
            field = value
        }

//    var showIcon: Boolean = false
//        set(value) {
//            if (value) {
//                loc_drop_point.visibility = View.VISIBLE
//            } else {
//                loc_drop_point.visibility = View.GONE
//            }
//            field = value
//        }

    private var dropIconColor: Int = 0
        set(value) {

            loc_drop_point.setTextColor(value)
            field = value
        }
    private var rightIconBackground: Int = 0
        set(value) {

            icon_back_right.setTextColor(value)
            field = value
        }

    private var msgIconBackground: Int = 0
        set(value) {

            icon_back_msg.setTextColor(value)
            field = value
        }
    private var rightIconColor: Int = 0
        set(value) {

            icon_right.setTextColor(value)
            tv_right_icon_name.setTextColor = value
            field = value
        }
    private var msgtIconColor: Int = 0
        set(value) {

            icon_mag.setTextColor(value)
            tv_icon_msg.setTextColor = value
            field = value
        }


//    var ivSize: Int = 0
//        set(value) {
//            if (value == null) {
//                // arrowIcon.visibility = View.GONE
//            } else {
//                val iconParam =
//                    LinearLayout.LayoutParams(VUtil.dpToPx(ivSize), VUtil.dpToPx(ivSize))
//                arrowIcon.layoutParams = iconParam
//            }
//            field = value
//        }


    var colorText: CharSequence = ""
        set(value) {
            tv_right_icon_name.tv_colored.text = value
            field = value
        }

    var msgColorText: CharSequence = ""
        set(value) {
            tv_icon_msg.tv_colored.text = value
            field = value
        }


    var orderNo: CharSequence = ""
        set(value) {
            tv_order_no.description = value
            field = value
        }
    var title: CharSequence = ""
        set(value) {
            tv_drop_point.title = value
            field = value
        }
  var cusName: CharSequence = ""
        set(value) {
            tv_customer_name.header = value
            field = value
        }
 var cusDes: CharSequence = ""
        set(value) {
            tv_cus_description.description = value
            field = value
        }


    init {
        clipToPadding = false
        val view = View.inflate(context, R.layout.view_drop_points, this)
        tv_drop_point = view.findViewById(R.id.tv_drop_point)
        tv_order_no = view.findViewById(R.id.tv_order_no)
        tv_right_icon_name = view.findViewById(R.id.tv_right_icon_name)
        tv_icon_msg = view.findViewById(R.id.tv_icon_msg)
        loc_drop_point = view.findViewById(R.id.loc_drop_point)
        icon_right = view.findViewById(R.id.icon_right)
        icon_mag = view.findViewById(R.id.icon_mag)
        icon_back_right = view.findViewById(R.id.icon_back_right)
        icon_back_msg = view.findViewById(R.id.icon_back_msg)
        tv_customer_name = view.findViewById(R.id.tv_customer_name)
        tv_cus_description = view.findViewById(R.id.tv_cus_description)
        val a = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.LDropPointCardView,
            defStyleAttr,
            defStyleRes
        )
        dropIcon = a.getString(R.styleable.LDropPointCardView_fontIcon) ?: dropIcon
        dropIconColor = a.getInt(R.styleable.LDropPointCardView_fontIconColor, 0)

        rightIcon = a.getString(R.styleable.LDropPointCardView_rightFontIcon) ?: rightIcon
        msgIcon = a.getString(R.styleable.LDropPointCardView_msgFontIcon) ?: msgIcon
        rightIconColor = a.getInt(R.styleable.LDropPointCardView_rightFontIconColor, 0)
        msgtIconColor = a.getInt(R.styleable.LDropPointCardView_msgtIconColor, 0)

        rightIconBackground = a.getInt(R.styleable.LDropPointCardView_rightFontIconBackColor, 0)
        msgIconBackground = a.getInt(R.styleable.LDropPointCardView_msgIconBackColor, 0)

        colorText = a.getString(R.styleable.LDropPointCardView_setText) ?: colorText
        msgColorText = a.getString(R.styleable.LDropPointCardView_msgColorText) ?: msgColorText
        title = a.getString(R.styleable.LDropPointCardView_cardTitle) ?: title
        cusName = a.getString(R.styleable.LDropPointCardView_cardHeader) ?: cusName
        cusDes = a.getString(R.styleable.LDropPointCardView_cardDescription) ?: cusDes
        orderNo = a.getString(R.styleable.LDropPointCardView_cardOrderNo) ?: orderNo
        a.recycle()
    }
}