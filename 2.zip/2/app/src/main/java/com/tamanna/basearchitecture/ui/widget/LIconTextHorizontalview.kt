package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.LinearLayout
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.databinding.ViewFonticonTextviewBinding
import com.tamanna.basearchitecture.ui.helper.hideEmptyTextView

/**
 * Created by Bhupendra Kumar Sahu on 20-Aug-20.
 */
class LIconTextHorizontalview : LinearLayout {
    var icon: String? = null
        set(value) {
            field = value
            vbd.icon.hideEmptyTextView(field.toString())
        }
    var layoutBackColor: Int = 0
        set(value) {
            field = value
            vbd.mCard.setCardBackgroundColor(field)
        }

    var iconTextColor: Int = 0
        set(value) {
            field = value
            vbd.icon.setTextColor(value)
            vbd.tvSubeader.tv_description.setTextColor(value)
        }

    var description: CharSequence? = ""
        set(value) {
            field = value
            vbd.tvSubeader.tv_description.hideEmptyTextView(field.toString())
        }
    private val vbd by lazy {
        val layoutInflater = LayoutInflater.from(context)
        ViewFonticonTextviewBinding.inflate(
            layoutInflater,
            this,
            true
        )
    }

    constructor(context: Context) : this(context, null, 0)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {

        if (attrs != null) {
            val a = context.theme.obtainStyledAttributes(
                attrs,
                R.styleable.LIconTextHorizontalview,
                defStyleAttr,
                0
            )
            icon = a.getString(R.styleable.LIconTextHorizontalview_fontIcon) ?: icon
            description =
                a.getString(R.styleable.LIconTextHorizontalview_cardDescription) ?: description
            layoutBackColor = a.getInt(R.styleable.LIconTextHorizontalview_backColor, 0)
            iconTextColor = a.getInt(R.styleable.LIconTextHorizontalview_fontIconColor, 0)
            a.recycle()
        }
    }
}