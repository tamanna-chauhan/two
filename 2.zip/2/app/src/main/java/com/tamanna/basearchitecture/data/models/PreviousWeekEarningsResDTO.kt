package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName

/**
 * Created by Bhupendra Kumar Sahu on 10-Feb-21.
 */
data class PreviousWeekEarningsResDTO(
    @field:SerializedName("previousWeeks") val previousWeeks: List<previousWeeksListDTO>

)

data class previousWeeksListDTO(
    @field:SerializedName("earnings") val earnings: Double,
    @field:SerializedName("week") val week: Int,
    @field:SerializedName("endDate") val endDate: String,
    @field:SerializedName("startDate") val startDate: String,
    @field:SerializedName("dailyDuties") val dailyDuties: List<DailyDutyDTO>

)

data class DailyDutyDTO(
    @field:SerializedName("earnings") val earnings: Double,
    @field:SerializedName("trips") val trips: Long,
    @field:SerializedName("weekDayLabel") val weekDayLabel: String

)