package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import com.tamanna.basearchitecture.R


/**
 * Created by Bhupendra Kumar Sahu on 19-Aug-20.
 */
class LButtonToggleGroupComponent @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : LinearLayout(context, attrs, defStyleAttr, defStyleRes) {
    private val action_btn1: Button
    private val action_btn2: Button



    private var actionBtn1: CharSequence = ""
        set(value) {
            action_btn1.text = value
            action_btn1.isAllCaps=false
            field = value
        }
    private var actionBtn2: CharSequence = ""
        set(value) {

            action_btn2.text = value
            action_btn1.isAllCaps=false

            field = value
        }


    init {
        clipToPadding = false
        orientation = LinearLayout.HORIZONTAL


        val view = View.inflate(context, R.layout.component_button_toggle_group, this)
        action_btn1 = view.findViewById(R.id.action_btn1)
        action_btn2 = view.findViewById(R.id.action_btn2)

        val a = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.LButtonToggleGroupComponent,
            defStyleAttr,
            defStyleRes
        )
        actionBtn1 = a.getString(R.styleable.LButtonToggleGroupComponent_buttonText) ?: actionBtn1
        actionBtn2 = a.getString(R.styleable.LButtonToggleGroupComponent_buttonText1) ?: actionBtn2
        a.recycle()
    }
}