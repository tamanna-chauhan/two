/*
 *   Created by Sourav Kumar Pandit  22 - 4 - 2020
 */

package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName


data class NotificationResDTO(
    @field:SerializedName("notifications") val notification: List<NotificationListDTO>
)

data class NotificationListDTO(

    @field:SerializedName("seen") val seen: Boolean,
    @field:SerializedName("_id") val _id: String,
    @field:SerializedName("notificationId") val notificationId: String,
    @field:SerializedName("tamannaId") val tamannaId: String,
    @field:SerializedName("title") val title: String,
    @field:SerializedName("description") val description: String,
    @field:SerializedName("createdAt") val createdAt: String

)


