package com.tamanna.basearchitecture.ui.worker

import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.content.Intent
import android.os.*
import android.util.Log
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.here.oksse.OkSse
import com.here.oksse.ServerSentEvent
import com.tamanna.basearchitecture.BuildConfig
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.data.models.TaskInfoDTO
import com.tamanna.basearchitecture.data.models.base.APIConstant
import com.tamanna.basearchitecture.pref.RiderInfo
import com.tamanna.basearchitecture.ui.screen.mainActivity.MainActivity
import com.tamanna.basearchitecture.util.IConstants
import com.tamanna.basearchitecture.util.viewutils.YumUtil
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import org.koin.core.KoinComponent
import org.koin.core.inject

@SuppressLint("LogNotTimber")
class SseService : LifecycleService(), ServerSentEvent.Listener, KoinComponent {

    private var serviceLooper: Looper? = null
    private var serviceHandler: ServiceHandler? = null
    private lateinit var request: Request
    private var okSse: OkSse? = null
    private var sse: ServerSentEvent? = null
/*
    private val repository: DestinationDropRepository by inject()*/

    // Handler that receives messages from the thread
    private inner class ServiceHandler(looper: Looper) : Handler(looper) {

        override fun handleMessage(msg: Message) {
            val url =
                "${IConstants.BASE_URL}${APIConstant.URL.SSE_ENDPOINT}?tamannaId=${RiderInfo.tamannaId}"
            request = Request.Builder().url(url).build()
            okSse = OkSse()
            sse = okSse?.newServerSentEvent(request, this@SseService)

            /*// Normally we would do some work here, like download a file.
            // For our sample, we just sleep for 5 seconds.
            try {
                Thread.sleep(5000)
            } catch (e: InterruptedException) {
                // Restore interrupt status.
                Thread.currentThread().interrupt()
            }

            // Stop the service using the startId, so that we don't stop
            // the service in the middle of handling another job
            stopSelf(msg.arg1)*/
        }
    }

    override fun onCreate() {
        super.onCreate()
        // Start up the thread running the service.  Note that we create a
        // separate thread because the service normally runs in the process's
        // main thread, which we don't want to block.  We also make it
        // background priority so CPU-intensive work will not disrupt our UI.
        HandlerThread("ServiceStartArguments", Process.THREAD_PRIORITY_BACKGROUND).apply {
            start()

            // Get the HandlerThread's Looper and use it for our Handler
            serviceLooper = looper
            serviceHandler = ServiceHandler(looper)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (BuildConfig.DEBUG) {
            Toast.makeText(this, "service starting", Toast.LENGTH_SHORT).show()
        }
        // For each start request, send a message to start a job and deliver the
        // start ID so we know which request we're stopping when we finish the job
        serviceHandler?.obtainMessage()?.also { msg ->
            msg.arg1 = startId
            serviceHandler?.sendMessage(msg)
        }

        startForeground(
            NOTIFY_ID, buildForegroundNotification(
                description = R.string.service_sse_connecting
            )
        )
        // If we get killed, after returning from here, restart
        return START_STICKY
    }

    override fun onBind(intent: Intent): IBinder? {
        super.onBind(intent)
        // We don't provide binding, so return null
        return null
    }

    override fun onDestroy() {
        super.onDestroy()
        sse?.close()
        if (BuildConfig.DEBUG) {
            Toast.makeText(this, "service done", Toast.LENGTH_SHORT).show()
        }
    }

    private fun buildForegroundNotification(
        title: Int = R.string.service_sse_title,
        description: Int
    ): Notification {
        val b: NotificationCompat.Builder = NotificationCompat.Builder(this, CHANNEL_ID)
        b.setOngoing(true)
            .setContentTitle(applicationContext.resources.getString(title))
            .setSmallIcon(R.drawable.ic_app_notification)
            .setColor(ContextCompat.getColor(applicationContext, R.color.colorAppIcon))
                .setGroup(GROUP)
            .setContentText(applicationContext.resources.getString(description)).priority =
            NotificationCompat.PRIORITY_DEFAULT
        return b.build()
    }

    private fun buildFullScreenNotification(
        title: Int = R.string.service_sse_title,
        description: Int = R.string.service_sse_new_order,
        data: TaskInfoDTO
    ): Notification {
        val fullScreenIntent = Intent(this, MainActivity::class.java)
        fullScreenIntent.putExtra("data", data)
        val fullScreenPendingIntent = PendingIntent.getActivity(
            this, 0,
            fullScreenIntent, PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notificationBuilder =
            NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_app_notification)
                .setColor(ContextCompat.getColor(applicationContext, R.color.colorAppIcon))
                .setContentTitle(applicationContext.resources.getString(title))
                .setContentText(applicationContext.resources.getString(description))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_PROMO)

                // Use a full-screen intent only for the highest-priority alerts where you
                // have an associated activity that you would like to launch after the user
                // interacts with the notification. Also, if your app targets Android 10
                // or higher, you need to request the USE_FULL_SCREEN_INTENT permission in
                // order for the platform to invoke this notification.
                .setFullScreenIntent(fullScreenPendingIntent, true)

        return notificationBuilder.build()
    }

    private fun createTask(taskId: String, timeOut: Double) {
        YumUtil.executeWithDelay(0){} /*{
            repository.getTaskInfo(taskId).observe(this, {
                if (it.type == APIConstant.Status.SUCCESS && it.data != null) {
                    Intent().also { intent ->
                        intent.action = SseBroadCast.ACTION_NEW_TASK
                        intent.putExtra("data", it.data)
                        intent.putExtra("timeout", timeOut)
                        sendBroadcast(intent)
                    }
                }
            })
        }*/
    }

    private fun cancelTask(taskId: String) {
        YumUtil.executeWithDelay(0) {
            Intent().also { intent ->
                intent.action = SseBroadCast.ACTION_CANCEL_TASK
                intent.putExtra("data", taskId)
                LocalBroadcastManager.getInstance(applicationContext).sendBroadcast(intent)
            }

        }
    }


    private fun cancelOrder(taskId: String) {
        YumUtil.executeWithDelay(0) {
            Intent().also { intent ->
                intent.action = SseBroadCast.ACTION_ORDER_TASK
                intent.putExtra("data", taskId)
                LocalBroadcastManager.getInstance(applicationContext).sendBroadcast(intent)
            }

        }
    }


    override fun onOpen(sse: ServerSentEvent?, response: Response?) {
        Log.d("sse", "sse open")
        with(NotificationManagerCompat.from(this)) {
            notify(
                NOTIFY_ID,
                buildForegroundNotification(description = R.string.service_sse_connected)
            )
        }
    }

    override fun onMessage(sse: ServerSentEvent?, id: String?, event: String?, message: String?) {
        event?.let {
            when (it) {
                "create" -> {
                    val json = JSONObject(message ?: "")
                    if (json.has("taskId")) {
                        val taskId = json.getString("taskId")
                        createTask(taskId, if(json.has("timeout")) json.getDouble("timeout") else 10000.0)
                    }
                }
                "cancel" -> {
                    val json = JSONObject(message ?: "")
                    if (json.has("taskId")) {
                        val taskId = json.getString("taskId")
                        cancelTask(taskId)
                    }
                }
                "orderCancel" -> {
                    val json = JSONObject(message ?: "")
                    if (json.has("taskId")) {
                        val taskId = json.getString("taskId")
                        cancelOrder(taskId)
                    }
                }
            }
        }

        //NOTE : Below is for testing purpose
        //getTaskInformation("499570e0-5bb9-11eb-907f-5db67606b887")
        Log.d("sse", "sse  event->${event}  message->${message}")
    }


    override fun onComment(sse: ServerSentEvent?, comment: String?) {
        Log.d("sse", "service comment ${comment}")
    }

    override fun onRetryTime(sse: ServerSentEvent?, milliseconds: Long): Boolean {
        Log.d("sse", "sse retry")
        return true
    }

    override fun onRetryError(
        sse: ServerSentEvent?,
        throwable: Throwable?,
        response: Response?
    ): Boolean {
        Log.d("sse", "sse retry error ${throwable?.message}")
        return true
    }

    override fun onClosed(sse: ServerSentEvent?) {
        Log.d("sse", "sse close")

    }

    override fun onPreRetry(sse: ServerSentEvent?, originalRequest: Request?): Request {
        Log.d("sse", "sse pre retry")
        with(NotificationManagerCompat.from(this)) {
            notify(
                NOTIFY_ID,
                buildForegroundNotification(description = R.string.service_sse_connecting)
            )
        }
        return originalRequest ?: request
    }


    companion object {
        val NOTIFY_ID = 1
        val FULL_SCREEN_NOTIFY_ID = 1338
        val CHANNEL_ID = "tamannaSSEServiceChannel"
        val GROUP = "_notifications"
    }


}