package com.tamanna.basearchitecture

import android.content.Context
import androidx.multidex.MultiDex
import androidx.multidex.MultiDexApplication
import com.tamanna.basearchitecture.di.appModule
import org.koin.android.ext.koin.androidContext
import org.koin.android.ext.koin.androidLogger
import org.koin.core.context.startKoin


class BaseApplication : MultiDexApplication() {

    private fun configureDi() = startKoin {

        // use AndroidLogger as Koin Logger - default Level.INFO
        if (BuildConfig.DEBUG) androidLogger()

        androidContext(this@BaseApplication)
        /*// load properties from assets/koin.properties file
        androidFileProperties()*/

        modules(appModule())
    }

    override fun onCreate() {
        super.onCreate()
    }

    override fun attachBaseContext(base: Context?) {
        super.attachBaseContext(base)
        MultiDex.install(this)
    }

}