package com.tamanna.basearchitecture.ui.core

//
//class CommonActivityTitleView @JvmOverloads constructor(private val mBaseActivity: AppCompatActivity, private val rootView: ConstraintLayout, var mTitle: CharSequence, var mIsSupportScroll: Boolean = true) {
//    //    var baseTitleRootLayout: CoordinatorLayout? = null
////    var baseTitleToolbar: Toolbar? = null
////    var baseTitleContentView: FrameLayout? = null
//    var mViewStub: ViewStub? = null
////    var rootView: ConstraintLayout? = null
//
//    constructor(activity: AppCompatActivity, rootView: ConstraintLayout, @StringRes resId: Int) : this(activity, rootView, activity.getString(resId), true)
//    constructor(activity: AppCompatActivity, rootView: ConstraintLayout, @StringRes resId: Int, isSupportScroll: Boolean) : this(activity, rootView, activity.getString(resId), isSupportScroll)
//
//    private val binding by lazy {
//        CoreActivityTitleBinding.inflate(mBaseActivity.layoutInflater, rootView, true)
//    }
//
//    init {
//
//
//    }
//
//    fun setIsSupportScroll(isSupportScroll: Boolean) {
//        mIsSupportScroll = isSupportScroll
//    }
//
////    fun bindLayout(): Int {
////        return R.layout.core_activity_title
////    }
//
//    fun contentView(): View {
//        //            baseTitleRootLayout = mBaseActivity.findViewById(R.id.baseTitleRootLayout)
////            baseTitleToolbar = mBaseActivity.findViewById(R.id.baseTitleToolbar)
////        mViewStub = if (mIsSupportScroll) {
////            binding.baseTitleStubScroll.viewStub
////        } else {
////            binding.baseTitleStubNoScroll.viewStub
////        }
////        mViewStub?.visibility = View.VISIBLE
////            baseTitleContentView = binding.baseTitleStubNoScroll.findViewById(R.id.commonTitleContentView)
////            setTitleBar()
//
//        binding.root
//        if (mIsSupportScroll) {
////             mViewStub = binding.baseTitleStubScroll.viewStub
//            mViewStub = mBaseActivity.findViewById(R.id.baseTitleStubScroll);
//        } else {
////            mViewStub = binding.baseTitleStubNoScroll.viewStub
//            mViewStub = mBaseActivity.findViewById(R.id.baseTitleStubNoScroll)
//        }
//        mViewStub?.visibility = View.VISIBLE;
//        setTitleBar()
//        BarUtils.setStatusBarColor(mBaseActivity, ColorUtils.getColor(R.color.colorPrimary))
//        BarUtils.addMarginTopEqualStatusBarHeight(binding.baseTitleRootLayout)
//        return rootView
//    }
//
//    private fun setTitleBar() {
//        mBaseActivity.setSupportActionBar(binding.baseTitleToolbar)
//        val titleBar = mBaseActivity.supportActionBar
//        if (titleBar != null) {
//            titleBar.setDisplayHomeAsUpEnabled(true)
//            titleBar.title = mTitle
//        }
//    }
//
//    fun onOptionsItemSelected(item: MenuItem): Boolean {
//        if (item.itemId == android.R.id.home) {
//            mBaseActivity.finish()
//            return true
//        }
//        return mBaseActivity.onOptionsItemSelected(item)
//    }
//}