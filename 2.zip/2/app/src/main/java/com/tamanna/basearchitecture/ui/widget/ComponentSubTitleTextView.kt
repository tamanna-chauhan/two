package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.tamanna.basearchitecture.R


/**
 * Created by Bhupendra Kumar Sahu on 19-Aug-20.
 */
class ComponentSubTitleTextView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : LinearLayout(context, attrs, defStyleAttr, defStyleRes)
{
     val tv_sub_title: TextView

     var subTitle: CharSequence = ""
        set(value) {
            tv_sub_title.text = value
            field = value
        }
    var alignmentCenter: Boolean = false
        set(value) {
            if (value) {
                tv_sub_title.textAlignment= View.TEXT_ALIGNMENT_CENTER
            } else {
                tv_sub_title.textAlignment= View.TEXT_ALIGNMENT_TEXT_START
            }
            field = value
        }
    init {
        clipToPadding = false
        val view = View.inflate(context, R.layout.type_attribute_sub_title_text, this)
        tv_sub_title = view.findViewById(R.id.tv_sub_title)

        val a = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.ComponentSubTitleTextView,
            defStyleAttr,
            defStyleRes
        )
        subTitle = a.getString(R.styleable.ComponentSubTitleTextView_cardSubTitle) ?: subTitle
        alignmentCenter = a.getBoolean(R.styleable.ComponentSubTitleTextView_alignmentCenter, false)
        a.recycle()
    }}