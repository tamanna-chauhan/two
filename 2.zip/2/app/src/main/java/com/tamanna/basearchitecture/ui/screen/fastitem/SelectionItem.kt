package com.tamanna.basearchitecture.ui.screen.fastitem

import android.view.LayoutInflater
import android.view.ViewGroup
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.data.models.local.KeyValueSSI
import com.tamanna.basearchitecture.databinding.LayoutSelectionBinding
import com.mikepenz.fastadapter.binding.ModelAbstractBindingItem

class SelectionItem(keyValue: KeyValueSSI) :
    ModelAbstractBindingItem<KeyValueSSI, LayoutSelectionBinding>(keyValue) {


    override val type: Int
        get() = R.id.selection_item_id


    override fun bindView(binding: LayoutSelectionBinding, payloads: List<Any>) {
        super.bindView(binding, payloads)
        attachToWindow(binding)


    }

    override fun unbindView(binding: LayoutSelectionBinding) {
//        binding.imageUrl = null

        binding.title = null
        binding.subtitle = null
        binding.cuisines = null
        binding.offer = null
//        binding.rating = null
        binding.duration = null
    }

    override fun createBinding(
        inflater: LayoutInflater,
        parent: ViewGroup?
    ): LayoutSelectionBinding {
        return LayoutSelectionBinding.inflate(inflater, parent, false)
    }
}