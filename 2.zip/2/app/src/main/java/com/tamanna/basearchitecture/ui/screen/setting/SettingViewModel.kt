package com.tamanna.basearchitecture.ui.screen.setting

import com.tamanna.basearchitecture.ui.base.BaseViewModel

class SettingViewModel : BaseViewModel<ISettingView>()