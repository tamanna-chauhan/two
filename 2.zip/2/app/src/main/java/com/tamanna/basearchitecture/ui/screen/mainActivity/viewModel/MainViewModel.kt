package com.tamanna.basearchitecture.ui.screen.mainActivity.viewModel

import com.tamanna.basearchitecture.ui.base.BaseViewModel
import com.tamanna.basearchitecture.ui.screen.mainActivity.IMainView
import com.tamanna.basearchitecture.ui.screen.mainActivity.data.MainRepository

class MainViewModel constructor(private val repository: MainRepository) :
    BaseViewModel<IMainView>() {
/*

    fun logout(tamannaId: String) =
        repository.logout(tamannaId)

*/

}