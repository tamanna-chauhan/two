package com.tamanna.basearchitecture.ui.screen.otp

import com.tamanna.basearchitecture.ui.base.IView

interface IOtp : IView
