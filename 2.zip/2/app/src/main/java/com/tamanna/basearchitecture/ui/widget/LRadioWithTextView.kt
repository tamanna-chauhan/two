package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.LinearLayout
import com.tamanna.basearchitecture.R


/**
 * Created by Bhupendra Kumar Sahu on 21-Aug-20.
 */
class LRadioWithTextView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : LinearLayout(context, attrs, defStyleAttr, defStyleRes) {
    val header: ComponentHeaderTextView
    val description: ComponentDescriptionTextView


    private var name: String? = null
        set(value) {
            if (value == null) {
                // fontIcon.visibility = View.GONE
            } else {

                header.header = value
                header.visibility = View.VISIBLE
            }
            field = value
        }
    private var acNo: String? = null
        set(value) {
            if (value == null) {
                // fontIcon.visibility = View.GONE
            } else {

                description.description = value
                description.visibility = View.VISIBLE
            }
            field = value
        }

    init {
        clipToPadding = false
        val view = View.inflate(context, R.layout.view_radio_with_text, this)
        description = view.findViewById(R.id.rb_tv_des)
        header = view.findViewById(R.id.rb_tv_header)

        val a = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.LRadioWithTextView,
            defStyleAttr,
            defStyleRes
        )
        name = a.getString(R.styleable.LRadioWithTextView_cardHeader) ?: name
        acNo = a.getString(R.styleable.LRadioWithTextView_cardDescription) ?: acNo


        a.recycle()
    }
}