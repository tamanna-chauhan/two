package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.Button
import android.widget.LinearLayout

import com.tamanna.basearchitecture.R

/**
 * Created by Bhupendra Kumar Sahu on 19-Aug-20.
 */
class ComponentButton @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : LinearLayout(context, attrs, defStyleAttr, defStyleRes)
{
     val actionButton: Button

     var actionDone: CharSequence = ""
        set(value) {
            actionButton.text = value
            field = value
        }
    init {
        clipToPadding = false
        val view = View.inflate(context, R.layout.component_button, this)
        actionButton = view.findViewById(R.id.btn_action)

        val a = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.ComponentButton,
            defStyleAttr,
            defStyleRes
        )
        actionDone = a.getString(R.styleable.ComponentButton_buttonText) ?: actionDone
        a.recycle()
    }}