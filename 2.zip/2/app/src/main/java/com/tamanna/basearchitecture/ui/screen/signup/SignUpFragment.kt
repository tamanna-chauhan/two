package com.tamanna.basearchitecture.ui.screen.signup

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import androidx.navigation.fragment.findNavController
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.data.models.base.APIConstant
import com.tamanna.basearchitecture.data.models.base.RHandler
import com.tamanna.basearchitecture.databinding.FragmentSignupBinding
import com.tamanna.basearchitecture.ui.base.BaseFragment
import com.tamanna.basearchitecture.util.IConstants
import com.tamanna.basearchitecture.util.viewutils.YumUtil
import com.tamanna.basearchitecture.util.viewutils.YumUtil.showSoftKeyboard
import org.koin.androidx.viewmodel.ext.android.viewModel


class SignUpFragment : BaseFragment<FragmentSignupBinding, SignUpViewModel>(), ISignUp {
    override fun getLayoutId() = R.layout.fragment_signup

    private val navController by lazy {
        findNavController()
    }
    override val fvm: SignUpViewModel by viewModel()

    override fun onFragmentReady(view: View) {
        bd.signupModel = fvm
        applyDebounceClickListener(bd.btnSignup)
        bd.fullNameInput.showSoftKeyboard()

        bd.mobileInput.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(cs: CharSequence, arg1: Int, arg2: Int, arg3: Int) {
                bd.editMobileOutline.error = null
                bd.editFullNameOutline.error = null

            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int, arg3: Int) {
            }

            override fun afterTextChanged(arg0: Editable) {
            }
        })
        bd.fullNameInput.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(cs: CharSequence, arg1: Int, arg2: Int, arg3: Int) {
                bd.editMobileOutline.error = null
                bd.editFullNameOutline.error = null
            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int, arg3: Int) {
            }

            override fun afterTextChanged(arg0: Editable) {
            }
        })

    }

    override fun navToOtp() {

        fvm.signUpSendOtp(bd.mobileInput.text.toString()).observe(this, { result ->
            RHandler<Any>(
                this,
                result
            ) {
            }

        })
    }

    override fun onResponse(code: Int?, response: Any?, title: String?, message: String) {
        when (code) {
            APIConstant.Code.USER_EXIST -> {
                showAlerter(title ?: "", message)
                val args = Bundle()
                args.putString(IConstants.FragmentArgs.MOBILE, bd.mobileInput.text.toString())
                navController.navigate(R.id.action_fragment_signup_to_fragment_login, args)
            }
            APIConstant.Code.OTP_SENT_SUCCESS -> {
                val args = Bundle()
                args.putString(IConstants.FragmentArgs.MOBILE, bd.mobileInput.text.toString())
                args.putString(IConstants.FragmentArgs.NAME, bd.fullNameInput.text.toString())
                args.putString(IConstants.FragmentArgs.FLAG, IConstants.FragmentArgs.SIGNUP)
                navController.navigate(R.id.action_fragment_signup_to_fragment_otp_verify, args)

            }


            else -> super.onResponse(code, response, title ?: "", message)

        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val no = arguments?.getString(IConstants.FragmentArgs.MOBILE)
        if (no != null) {
            bd.mobileInput.setText(no.toString())
        }
    }

    override fun showCodeError(code: Int?, title: String?, message: String) {
        showAlerter(title ?: "", message)
        super.showCodeError(code, title, message)
    }

    override fun onDebounceClick(view: View) {
        when (view) {
            bd.btnSignup -> {
                if (bd.fullNameInput.text.toString().isNotEmpty()) {
                    if (YumUtil.isValidNameIgnoreSpace(bd.fullNameInput.text.toString())) {
                        if (bd.mobileInput.text.toString().isNotEmpty()) {
                            if (YumUtil.isValidMobile(bd.mobileInput.text.toString())) {
                                bd.editFullNameOutline.error = null
                                bd.editMobileOutline.error = null
                                navToOtp()
                            } else {
                                bd.editFullNameOutline.error = null
                                bd.mobileInput.requestFocus()
                                bd.editMobileOutline.error =
                                    getString(R.string.incorrect_mobile_number)
                            }
                        } else {
                            bd.editFullNameOutline.error = null
                            bd.mobileInput.requestFocus()
                            bd.editMobileOutline.error = getString(R.string.enter_mobile_number)

                        }
                    } else {
                        bd.editMobileOutline.error = null
                        bd.fullNameInput.requestFocus()
                        bd.editFullNameOutline.error = getString(R.string.enter_valid_name)
                    }
                } else {
                    bd.editMobileOutline.error = null
                    bd.fullNameInput.requestFocus()
                    bd.editFullNameOutline.error = getString(R.string.enter_your_full_name)
                }


            }
        }
        super.onDebounceClick(view)
    }
}