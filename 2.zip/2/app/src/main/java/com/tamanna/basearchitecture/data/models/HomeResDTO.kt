package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName

/**
 * Created by Bhupendra Kumar Sahu on 10-Feb-21.
 */
data class HomeResDTO(
    @field:SerializedName("thisWeekEarnings") val thisWeekEarnings: Double,
    @field:SerializedName("lastWeekEarnings") val lastWeekEarnings: Double,
    @field:SerializedName("todaysEarnings") val todaysEarnings: Double,
    @field:SerializedName("operationalStatus") val operationalStatus: Boolean,
    @field:SerializedName("hasNotifications") val hasNotifications: Boolean,
    @field:SerializedName("tasks") val tasks: List<Task>
)

//data class OngoingTaskDTO(
//    @field:SerializedName("_id") val _id: String,
//    @field:SerializedName("taskLeg") val taskLeg: String,
//    @field:SerializedName("status") val status: String,
//    @field:SerializedName("creationTime") val creationTime: String,
//    @field:SerializedName("taskId") val taskId: String,
//    @field:SerializedName("taskLocation") val taskLocation: TaskLocationDTO,
//    @field:SerializedName("packetInfo") val packetInfo: PacketInfoDTO,
//    @field:SerializedName("estDistance") val estDistance: Double,
//    @field:SerializedName("estDuration") val estDuration: Long,
//
//    )
//
//data class PacketInfoDTO(
//    @field:SerializedName("payment") val payment: PaymentInfoDTO,
//    @field:SerializedName("items") val items: List<OrderItemDTO>,
//    @field:SerializedName("packetType") val packetType: List<Any?>
//)
//
//data class PaymentInfoDTO(
//    @field:SerializedName("amount") val amount: Long,
//    @field:SerializedName("transactionId") val transactionId: Any? = null,
//    @field:SerializedName("payStatus") val payStatus: String,
//    @field:SerializedName("payMethod") val payMethod: String
//)
//
//data class TaskLocationDTO(
//    @field:SerializedName("houseNum") val houseNum: String? = null,
//    @field:SerializedName("specialInstructions") val specialInstructions: List<Any?>,
//    @field:SerializedName("coordinates") val coordinates: CoordinatesDTO,
//    @field:SerializedName("contact") val contact: ContactDTO
//)
//
//data class ContactDTO(
//    @field:SerializedName("name") val name: String? = null,
//    @field:SerializedName("mobile1") val mobile1: String? = null,
//    @field:SerializedName("mobile2") val mobile2: String? = null,
//    @field:SerializedName("landline") val landline: String? = null,
//    @field:SerializedName("extension") val extension: String? = null
//
//)

