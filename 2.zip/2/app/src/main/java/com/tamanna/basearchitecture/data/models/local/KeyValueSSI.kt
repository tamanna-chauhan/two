package com.tamanna.basearchitecture.data.models.local

data class KeyValueSSI(val key: String, val value1: String, val value2: String)
