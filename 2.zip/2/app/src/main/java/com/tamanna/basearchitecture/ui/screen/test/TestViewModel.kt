package com.tamanna.basearchitecture.ui.screen.test

import com.tamanna.basearchitecture.ui.base.BaseViewModel

class TestViewModel : BaseViewModel<ITestView>()