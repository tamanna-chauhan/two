package com.tamanna.basearchitecture.ui.screen.mainActivity

import android.view.View
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.chip.Chip
import com.mikepenz.fastadapter.adapters.FastItemAdapter
import com.mikepenz.fastadapter.adapters.GenericFastItemAdapter
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.data.models.Datasource
import com.tamanna.basearchitecture.data.models.ProcessDTO
import com.tamanna.basearchitecture.data.models.base.RHandler
import com.tamanna.basearchitecture.databinding.FragmentMyBinding
import com.tamanna.basearchitecture.databinding.FragmentMyThreeBinding
import com.tamanna.basearchitecture.ui.base.BaseFragment
import com.tamanna.basearchitecture.ui.common.otpview.PinEditView
import com.tamanna.basearchitecture.ui.screen.mainActivity.viewModel.MillingViewModel
import com.tamanna.basearchitecture.ui.screen.mainActivity.viewModel.SprayingViewModel
import com.tamanna.basearchitecture.ui.screen.otp.IOtp
import org.koin.androidx.viewmodel.ext.android.viewModel

class SortingPFragment : BaseFragment<FragmentMyBinding, MillingViewModel>(), IOtp,
    PinEditView.PinViewEventListener {

    override val fvm: MillingViewModel by viewModel()


    override fun getLayoutId() = R.layout.fragment_my

    //save our FastAdapter
    private lateinit var mFastAdapter: GenericFastItemAdapter

    private val navController by lazy {
        findNavController()
    }

    override fun onFragmentReady(view: View) {

        mFastAdapter = FastItemAdapter()

        bd.rvEarning.layoutManager = LinearLayoutManager(requireContext())
        bd.rvEarning.adapter = mFastAdapter


        fvm.getList("4", "2", "Spraying").observe(this) { response ->
            RHandler<List<ProcessDTO>>(this, response) {
                it.forEach { process ->
                    fvm.elogMap[process.key] = process.datasource
                }
                updateUI()
/*

                val dataSourcesList = ArrayList<BindingElogbookItem>()
                it.forEach { process ->
                    process.datasource.forEach { datasource ->
                        dataSourcesList.add(BindingElogbookItem().withDatasource(datasource))
                    }
                }
                mFastAdapter.add(dataSourcesList)
*/
            }
        }

    }

    private fun updateUI() {
        var firstChipId = -1

        for ((key, value) in fvm.elogMap) {
            ///Widget.MaterialComponents.Chip.Choice
            val chip = Chip(requireContext(), null, R.attr.chipStyle)
            if (firstChipId == -1) {
                firstChipId = key.hashCode()
                chip.id = firstChipId
            } else {
                chip.id = key.hashCode()
            }

            chip.text = key.capitalize()
            chip.isCheckable = true
            chip.isCheckedIconVisible = false
            bd.chipGroup.addView(chip)
        }

        bd.chipGroup.isSingleSelection = true
        bd.chipGroup.setOnCheckedChangeListener { group, checkedId ->
            bd.chipGroup.findViewById<Chip>(checkedId).also {
                updateList(fvm.elogMap[it.text.toString()])
            }
        }

        bd.chipGroup.check(firstChipId)
    }

    private fun updateList(datasource: List<Datasource>?) {
        mFastAdapter.clear()
        val dataSourcesList = ArrayList<BindingElogbookItem>()
        datasource?.forEach { datasource ->
            dataSourcesList.add(BindingElogbookItem().withDatasource(datasource))
        }
        mFastAdapter.add(dataSourcesList)

    }


    override fun onDataEntered(pinEditView: PinEditView?, isFill: Boolean) {
    }

    override fun onResponse(code: Int?, response: Any?, title: String?, message: String) {
        super.onResponse(code, response, title, message)
    }


}