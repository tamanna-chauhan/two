package com.tamanna.basearchitecture.api

import com.google.gson.Gson
import com.tamanna.basearchitecture.data.models.base.APIConstant
import com.tamanna.basearchitecture.data.models.base.ResponseDTO
import org.json.JSONObject
import retrofit2.Response
import timber.log.Timber


/**
 * Abstract Base Data source class with error handling
 */
@Suppress("UNCHECKED_CAST")
abstract class BaseDataSource {
    protected suspend fun <T> getResult(call: suspend () -> Response<T>): ResponseDTO<T> {
        try {
            val response = call()
            if (response.isSuccessful) {
                val body = response.body()
                if (body != null) return ResponseDTO.success(data = body)
            } else if (response.code() == 500) {
                val errorJson = JSONObject(response.errorBody()?.string())
                return ResponseDTO.error(
                    title = if (errorJson.has("name"))
                        errorJson.getString("name")
                    else
                        "Error",
                    message = if (errorJson.has("message"))
                        errorJson.getString("message")
                    else
                        "Something Happened"
                )
            }

            /*Your app should never come at this point*/
            return ResponseDTO.error(
                title = "Unknown Error",
                message = "Sorry, Something unexpected happened",
                data = null,
                code = APIConstant.Status.UNKNOWN,
                displayType = ""
            )

        } catch (e: java.net.UnknownHostException) {
            return ResponseDTO.error(
                title = "No Internet Connection",
                message = "You are not connected to internet.\nMake sure wi-fi OR mobile data is on,Airplane Mode is off and try again",
                data = null,
                code = APIConstant.Status.NO_NETWORK,
                displayType = ""
            )
        } catch (e: java.net.ConnectException) {
            return ResponseDTO.error(
                title = "No Internet Connection",
                message = "You are not connected to internet.\nMake sure wi-fi OR mobile data is on,Airplane Mode is off and try again",
                data = null,
                code = APIConstant.Status.NO_NETWORK,
                displayType = ""
            )
        } catch (e: Exception) {
            Timber.e(e)
            /*Try to  never Reach this point*/
            return ResponseDTO.error(
                type = APIConstant.Status.UNKNOWN,
                title = "Oops !! something really bad happened ",
                message = e.message,
                data = null,
                code = 0,
                displayType = ""
            )
        }
    }
}

