package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.ui.helper.appendPriceValue


class ComponentColorTextView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : LinearLayout(context, attrs, defStyleAttr, defStyleRes)
{
    val tv_colored: TextView

    var setText: CharSequence = ""
        set(value) {
            if (value == null) {
                tv_colored.visibility = View.INVISIBLE
                tv_colored.text = ""
                return
            }
            tv_colored.text = value
            tv_colored.isAllCaps = false
            field = value
        }
    var alignmentCenter: Boolean = false
        set(value) {
            if (value) {
                tv_colored.textAlignment = View.TEXT_ALIGNMENT_CENTER
            } else {
                tv_colored.textAlignment = View.TEXT_ALIGNMENT_TEXT_START
            }
            field = value
        }

    var setTextColor : Int = 0
        set(value) {
            tv_colored.setTextColor(value)
            field = value


        }
    init {
        clipToPadding = false
        val view = View.inflate(context, R.layout.type_attribute_color_text, this)
        tv_colored = view.findViewById(R.id.tv_colored)

        val a = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.ComponentColorTextView,
            defStyleAttr,
            defStyleRes
        )
        setText = a.getString(R.styleable.ComponentColorTextView_setText) ?: setText
        alignmentCenter = a.getBoolean(R.styleable.ComponentColorTextView_alignmentCenter, false)
        setTextColor = a.getInt(R.styleable.ComponentColorTextView_colorText, 0)
        a.recycle()
    }

    fun setPrice(price: Double) {
        tv_colored.appendPriceValue(price)

    }

}