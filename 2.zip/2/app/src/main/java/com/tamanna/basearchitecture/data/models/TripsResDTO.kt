package com.tamanna.basearchitecture.data.models

import com.google.gson.annotations.SerializedName

/**
 * Created by Bhupendra Kumar Sahu on 10-Feb-21.
 */
data class TripsResDTO(
    @field:SerializedName("trips") val trips: List<TripListDTO>

)

data class TripListDTO(
    @field:SerializedName("status") val status: String,
    @field:SerializedName("amount") val amount: Double,
    @field:SerializedName("creationTime") val creationTime: String,
    @field:SerializedName("completionTime") val completionTime: String,
    @field:SerializedName("taskId") val taskId: String,
    @field:SerializedName("location") val location: String
)