package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.LinearLayout
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.databinding.ViewFonticonTextviewVerticalBinding
import com.tamanna.basearchitecture.ui.helper.hideEmptyTextView

class LIconTextVerticalView : LinearLayout {

    var icon: CharSequence? = null
        set(value) {
            field = value
            binding.ficon = field.toString()
        }

    var iconBackColor: Int = 0
        set(value) {
            field = value
            binding.ficonback = field
        }

    var iconTextColor: Int = 0
        set(value) {
            field = value
            binding.ficoncolor = field
        }


    var description: String? = null
        set(value) {
            field = value
            binding.ftvDescription.tv_description.hideEmptyTextView(value)

        }

//    var header: String? = null
//        set(value) {
//            field = value
//            binding.ftvHeader.tv_header.hideEmptyTextView(value)
//
//        }
var footer: String? = null
    set(value) {
        field = value
        binding.ftvFooter.tv_description.hideEmptyTextView(value)

    }
    var isShow: Boolean = false
        set(value) {
            field = value
            binding.show = field
        }

    var alignmentCenter: Boolean = true
        set(value) {
            if (value) {
                binding.ftvHeader.alignmentCenter = value
                binding.ftvDescription.alignmentCenter = value
                binding.ftvFooter.alignmentCenter = value
            } else {
                binding.ftvDescription.alignmentCenter = value
                binding.ftvHeader.alignmentCenter = value
                binding.ftvFooter.alignmentCenter = value

            }
            field = value
        }
    private val binding by lazy {
        val layoutInflater = LayoutInflater.from(context)
        ViewFonticonTextviewVerticalBinding.inflate(
            layoutInflater,
            this,
            true
        )
    }

    constructor(context: Context) : this(context, null, 0)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {

        if (attrs != null) {

            val a = context.theme.obtainStyledAttributes(
                attrs,
                R.styleable.LIconTextVerticalView,
                defStyleAttr,
                0
            )
            icon = a.getString(R.styleable.LIconTextVerticalView_fontIcon) ?: icon
//            header = a.getString(R.styleable.LIconTextVerticalView_cardHeader) ?: header
            footer = a.getString(R.styleable.LIconTextVerticalView_cardFooter) ?: footer
            description =
                a.getString(R.styleable.LIconTextVerticalView_cardDescription) ?: description
            iconTextColor = a.getInt(R.styleable.LIconTextVerticalView_fontIconColor, 0)
            iconBackColor = a.getInt(R.styleable.LIconTextVerticalView_backColor, 0)
            alignmentCenter = a.getBoolean(R.styleable.LIconTextVerticalView_alignmentCenter, true)
            isShow = a.getBoolean(R.styleable.LIconTextVerticalView_showIcon, false)


            a.recycle()
        }
    }

    fun setPrice(price: Double) {
        binding.ftvHeader.setPrice(price)

    }

    fun setKm(km: Double) {
        binding.ftvHeader.setKm(km)

    }
}