package com.tamanna.basearchitecture.ui.screen.nodatascreen

import com.tamanna.basearchitecture.ui.base.BaseViewModel

class NoDataViewModel : BaseViewModel<INoDataView>()