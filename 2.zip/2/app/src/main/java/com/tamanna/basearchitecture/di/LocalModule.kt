package com.tamanna.basearchitecture.di

import android.content.Context
import com.tamanna.basearchitecture.util.IConstants
import org.koin.android.ext.koin.androidApplication
import org.koin.dsl.module

fun localModule() = module {

    single {
        androidApplication().getSharedPreferences(
            IConstants.SHARE_PREF_NAME,
            Context.MODE_PRIVATE
        )
    }

//    single { SharedPrefsHelper(get()) }


}