package com.tamanna.basearchitecture.util


fun getQueryParam(query: String, url: String): String {
    try {
        url.split("?")[1].split("&").forEach { params ->
            if (params.contains(query)) {
                return params.split("=")[1]
            }
        }
    } catch (e: java.lang.Exception) {

    }

    return ""
}

