package com.tamanna.basearchitecture.api

import com.tamanna.basearchitecture.data.models.SendOtpDTO
import com.tamanna.basearchitecture.data.models.base.APIConstant
import com.tamanna.basearchitecture.data.models.base.ResponseDTO
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

interface SignUpServiceAPI {

    @POST(APIConstant.URL.SIGNUP_SEND_OTP)
    suspend fun signUpSendOtp(@Body sendOtpDTO: SendOtpDTO): Response<ResponseDTO<Any>>


}
