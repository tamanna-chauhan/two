package com.tamanna.basearchitecture.ui.screen.otp

import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import androidx.navigation.fragment.findNavController
import com.chibatching.kotpref.bulk
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.data.models.SignUpResponseDTO
import com.tamanna.basearchitecture.data.models.UploadsDTO
import com.tamanna.basearchitecture.data.models.base.APIConstant
import com.tamanna.basearchitecture.data.models.base.LoginResponseDTO
import com.tamanna.basearchitecture.data.models.base.RHandler
import com.tamanna.basearchitecture.data.models.base.RiderInfoDTO
import com.tamanna.basearchitecture.databinding.FragmentOtpVerifyBinding
import com.tamanna.basearchitecture.pref.RiderInfo
import com.tamanna.basearchitecture.ui.base.BaseFragment
import com.tamanna.basearchitecture.ui.common.otpview.PinEditView
import com.tamanna.basearchitecture.ui.screen.mainActivity.MainActivity
import com.tamanna.basearchitecture.util.IConstants
import com.tamanna.basearchitecture.util.viewutils.YumUtil
import com.tamanna.basearchitecture.util.viewutils.YumUtil.hideKeyboard
import org.koin.androidx.viewmodel.ext.android.viewModel


class OtpVerifyFragment : BaseFragment<FragmentOtpVerifyBinding, OtpViewModel>(), IOtp,
    PinEditView.PinViewEventListener {
    var flag: String? = ""
    var name: String? = ""
    var deviceId: String = ""
    override val fvm: OtpViewModel by viewModel()


    override fun getLayoutId() = R.layout.fragment_otp_verify
    private val navController by lazy {
        findNavController()
    }

    override fun onFragmentReady(view: View) {
        applyDebounceClickListener(bd.tvTimer)
        deviceId = YumUtil.getDeviceUniqueId(requireContext())
        startCountDownTimer()


    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        bd.mobileNo = arguments?.getString(IConstants.FragmentArgs.MOBILE).toString()
        flag = arguments?.getString(IConstants.FragmentArgs.FLAG).toString()

        when (flag) {
            IConstants.FragmentArgs.SIGNUP -> {
                name = arguments?.getString(IConstants.FragmentArgs.NAME).toString().capitalize()

            }

        }
        bd.pinview.setPinViewEventListener(this)
        bd.btnOtpVerify.isEnabled = false
        bd.btnOtpVerify.setOnClickListener {
            if (bd.pinview.value.length < 4) {
                bd.btnOtpVerify.text = getString(R.string.please_enter_valid_otp)
                bd.btnOtpVerify.isEnabled = false
            } else {
                validateUser()
            }
        }
    }

    override fun onDataEntered(pinEditView: PinEditView?, isFill: Boolean) {
        hideKeyboard(requireActivity())
        pinEditView?.value?.let {
            validateUser()
        }
    }

    override fun onResponse(code: Int?, response: Any?, title: String?, message: String) {
        when (code) {
            APIConstant.Code.OTP_SENT_SUCCESS -> {
                startCountDownTimer()
            }
        }
        super.onResponse(code, response, title, message)
    }

    private fun validateUser() {
        hideKeyboard(requireActivity())
        bd.btnOtpVerify.isEnabled = true
        bd.btnOtpVerify.text = getString(R.string.verify)
        when (flag) {
            IConstants.FragmentArgs.LOGIN -> {
                fvm.verifyLogin(bd.mobileNo.toString(), bd.pinview.value.toString(), deviceId)
                    .observe(viewLifecycleOwner, { result ->
                        RHandler<LoginResponseDTO>(
                            this,
                            result
                        ) {
                            RiderInfo.bulk {
                                accessToken = it.tamanna.authToken
                                tamannaId = it.tamanna.tamannaId
                                name = it.tamanna.name.toString()
                                photo = it.tamanna.photo.toString()
                                accountStatus = it.tamanna.status.toString()
                                percent = it.tamanna.completionPercent
                                bankDetailsComplete = it.tamanna.bankDetailsComplete


                            }
                            setUpZohoVisitor(it.tamanna)
                            showSuccessAlerter(getString(R.string.log_in_successfully))
                            (activity as MainActivity).setProfileDetails()
//                            navController.navigate(R.id.action_to_home)
                        }

                    })
            }
            IConstants.FragmentArgs.SIGNUP -> {
                val uploads: UploadsDTO = UploadsDTO()
                fvm.verifySignUp(
                    uploads,
                    bd.pinview.value.toString(),
                    bd.mobileNo.toString(),
                    deviceId,
                    name.toString()
                )
                    .observe(viewLifecycleOwner, { result ->
                        RHandler<SignUpResponseDTO>(
                            this,
                            result
                        ) {
                            RiderInfo.bulk {
                                accessToken = it.authToken
                                tamannaId = it.tamannaId
                                name = it.name.toString()
                                photo = it.photo.toString()
                                accountStatus = it.status.toString()
                                percent = it.completionPercent
                                bankDetailsComplete = it.bankDetailsComplete


                            }
                            showSuccessAlerter(getString(R.string.sign_up_successfully))

//                            navController.navigate(R.id.action_to_)
                        }

                    })
            }


        }

    }

    private fun setUpZohoVisitor(tamanna: RiderInfoDTO) {


    }

    private fun startCountDownTimer() {
        val counterTimer = object : CountDownTimer(30000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                bd.tvTimerMsg.setText = "${millisUntilFinished / 1000}sec Please Wait"
                bd.tvTimer.isEnabled = false
                bd.tvTimer.setText = ""
                bd.tvTimerMsg.visibility = View.VISIBLE
                bd.tvTimer.visibility = View.GONE
            }

            override fun onFinish() {
                if (activity != null) {
                    bd.tvTimer.isEnabled = true
                    bd.tvTimer.setText = getString(R.string.resend_otp)
                    bd.tvTimerMsg.setText = "Didn't receive the otp? "
                    bd.tvTimerMsg.visibility = View.VISIBLE
                    bd.tvTimer.visibility = View.VISIBLE


                }
            }
        }
        counterTimer.start()
    }

    override fun onDebounceClick(view: View) {
        when (view) {
            bd.tvTimer -> {
                when (flag) {
                    IConstants.FragmentArgs.LOGIN -> {
                        fvm.loginSendOtp(bd.mobileNo.toString()).observe(this, { result ->
                            RHandler<Any>(
                                this,
                                result
                            ) {

                            }

                        })

                    }
                    IConstants.FragmentArgs.SIGNUP -> {
                        fvm.signupResendOtp(bd.mobileNo.toString()).observe(this, { result ->
                            RHandler<Any>(
                                this,
                                result
                            ) {

                            }

                        })

                    }
                }
            }
        }
        super.onDebounceClick(view)

    }

}