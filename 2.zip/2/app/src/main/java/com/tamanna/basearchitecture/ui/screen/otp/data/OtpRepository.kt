package com.tamanna.basearchitecture.ui.screen.otp.data

import androidx.lifecycle.distinctUntilChanged
import com.tamanna.basearchitecture.data.models.LoginOtpDTO
import com.tamanna.basearchitecture.data.models.SendOtpDTO
import com.tamanna.basearchitecture.data.models.SignUpOtpDTO
import com.tamanna.basearchitecture.data.models.UploadsDTO
import com.tamanna.basearchitecture.util.IConstants
import com.tamanna.basearchitecture.worker.networkLiveData

class OtpRepository constructor(
    private val remoteSource: OtpRemoteDataSource
) {
    fun verifyLogin(number: String, otp: String, deviceId: String) = networkLiveData(
        networkCall = {
            val loginOTP =
                LoginOtpDTO(
                    mobile = number,
                    countryCode = IConstants.Country.Code,
                    otp = otp,
                    deviceId = deviceId
                )
            remoteSource.verifyLogin(loginOTP)
        }
    ).distinctUntilChanged()

    fun verifySignUp(
        uploads: UploadsDTO,
        otp: String,
        number: String,
        deviceId: String,
        name: String
    ) = networkLiveData(
        networkCall = {
            val sendOTP =
                SignUpOtpDTO(
                    uploads = uploads,
                    otp = otp,
                    mobile = number,
                    countryCode = IConstants.Country.Code,
                    deviceId = deviceId,
                    name = name
                )
            remoteSource.verifySignUp(sendOTP)
        }
    ).distinctUntilChanged()


    fun signupResendOtp(number: String, countryCode: String, method: String) = networkLiveData(
        networkCall = {
            val send =
                SendOtpDTO(mobile = number, countryCode = countryCode, method = method)
            remoteSource.signupResendOtp(send)
        }
    ).distinctUntilChanged()

    fun loginSendOtp(number: String, countryCode: String, method: String) = networkLiveData(
        networkCall = {
            val send =
                SendOtpDTO(mobile = number, countryCode = countryCode, method = method)
            remoteSource.loginSendOtp(send)
        }
    ).distinctUntilChanged()
}
