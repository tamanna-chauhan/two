package com.tamanna.basearchitecture.ui.base.actiondialog

import androidx.annotation.ColorInt
import com.tamanna.basearchitecture.ui.helper.ThemeConstant

data class ActionItemDTO(
    val key: Int,
    val text: CharSequence,
    @ColorInt val textColor: Int = ThemeConstant.white,
    @ColorInt val buttonColor: Int? = ThemeConstant.logoImage,
    val data: MutableMap<String, Any>? = null
)