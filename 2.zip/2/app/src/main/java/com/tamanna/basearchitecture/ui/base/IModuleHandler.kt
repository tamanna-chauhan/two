package com.tamanna.basearchitecture.ui.base
interface IModuleHandler : IView {
    fun onSuccess(actionId: Int, data: Any?)

}