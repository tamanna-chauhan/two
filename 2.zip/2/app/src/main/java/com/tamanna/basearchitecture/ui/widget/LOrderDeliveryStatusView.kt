package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import androidx.constraintlayout.widget.ConstraintLayout
import com.laalsa.laalsalib.ui.VUtil
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.databinding.ViewOrderDeliveryStatusBinding
import com.tamanna.basearchitecture.util.YUtils

/**
 * Created by Bhupendra Kumar Sahu on 20-Aug-20.
 */
class LOrderDeliveryStatusView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : ConstraintLayout(context, attrs, defStyleAttr, defStyleRes) {

    internal val vbd by lazy {
        val layoutInflater = LayoutInflater.from(context)
        ViewOrderDeliveryStatusBinding.inflate(layoutInflater, this, true)
    }
    var imageRes: Int? = null
        set(value) {

            field = value
            YUtils.setImageRes(vbd.ivInformation.imageview, field)
        }
    var imageResSize: Float = VUtil.dpToPx(45).toFloat()
        set(value) {
            field = value
            vbd.ivInformation.imageResSize = value
        }
    var header: CharSequence = ""
        set(value) {
            if (value == null) {
                vbd.tvInfoHrader.visibility = View.INVISIBLE
                vbd.tvInfoHrader.header = ""
                return
            }
            vbd.tvInfoHrader.header = value
            field = value
        }
    var description: CharSequence = ""
        set(value) {
            if (value == null) {
                vbd.tvInfoDescription.visibility = View.INVISIBLE
                vbd.tvInfoDescription.description = ""
                return
            }
            vbd.tvInfoDescription.description = value
            field = value


        }
    var alignmentCenter: Boolean = true
        set(value) {
            if (value) {
                vbd.tvInfoHrader.alignmentCenter = value
                vbd.tvInfoDescription.alignmentCenter = value
            } else {
                vbd.tvInfoHrader.alignmentCenter = value
                vbd.tvInfoDescription.alignmentCenter = value
            }
            field = value
        }

    init {
        val a = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.LOrderDeliveryStatusView,
            defStyleAttr,
            defStyleRes
        )
        imageResSize =
            a.getDimension(R.styleable.LOrderDeliveryStatusView_imageResSize, imageResSize)
        imageRes = a.getResourceId(
            R.styleable.LOrderDeliveryStatusView_imageRes,
            -1
        )
        header = a.getString(R.styleable.LOrderDeliveryStatusView_cardHeader) ?: header
        description =
            a.getString(R.styleable.LOrderDeliveryStatusView_cardDescription) ?: description
        //  ivSize = a.getInt(R.styleable.LOrderDeliveryStatusView_imageSize, 0)
        alignmentCenter = a.getBoolean(R.styleable.LOrderDeliveryStatusView_alignmentCenter, true)

        a.recycle()
    }
}
