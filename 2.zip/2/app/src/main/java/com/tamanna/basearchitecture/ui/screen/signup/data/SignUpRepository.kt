package com.tamanna.basearchitecture.ui.screen.signup.data

import androidx.lifecycle.distinctUntilChanged
import com.tamanna.basearchitecture.data.models.SendOtpDTO
import com.tamanna.basearchitecture.worker.networkLiveData

class SignUpRepository constructor(
    private val remoteSource: SignUpRemoteDataSource
) {
    fun signUpSendOtp(number: String, countryCode: String, method: String) = networkLiveData(
        networkCall = {
            val sendOTP =
                SendOtpDTO(mobile = number, countryCode = countryCode, method = method)
            remoteSource.signUpSendOtp(sendOTP)
        }
    ).distinctUntilChanged()


}
