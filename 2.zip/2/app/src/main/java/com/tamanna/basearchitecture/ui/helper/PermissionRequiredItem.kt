package com.tamanna.basearchitecture.ui.helper

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.databinding.ItemPermissionRequiredBinding
import com.mikepenz.fastadapter.binding.AbstractBindingItem

class PermissionRequiredItem : AbstractBindingItem<ItemPermissionRequiredBinding>() {

    private var title: String = ""
    private var subtitle: String = ""
    private var listener: View.OnClickListener? = null


    override val type: Int
        get() = R.id.item_permission

    override fun bindView(binding: ItemPermissionRequiredBinding, payloads: List<Any>) {
        super.bindView(binding, payloads)
        attachToWindow(binding)

        binding.title = title
        binding.subtitle = subtitle
        binding.clickListener = listener
    }

    override fun createBinding(
        inflater: LayoutInflater,
        parent: ViewGroup?
    ): ItemPermissionRequiredBinding {
        return ItemPermissionRequiredBinding.inflate(inflater, parent, false)
    }

    fun withTitle(title: String): PermissionRequiredItem {
        this.title = title
        return this
    }


    fun withDescription(description: String): PermissionRequiredItem {
        this.subtitle = description
        return this
    }

    fun withListener(listener: View.OnClickListener): PermissionRequiredItem {
        this.listener = listener
        return this
    }


}