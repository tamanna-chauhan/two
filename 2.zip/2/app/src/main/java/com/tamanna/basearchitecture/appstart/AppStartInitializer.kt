package com.tamanna.basearchitecture.appstart

import android.content.Context
import androidx.startup.Initializer
import com.tamanna.basearchitecture.AppObjects
import com.tamanna.basearchitecture.BuildConfig
import com.tamanna.basearchitecture.di.appModule
import org.koin.android.ext.koin.androidContext
import org.koin.android.ext.koin.androidLogger
import org.koin.core.context.startKoin
import timber.log.Timber

class AppStartInitializer : Initializer<Unit> {

    override fun create(context: Context) {
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
            Timber.d("TimberInitializer is initialized.")
        }
        configureDi(context)
        AppObjects(context)
    }


    private fun configureDi(context: Context) = startKoin {
        // use AndroidLogger as Koin Logger - default Level.INFO
        if (BuildConfig.DEBUG) androidLogger()
        androidContext(context)
        /*// load properties from assets/koin.properties file
        androidFileProperties()*/
        modules(appModule())
    }


    override fun dependencies(): List<Class<out Initializer<*>>> = emptyList()
//    override fun dependencies() = emptyList<Nothing>()

}

