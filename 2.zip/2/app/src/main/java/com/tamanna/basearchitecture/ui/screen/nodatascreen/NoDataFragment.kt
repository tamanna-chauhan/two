package com.tamanna.basearchitecture.ui.screen.nodatascreen

import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.tamanna.basearchitecture.R
import com.tamanna.basearchitecture.databinding.FragmentNoDataBinding
import com.tamanna.basearchitecture.ui.base.BaseFragment
import org.koin.androidx.viewmodel.ext.android.viewModel

class NoDataFragment : BaseFragment<FragmentNoDataBinding, NoDataViewModel>() {
    override fun onDebounceClick(view: View) {
    }

    override fun getLayoutId() = R.layout.fragment_no_data


    override val fvm by viewModel<NoDataViewModel>()

    override fun onFragmentReady(view: View) {
        val action = arguments?.getInt("action", -1)
        val imgDrawable = arguments?.getInt("imgDrawable", -1)
        val title = arguments?.getString("title")
        val message = arguments?.getString("message")

        bd.textTitle.text = title
        bd.textMessage.text = message
        if (imgDrawable != null && imgDrawable != -1)
            bd.imgDrawableIllu.setImageResource(imgDrawable)
        bd.btnTryAgain.setOnClickListener {
//            val host = NavHostFragment.create(R.navigation.mobile_navigation)
//            (requireActivity() as AppCompatActivity).supportFragmentManager.beginTransaction().replace(R.id.nav_host_fragment, host).setPrimaryNavigationFragment(host).commit()
            (requireActivity() as AppCompatActivity).onSupportNavigateUp()
        }

    }


}

