package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.text.TextPaint
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatImageView

class LImageView : AppCompatImageView {
    constructor(context: Context) : super(context,null,0)
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs,0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    )

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val paint= TextPaint(Paint.ANTI_ALIAS_FLAG)
        paint.textSize=25f
        paint.color= Color.RED
        paint.strokeWidth=3f
//        paint.bgColor=Color.WHITE
//        paint.stro
        paint.style=Paint.Style.FILL
//        canvas.drawCircle((canvas.width/2).toFloat(), (canvas.height/2).toFloat(),50f,paint)
        canvas.drawText("Hello",(canvas.width/2).toFloat(), (canvas.height/2).toFloat(),paint)
    }
}
