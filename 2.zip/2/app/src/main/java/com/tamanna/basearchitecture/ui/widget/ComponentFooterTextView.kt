package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.tamanna.basearchitecture.R


class ComponentFooterTextView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : LinearLayout(context, attrs, defStyleAttr, defStyleRes)
{
    private val tv_footer: TextView

     var footer: CharSequence = ""
        set(value) {
            if (value == null) {
                tv_footer.visibility = View.INVISIBLE
                tv_footer.text = ""
                return
            }
            tv_footer.text = value
            field = value
        }
    var alignmentCenter: Boolean = false
        set(value) {
            if (value) {
                tv_footer.textAlignment= View.TEXT_ALIGNMENT_CENTER
            } else {
                tv_footer.textAlignment= View.TEXT_ALIGNMENT_TEXT_START
            }
            field = value
        }
    init {
        clipToPadding = false
        val view = View.inflate(context, R.layout.type_attribute_footer_text, this)
        tv_footer = view.findViewById(R.id.tv_footer)

        val a = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.ComponentFooterTextView,
            defStyleAttr,
            defStyleRes
        )
        footer = a.getString(R.styleable.ComponentFooterTextView_cardFooter) ?: footer
        alignmentCenter = a.getBoolean(R.styleable.ComponentFooterTextView_alignmentCenter, false)
        a.recycle()
    }}