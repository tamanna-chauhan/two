package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.tamanna.basearchitecture.R


/**
 * Created by Bhupendra Kumar Sahu on 19-Aug-20.
 */
class ComponentDescriptionTextView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : LinearLayout(context, attrs, defStyleAttr, defStyleRes)
{
     val tv_description: TextView

     var description: CharSequence = ""
        set(value) {
            if (value == null) {
                tv_description.visibility = View.GONE
                tv_description.text = ""
                return
            }
            tv_description.text = value
            field = value
        }

    var alignmentCenter: Boolean = false
        set(value) {
            if (value) {
                tv_description.textAlignment= View.TEXT_ALIGNMENT_CENTER
            } else {
                tv_description.textAlignment= View.TEXT_ALIGNMENT_TEXT_START
            }
            field = value
        }
    init {
        clipToPadding = false
        val view = View.inflate(context, R.layout.type_attribute_description_text, this)
        tv_description = view.findViewById(R.id.tv_description)

        val a = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.ComponentDescriptionTextView,
            defStyleAttr,
            defStyleRes
        )
        description = a.getString(R.styleable.ComponentDescriptionTextView_cardDescription) ?: description
        alignmentCenter = a.getBoolean(R.styleable.ComponentDescriptionTextView_alignmentCenter, false)

        a.recycle()
    }}