package com.tamanna.basearchitecture.ui.base.actiondialog

object ActionConstant {
    const val CLOSE = 3000
    const val POSITIVE = 3001

}