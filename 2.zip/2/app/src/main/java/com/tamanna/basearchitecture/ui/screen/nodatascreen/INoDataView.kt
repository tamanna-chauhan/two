package com.tamanna.basearchitecture.ui.screen.nodatascreen

import com.tamanna.basearchitecture.ui.base.IView

interface INoDataView : IView
