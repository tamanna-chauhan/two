package com.tamanna.basearchitecture.pref

import com.chibatching.kotpref.KotprefModel

object AppPref : KotprefModel() {
    var darkTheme by booleanPref(default = true)
    var baseUrl by stringPref()
    }

//enum class GameLevel {
//    EASY,
//    NORMAL,
//    HARD
//}