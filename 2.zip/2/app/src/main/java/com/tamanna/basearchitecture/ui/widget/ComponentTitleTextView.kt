package com.tamanna.basearchitecture.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.tamanna.basearchitecture.R


class ComponentTitleTextView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : LinearLayout(context, attrs, defStyleAttr, defStyleRes)
{
     val tv_title: TextView
    var title: CharSequence = ""
        set(value) {
            if (value == null) {
                tv_title.visibility = View.INVISIBLE
                tv_title.text = ""
                return
            }
            tv_title.text = value
            field = value
        }

    var alignmentCenter: Boolean = false
        set(value) {
            if (value) {
                tv_title.textAlignment= View.TEXT_ALIGNMENT_CENTER
            } else {
                tv_title.textAlignment= View.TEXT_ALIGNMENT_TEXT_START
            }
            field = value
        }
    init {
        clipToPadding = false
        val view = View.inflate(context, R.layout.type_attribute_title_text, this)
        tv_title = view.findViewById(R.id.tv_title)

        val a = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.ComponentTitleTextView,
            defStyleAttr,
            defStyleRes
        )
        title = a.getString(R.styleable.ComponentTitleTextView_cardTitle) ?: title
        alignmentCenter = a.getBoolean(R.styleable.ComponentTitleTextView_alignmentCenter, false)

        a.recycle()
    }}